<?php
require_once (dirname(dirname(__FILE__)) . '/staskrun.class.php');
class sTaskRun_mysql extends sTaskRun {}