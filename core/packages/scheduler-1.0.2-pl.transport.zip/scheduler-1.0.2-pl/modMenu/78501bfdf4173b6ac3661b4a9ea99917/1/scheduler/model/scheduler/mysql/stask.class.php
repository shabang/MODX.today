<?php
require_once (dirname(dirname(__FILE__)) . '/stask.class.php');
class sTask_mysql extends sTask {}