<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'sTask',
    1 => 'sTaskRun',
  ),
  'sTask' => 
  array (
    0 => 'sSnippetTask',
    1 => 'sProcessorTask',
    2 => 'sFileTask',
  ),
);