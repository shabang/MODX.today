<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MoreGallery is proprietary software, developed by Mark Hamstra for modmore. By purchasing MoreGallery via https://www.modmore.com/extras/moregallery/, you have received a usage license for a single (1) MODX Revolution installation, including one year (starting on date of purchase) of email support.

While we hope MoreGallery is useful to you and we will try to help you successfully use MoreGallery, modmore is not liable for loss of revenue, damages or other financial loss resulting from the installation or use of MoreGallery.

By using and installing this package, you acknowledge that you shall only use this on a single MODX installation.

Redistribution in any shape or form is strictly prohibited. You may customize or change the provided source code to tailor MoreGallery for your own use, as long as no attempt is made to remove license protection measures. By changing source code you acknowledge you void the right to support unless coordinated with modmore support.
',
    'readme' => '--------------------------------------------
MoreGallery - Awesome Gallery for Revolution
--------------------------------------------
Author: Mark Hamstra - support@modmore.com
--------------------------------------------

MoreGallery is an awesome Gallery add-on for MODX Revolution that puts your galleries where they belong - in the Resource tree. Optimized for speed and an awesome user experience, MoreGallery takes galleries in MODX to a new level.

For more information on features and how to use them, please refer to https://www.modmore.com/extras/moregallery/

MoreGallery includes icons created by Daniel Bruce, licensed as CC BY-SA 3.0.
',
    'changelog' => '++ MoreGallery 1.3.1-pl
++ Released on 2015-03-27
+++++++++++++++++++++++++
- Prevent paste from being intercepted by moregallery, resulting in errors (#41)
- Fix issue when using Gitify where the mgImage representation has duplicated mgr_thumb paths

++ MoreGallery 1.3.0-pl
++ Released on 2015-02-20
+++++++++++++++++++++++++
- Please see the 1.3.0-rc1 changelog below for what\'s new in 1.3.x
- Ensure the moregallery service is loaded before accessing it in mgImage

++ MoreGallery 1.3.0-rc2
++ Released on 2015-02-10
+++++++++++++++++++++++++
- Fix issue requiring &resource to be specified on mgGetImages calls
- Fix positioning issues on URL label text and wide crop previews (#108, 109)
- Make sure removing an image also removes the crop thumbnails (#107)

++ MoreGallery 1.3.0-rc1
++ Released on 2015-02-04
+++++++++++++++++++++++++
New Features:
- Add region of interest cropping for responsive images or better art direction (#5)
- Add new visible/hidden state to images so you can hide an image from the front-end without removing it (#85)
- Add typeahead to tags for much easier tag selection (#84)
- On image upload, automatically extract image name from IPTC data if available (#91)
- Add 5 plugin events to hook into various parts of the gallery interaction (#62)
- Automatically rotate images to the right orientation on upload
- Now context-aware, so all settings can be overridden on context level as well

Improvements:
- Add snippet properties to build (#72, #95)
- Ensure transparent backgrounds remain transparent (instead of black) for thumbnails (#51)
- Add &where property to mgGetImages and mgGetTags for generic filtering, accepts JSON formatted queries. (#83)
- Add loading indicator for image tags (#57)
- New [[+width]] and [[+height]] placeholders for images
- Make sure settings have a lexicon and description (#96)
- Improve image centering/cropping in back-end to be always centered and filling the area
- Prevent conflicts with other phpthumb libraries that may be loaded (#73)
- Change how EXIF data is loaded to make it easier to work with (no thumbnail, flat structure)
- Attempt to increase the available memory on upload to make sure the extra processing is possible even with larger images

Bugfixes:
- Fix issue where editing image information causes data multiplication in the js (#97)

++ MoreGallery 1.2.3-pl
++ Released on 2015-01-29
+++++++++++++++++++++++++
- Fix upload issue when image contained invalid EXIF data

++ MoreGallery 1.2.2-pl
++ Released on 2015-01-19
+++++++++++++++++++++++++
- Fix image alignment issues with screens of exactly 1600px wide
- Updated translations (see https://crowdin.com/project/modmore-moregallery)

++ MoreGallery 1.2.1-pl
++ Released on 2014-10-28
+++++++++++++++++++++++++
- Fix potential issue on PHP 5.5/6 related to exif data
- Change how the "Add Gallery" button in the toolbar is loaded so it also loads on components (thanks Wieger Sloot!)
- Change "Add Gallery" button to use Font Awesome in 2.3.
- Small speed optimization for large galleries (thanks Rico!)

++ MoreGallery 1.2.0-pl
++ Released on 2014-08-04
+++++++++++++++++++++++++
- Fix issue filtering on non-existent tags
- Fix icon in the resource tree in 2.3.? (depends on modxcms/revolution#11736)

++ MoreGallery 1.2.0-rc1
++ Released on 2014-07-18
+++++++++++++++++++++++++
New Features:
- By default set source, relative url and content position to "inherit" so they continue to inherit system defaults after save.
- Allow dragging resources into the image URL field for quick insertion
- Add ability to control placement of image IDs into image file name
- Add ability to prevent the gallery ID from getting added to the file path
- Add ability to use sortBy=`random` with mgGetImages to get random images from cached data

Improvements:
- Improve ContentBlocks compatibility with some styling tweaks and support for content-in-tab
- Improve compatibility with Tagger (Thanks TheBoxer!)
- Make sure TinyMCE is initialised when editing images
- #65 Strip out unnecessary data from AJAX requests that could trigger mod_security errors
- Adjust resource validation to allow for derivatives
- Add [[+idx]] to the tpl in the mgGetTags snippet.
- Added Swedish translation
- Improve UX on adding tags to images by indicating you need to add it with a button or enter
- Update styling to match Revolution 2.3

Bugfixes
- Fix z-index issue with fixed toolbar
- Fix issue loading wrong media source when using import from file feature
- Prevent "`[[+resource.id]]` is not a valid integer and may not be passed to makeUrl()" errors
- Fix javascript issue causing gallery initialisation to fail when the resource tree is not available.
- Make sure the total results is set when data is retrieved from cache
- Fix TinyMCE rendering in image description

++ MoreGallery 1.1.0-pl
++ Released on 2014-01-25
+++++++++++++++++++++++++
New Features:
- Add Tagging functionality: back-end adding of tags, mgGetTags snippet to list tags and updates to mgGetImages to filter on tags and added [[+tags]] placeholder
- Import file into the Gallery by selecting it using the MODX Browser
- #55 Sanitise file names on upload

Fixes:
- Fix toolbar to top of the manager when it goes out of view due to scrolling
- Fix broken images in back-end when using remote media sources (like S3)
- #54 Make sure the container is resized upon opening a full image view modal
- #56 Fix errors being logged due to caching check

Improvements:
- Gallery Toolbar now stays in view when scrolling past it
- Change icon set to sprite-based icon set
- Updated Danish translation.

++ MoreGallery 1.0.2-pl
++ Released on 2013-11-06
+++++++++++++++++++++++++
- Add Danish translation

++ MoreGallery 1.0.1-pl
++ Released on 2013-11-06
+++++++++++++++++++++++++
- Add getResourceFields and getResourceTVs properties to mgGetImages to include fields or TVs placeholders.
- Only use the FileReader (for image previews during upload) when it is supported.
- Fix small content field if there\'s no RTE in use.
- Add French translation.

++ MoreGallery 1.0.0-pl
++ Released on 2013-10-30
+++++++++++++++++++++++++
- Prevent toolbar icon from being duplicated after saving a resource.
- Tiny fix to the CSS to prevent left box shadows from disappearing from the first image in each row.
- Prevent annoying jump in image previews when the image completed upload.
- Added Dutch, Czech, Russian and German translations.
- Extract text into a lexicon file for translation.
- Clear the MoreGallery cache when using the Site > Clear Cache menu option.

++ MoreGallery 0.9.16-pl
++ Released on 2013-10-15
+++++++++++++++++++++++++
- Fix fatal error in snippet.
- Fix issue with content location setting.

++ MoreGallery 0.9.15-pl
++ Released on 2013-10-12
+++++++++++++++++++++++++
- Handle exotic image type errors without triggering E_* errors.
- #25 Open full image in a modal instead of new tab
- #23 Change mgResource\'s to modDocument\'s during uninstall
- Add icon to create new gallery to the resource toolbar (can be disabled with add_icon_to_toolbar setting)
- Add single_image_url_param setting to change the "iid" url param to something different.
- Set the top position of the modal so it\'s within view.
- Fix loading of relative_url setting on resource panel (introduced in 0.9.13)

++ MoreGallery 0.9.14-pl
++ Released on 2013-10-08
+++++++++++++++++++++++++
- Implement better UI through usage of modal window for editing instead of weird sliding panel.
- Refactored to use jQuery UI\'s sortable plugin, while bigger it provides a better drag experience.
- #36 Check memory_limit on server and alert if file is probably to large to resize once uploaded.
- Fix issue creating images with MySQL 5.6 (columns always need a value, default or accept null.)
- Add feature to load RTEs into the edit panel (enabled by default, setting moregallery.use_rte_for_images)

++ MoreGallery 0.9.13-pl
++ Released on 2013-09-27
+++++++++++++++++++++++++
- #38 Hide content field or move it below images or into a new tab
- Add [[+image_count]] placeholder to wrapper tpl.
- #40 Properly load default options (source, url) from system settings on creating a new gallery.
- Fix weird issue with specific environments

++ MoreGallery 0.9.12-pl
++ Released on 2013-09-02
+++++++++++++++++++++++++
- Add some indices for additional (uncached) performance.
- Add "Resource" relation from mgImage to mgResource.
- Fix mgResource>mgImage relation from one to many
- Fix improper class_key setting.

++ MoreGallery 0.9.11-pl
++ Released on 2013-07-29
+++++++++++++++++++++++++
- Add relative_url and source settings to Resource > Settings tab to manage properties.
- Improve focus handling with auto save.
- Set "name" field of the image to the filename without extension by default.
- Improve error messages when upload fails.
- Accept empty value for moregallery.source_relative_url setting (ie, root of media source)

++ MoreGallery 0.9.10-pl
++ Released on 2013-07-23
+++++++++++++++++++++++++
- Add moregallery.source_relative_url and moregallery.source setting.
- Add error (and remove uploading image) if upload failed.

++ MoreGallery 0.9.9-pl
++ Released on 2013-07-21
+++++++++++++++++++++++++
- Fix annoying and broken reload when saving the resource

++ MoreGallery 0.9.8-pl
++ Released on 2013-07-19
+++++++++++++++++++++++++
- Lots of CSS tweaks to make it integrate better with latest 2.2/2.3 design.
- Add ability to link to resources by entering the resource ID.
- Add proper uploading image for images > 700kb.
- Fix loading RTEs.

++ MoreGallery 0.9.7-pl
++ Released on 2013-07-16
+++++++++++++++++++++++++
- Fix E_WARN error on certain environments.

++ MoreGallery 0.9.6-pl
++ Released on 2013-07-16
+++++++++++++++++++++++++
- Fix z-index conflicts with #modAB when editing images.
- Auto focus on name field when opening edit panel.
- Further improvements to performance of the manager, especially when uploading large images:
- - Minimize re-renders of backbone templates
- - Only show image previews for images that are smaller than 700kb to preserve the browser
- - Use data URIs to prevent additional requests for first 20 images in list, and freshly uploaded images.
- - Delay upload by 1s to let the browser do one thing at a time.
- - Only load full size images when opening the edit pane

++ MoreGallery 0.9.5-pl
++ Released on 2013-07-15
+++++++++++++++++++++++++
- Improve browser performance during upload.

++ MoreGallery 0.9.4-pl
++ Released on 2013-07-15
+++++++++++++++++++++++++
- Fix LOG_LEVEL_WARN error "Could not load package metadata"
- Fix prev/next when sortBy is not sortorder or with a descending sortDir
- Add resolver to increase upload_maxsize from 1MB to 10MB on install.
- More sensible (pretty) default chunks.
- Add uploadedon, uploadedby, editedon and editedby fields to images.
- Add ability to paginate through images with getPage
- Add check to make sure chunks referenced are still the same. Removes need to disable &cache.
- Remove dependency on phpthumbof for default chunks.

++ MoreGallery 0.9.3-pl
++ Released on 2013-07-14
+++++++++++++++++++++++++
- Add helpful note to indicate you can drop images into the gallery.
- Improve drag/dropping behavior between sorting and upload.
- Fix issue with uploading images when exif_read_data is not available.
- Make sure link_tag_scheme is used for generating of view_url.

++ MoreGallery 0.9.2-pl
++ Released on 2013-07-13
+++++++++++++++++++++++++
- Fix issue with gallery not properly refreshing when saving a resource.

++ MoreGallery 0.9.1-pl
++ Released on 2013-07-10
+++++++++++++++++++++++++
- Styling improvements.

++ MoreGallery 0.9.0-pl
++ Released on 2013-07-10
+++++++++++++++++++++++++
- Initial beta release.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '498914d51e120ce9406a8ee319636f3e',
      'native_key' => 'moregallery',
      'filename' => 'modNamespace/3f358bb357a174a6396b0165e964fdba.vehicle',
      'namespace' => 'moregallery',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '6af711020f7d1c0dbbc5c016a4cfcd6f',
      'native_key' => '6af711020f7d1c0dbbc5c016a4cfcd6f',
      'filename' => 'xPDOFileVehicle/e7a013b813b9d766f3f259b29361b50f.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f40b4d8161f10fbbdda326bdfc89d3f2',
      'native_key' => 'moregallery.source_relative_url',
      'filename' => 'modSystemSetting/e4abf02e330a3ae0a02e0455922a3a88.vehicle',
      'namespace' => 'moregallery',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54108954da2a07d705e86d42420a120b',
      'native_key' => 'moregallery.source',
      'filename' => 'modSystemSetting/005d67ea4d6381f6e252809e52c76b1d.vehicle',
      'namespace' => 'moregallery',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52f5845621ff24084a62f1ec9e61512d',
      'native_key' => 'moregallery.image_id_in_name',
      'filename' => 'modSystemSetting/9779e59d4e39d02859ed00fb86c9c93d.vehicle',
      'namespace' => 'moregallery',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fa82fcde21d509df6df67251f2c2bca',
      'native_key' => 'moregallery.resource_id_in_path',
      'filename' => 'modSystemSetting/16c41620a1f34004a8f324af99df6343.vehicle',
      'namespace' => 'moregallery',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48dde5eca0eb52ab7b2b565b01996441',
      'native_key' => 'moregallery.content_position',
      'filename' => 'modSystemSetting/183f1089b75a56f2545c500afd465582.vehicle',
      'namespace' => 'moregallery',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e208eebbc1545f870b77b5d261ff04c2',
      'native_key' => 'moregallery.use_rte_for_images',
      'filename' => 'modSystemSetting/c1f77998a438b8eebe47f01d601c144e.vehicle',
      'namespace' => 'moregallery',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61c03767d030ed5c252a9617745b5d04',
      'native_key' => 'moregallery.crops',
      'filename' => 'modSystemSetting/667cc31e610f693d4def20d1d2d287f8.vehicle',
      'namespace' => 'moregallery',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c2ad254d696fb2f6a3aea70c30497b4',
      'native_key' => 'moregallery.single_image_url_param',
      'filename' => 'modSystemSetting/bc9ff799241ab2210333cd9cf77f9afd.vehicle',
      'namespace' => 'moregallery',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '309a5329ecab12a1689f075df535a6e1',
      'native_key' => 'moregallery.add_icon_to_toolbar',
      'filename' => 'modSystemSetting/3e1e6c7d853cc57e70a7607757cb142b.vehicle',
      'namespace' => 'moregallery',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c4c52e22e07d0fb8e1028f28b808014',
      'native_key' => 'moregallery.sanitize_replace',
      'filename' => 'modSystemSetting/bfbbfb4c4f2d4e69511284241eda8770.vehicle',
      'namespace' => 'moregallery',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5ffc1488f1c27324678d3e1fab1b0a4',
      'native_key' => 'moregallery.sanitize_pattern',
      'filename' => 'modSystemSetting/2d808639f04431cace85da28f5487bb6.vehicle',
      'namespace' => 'moregallery',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d8fbcfbb6d90a71df6180cdef396e93',
      'native_key' => 'mgr_tree_icon_mgresource',
      'filename' => 'modSystemSetting/2534904f4fe7cbdac65c05bb7fefd39b.vehicle',
      'namespace' => 'moregallery',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f831fa2673f0e323143bf6a90fe5958',
      'native_key' => 'MoreGallery_OnImageCreate',
      'filename' => 'modEvent/c7f9dfb38834e330ddf78d5f47203d50.vehicle',
      'namespace' => 'moregallery',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a38e5c00986405f5cd0084c4669b1945',
      'native_key' => 'MoreGallery_OnImageRemove',
      'filename' => 'modEvent/809a571fa7488c7bd17982a7053b67a0.vehicle',
      'namespace' => 'moregallery',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba4188ace3dd335352719062ae627f98',
      'native_key' => 'MoreGallery_OnTagCreate',
      'filename' => 'modEvent/836349df697349af4dbb8720096c5463.vehicle',
      'namespace' => 'moregallery',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df113efe1751346efdec4179521f141e',
      'native_key' => 'MoreGallery_OnImageTagCreate',
      'filename' => 'modEvent/fc111a3cdbdcd0e6955581070209ed36.vehicle',
      'namespace' => 'moregallery',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e1c0c321ee64410911fd0b3973878b7',
      'native_key' => 'MoreGallery_OnImageTagRemove',
      'filename' => 'modEvent/480e588853b9309bfb308e32cf2f00f2.vehicle',
      'namespace' => 'moregallery',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'modmoreVehicle',
      'class' => 'modCategory',
      'guid' => 'e483a8a59a49963087376ac54936cac9',
      'native_key' => 1,
      'filename' => 'modCategory/412fa1796f4e99e297b7c25e96d91aa0.vehicle',
      'namespace' => 'moregallery',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '769b8e6c2113e829788b1e5c12071a3b',
      'native_key' => '769b8e6c2113e829788b1e5c12071a3b',
      'filename' => 'xPDOScriptVehicle/871e298a46d3d42061e45ca454b60013.vehicle',
      'namespace' => 'moregallery',
    ),
  ),
);