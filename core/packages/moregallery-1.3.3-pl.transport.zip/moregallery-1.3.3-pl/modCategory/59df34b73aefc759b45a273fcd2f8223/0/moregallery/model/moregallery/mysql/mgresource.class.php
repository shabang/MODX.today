<?php
require_once (dirname(dirname(__FILE__)) . '/mgresource.class.php');
class mgResource_mysql extends mgResource {}