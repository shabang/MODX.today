<?php
require_once (dirname(dirname(__FILE__)) . '/mgimagetag.class.php');
class mgImageTag_mysql extends mgImageTag {}