<?php

$xpdo_meta_map = array (
  'modResource' => 
  array (
    0 => 'mgResource',
  ),
  'xPDOSimpleObject' => 
  array (
    0 => 'mgImage',
    1 => 'mgTag',
    2 => 'mgImageTag',
    3 => 'mgImageCrop',
  ),
  'mgImage' => 
  array (
    0 => 'mgVideo',
  ),
  'mgVideo' => 
  array (
    0 => 'mgYouTubeVideo',
    1 => 'mgVimeoVideo',
  ),
);