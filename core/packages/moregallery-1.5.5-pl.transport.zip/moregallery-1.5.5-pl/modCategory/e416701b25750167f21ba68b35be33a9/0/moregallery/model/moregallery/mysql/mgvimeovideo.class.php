<?php
require_once (dirname(dirname(__FILE__)) . '/mgvimeovideo.class.php');
class mgVimeoVideo_mysql extends mgVimeoVideo {}