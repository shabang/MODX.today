<?php
class qsbSetUserGroup extends xPDOObject {}