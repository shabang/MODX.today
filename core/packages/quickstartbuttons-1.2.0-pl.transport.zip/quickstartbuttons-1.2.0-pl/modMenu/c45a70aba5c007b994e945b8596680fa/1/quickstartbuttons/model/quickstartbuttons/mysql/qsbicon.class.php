<?php
require_once (dirname(dirname(__FILE__)) . '/qsbicon.class.php');
class qsbIcon_mysql extends qsbIcon {}