<?php
class qsbIcon extends xPDOSimpleObject {}