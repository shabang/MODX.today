<?php
require_once (dirname(dirname(__FILE__)) . '/qsbsetusergroup.class.php');
class qsbSetUserGroup_mysql extends qsbSetUserGroup {}