<?php
require_once (dirname(dirname(__FILE__)) . '/hit.class.php');
class Hit_mysql extends Hit {}