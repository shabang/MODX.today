<?php
class Hit extends xPDOSimpleObject {}