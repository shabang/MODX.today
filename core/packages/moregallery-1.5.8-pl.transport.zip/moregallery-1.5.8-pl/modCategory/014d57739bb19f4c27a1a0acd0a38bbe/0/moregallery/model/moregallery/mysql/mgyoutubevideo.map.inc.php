<?php
$xpdo_meta_map['mgYouTubeVideo']= array (
  'package' => 'moregallery',
  'version' => '1.1',
  'extends' => 'mgVideo',
  'inherit' => 'single',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
