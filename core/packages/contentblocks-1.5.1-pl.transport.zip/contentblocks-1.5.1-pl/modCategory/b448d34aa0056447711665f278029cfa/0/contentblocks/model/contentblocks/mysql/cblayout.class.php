<?php
require_once (dirname(dirname(__FILE__)) . '/cblayout.class.php');
class cbLayout_mysql extends cbLayout {}
