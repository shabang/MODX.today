<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'cbLayout',
    1 => 'cbField',
    2 => 'cbTemplate',
    3 => 'cbDefault',
  ),
);