<?php
/**
 * Removes a cbLayout object.
 */
class cbLayoutRemoveProcessor extends modObjectRemoveProcessor {
    public $classKey = 'cbLayout';
    public $objectType = 'cbLayout';
}
return 'cbLayoutRemoveProcessor';
