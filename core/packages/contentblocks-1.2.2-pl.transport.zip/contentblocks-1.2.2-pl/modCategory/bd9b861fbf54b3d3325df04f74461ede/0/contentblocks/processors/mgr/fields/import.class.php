<?php
require_once dirname(dirname(__FILE__)) . '/import.class.php';
/**
 * Class cbFieldImportProcessor
 */
class cbFieldImportProcessor extends ContentBlocksImportProcessor
{
    public $classKey = 'cbField';
}

return 'cbFieldImportProcessor';
