<?php
/**
 * Removes a cbTemplate object.
 */
class cbTemplateRemoveProcessor extends modObjectRemoveProcessor {
    public $classKey = 'cbTemplate';
    public $objectType = 'cbTemplate';
}
return 'cbTemplateRemoveProcessor';
