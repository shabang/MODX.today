<?php
require_once dirname(dirname(__FILE__)) . '/export.class.php';
/**
 * Class cbLayoutExportProcessor
 */
class cbLayoutExportProcessor extends ContentBlocksExportProcessor
{
    public $classKey = 'cbLayout';
}

return 'cbLayoutExportProcessor';
