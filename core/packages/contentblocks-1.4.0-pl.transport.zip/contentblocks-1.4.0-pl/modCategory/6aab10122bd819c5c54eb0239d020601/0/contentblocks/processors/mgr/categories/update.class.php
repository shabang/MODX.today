<?php
/**
 * Updates a cbCategory object
 */
class cbCategoryUpdateProcessor extends modObjectUpdateProcessor {
    public $classKey = 'cbCategory';
    public $languageTopics = array('contentblocks:default');
}
return 'cbCategoryUpdateProcessor';
