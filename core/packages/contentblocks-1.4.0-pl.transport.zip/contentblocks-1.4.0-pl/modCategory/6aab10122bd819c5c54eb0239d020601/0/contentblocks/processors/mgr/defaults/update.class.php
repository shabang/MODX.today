<?php
/**
 * Updates a cbDefault object
 */
class cbDefaultUpdateProcessor extends modObjectUpdateProcessor {
    public $classKey = 'cbDefault';
    public $languageTopics = array('contentblocks:default');
}
return 'cbDefaultUpdateProcessor';
