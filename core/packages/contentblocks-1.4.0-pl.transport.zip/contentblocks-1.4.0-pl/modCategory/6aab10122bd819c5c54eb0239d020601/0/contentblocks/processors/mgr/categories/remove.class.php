<?php
/**
 * Removes a cbCategory object.
 */
class cbCategoryRemoveProcessor extends modObjectRemoveProcessor {
    public $classKey = 'cbCategory';
    public $objectType = 'cbCategory';
}
return 'cbCategoryRemoveProcessor';
