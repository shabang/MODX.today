<?php
/**
 * Removes a cbField object.
 */
class cbFieldRemoveProcessor extends modObjectRemoveProcessor {
    public $classKey = 'cbField';
    public $objectType = 'cbField';
}
return 'cbFieldRemoveProcessor';
