<?php
require_once dirname(dirname(__FILE__)) . '/import.class.php';
/**
 * Class cbCategoryImportProcessor
 */
class cbCategoryImportProcessor extends ContentBlocksImportProcessor
{
    public $classKey = 'cbCategory';
}

return 'cbCategoryImportProcessor';
