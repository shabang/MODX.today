<?php
require_once dirname(dirname(__FILE__)) . '/export.class.php';
/**
 * Class cbCategoryExportProcessor
 */
class cbCategoryExportProcessor extends ContentBlocksExportProcessor
{
    public $classKey = 'cbCategory';
}

return 'cbCategoryExportProcessor';
