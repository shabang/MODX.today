<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2014 modmore | More for MODX

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => 'Gitify Watch
============

No, it\'s not a smart watch.. but it is a really cool plugin for MODX Revolution!

Gitify Watch is a MODX plugin to complement the Gitify command line tool. It hooks into various MODX events,
and will automatically extract and commit changes you make.

The primary purpose of Gitify Watch is to be sure changes made directly on production are immediately pushed to the git
remote, so it is easy to keep a development server up to date. With project-specific development, it could also be a
starting point for building a complete workflow away from the command line.

',
    'changelog' => '++ Gitify Watch 1.0.0-rc1
++ Released on 2015-04-15
+++++++++++++++++++++++++
- First public release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'bdfd13917c60af6ee5d86b9dc7d75b8f',
      'native_key' => 'gitifywatch',
      'filename' => 'modNamespace/ef91bc2845316e54a51cda3a63823977.vehicle',
      'namespace' => 'gitifywatch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '103e7bc37cee6d5d0e81ba08fb9cde7a',
      'native_key' => 'gitifywatch.repository_path',
      'filename' => 'modSystemSetting/75948e0ea83fb6927676cce3d43bc4f9.vehicle',
      'namespace' => 'gitifywatch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9abf0bd50ed5fd9e47499b68093f14d',
      'native_key' => 'gitifywatch.gitify_path',
      'filename' => 'modSystemSetting/874ac100004f6bc5b5e66b395cd3781f.vehicle',
      'namespace' => 'gitifywatch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '75b11074b01d20acf25cdf4e45ca5f53',
      'native_key' => NULL,
      'filename' => 'modCategory/0e0d903690a540d2a5c3ab01a6a29c50.vehicle',
      'namespace' => 'gitifywatch',
    ),
  ),
);