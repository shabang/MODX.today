<?php
require_once dirname(dirname(__FILE__)) . '/import.class.php';
/**
 * Class cbLayoutImportProcessor
 */
class cbLayoutImportProcessor extends ContentBlocksImportProcessor
{
    public $classKey = 'cbLayout';
}

return 'cbLayoutImportProcessor';
