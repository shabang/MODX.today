<?php
require_once dirname(dirname(__FILE__)) . '/import.class.php';
/**
 * Class cbTemplateImportProcessor
 */
class cbTemplateImportProcessor extends ContentBlocksImportProcessor
{
    public $classKey = 'cbTemplate';
}

return 'cbTemplateImportProcessor';
