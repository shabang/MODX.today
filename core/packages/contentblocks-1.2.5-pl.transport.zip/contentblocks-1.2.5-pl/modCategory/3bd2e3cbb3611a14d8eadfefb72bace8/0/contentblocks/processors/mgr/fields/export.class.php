<?php
require_once dirname(dirname(__FILE__)) . '/export.class.php';
/**
 * Class cbFieldExportProcessor
 */
class cbFieldExportProcessor extends ContentBlocksExportProcessor
{
    public $classKey = 'cbField';
}

return 'cbFieldExportProcessor';
