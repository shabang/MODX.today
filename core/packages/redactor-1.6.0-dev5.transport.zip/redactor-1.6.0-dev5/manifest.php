<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'modmore is a valid license holder of the Redactor OEM license by Imperavi.

This license is a legal agreement between you and modmore for the use of the Redactor for MODX Extra. By downloading or installing Redactor, you agree to the terms and conditions of this license. modmore reservers the right to alter this agreement at any time, for any reason, without notice.

This license is valid for a single MODX installation and may not be redistributed, changed or removed of its license.

===== Included for reference, the Redactor OEM License ====

This license is a legal agreement between you and Imperavi for the use of Redactor (*all versions*) Software (the “Software”). By downloading any version of redactor you agree to be bound by the terms and conditions of this license. Imperavi reserves the right to alter this agreement at any time, for any reason, without notice.

Restrictions
Unless you have been granted prior, written consent from Imperavi, you may not:
Reproduce, distribute, or transfer the Software as a sole product, or portions thereof, to any third party.
Sell, rent, lease, assign, or sublet the Software as a sole product or portions thereof.
Grant rights to any other person.
Use the software in violation of any Canadian or international laws or regulations.
Display of Copyright Notices
All copyright and proprietary notices and logos (if any) of Redactor/Imperavi and within the Software files must remain intact.

Making Copies
You may make copies of the Software for back-up purposes, provided that you reproduce the Software in its original form and with all proprietary notices on the back-up copy. You may include copies of the Software as an integral part of your product (according to Permitted Use stated above).

Software Modification
You may alter, modify, or extend the Software for your own use or for use in as an integral part of your product or service, or commission a third-party to perform modifications for you, but you may not resell, redistribute or transfer the modified or derivative version of the Software as a sole product without prior written consent from Imperavi. Components from the Software may not be extracted and used in other programs without prior written consent from Imperavi.

Technical Support
Technical support is provided by email. No representations or guarantees are made regarding the response itself or response time in which support questions are answered. For the Support License holders response is guaranteed and the response time is no more than 1 (one) business day (Friday requests are answered on Monday; afternoon requests are answered next day).

Refund Policy
We offer a 30 day money back. If for any reason Redactor doesn’t work out for your project, simply email us within 30 days of purchase for a full refund.

Indemnity
You agree to indemnify and hold harmless Imperavi for any third-party claims, actions or suits, as well as any related expenses, liabilities, damages, settlements or fees arising from your use or misuse of the Software, or a violation of any terms of this license.

Disclaimer Of Warranty
THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, WARRANTIES OF QUALITY, PERFORMANCE, NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. FURTHER, IMPERAVI DOES NOT WARRANT THAT THE SOFTWARE OR ANY RELATED SERVICE WILL ALWAYS BE AVAILABLE.

Limitations Of Liability
YOU ASSUME ALL RISK ASSOCIATED WITH THE INSTALLATION AND USE OF THE SOFTWARE. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS OF THE SOFTWARE BE LIABLE FOR CLAIMS, DAMAGES OR OTHER LIABILITY ARISING FROM, OUT OF, OR IN CONNECTION WITH THE SOFTWARE. LICENSE HOLDERS ARE SOLELY RESPONSIBLE FOR DETERMINING THE APPROPRIATENESS OF USE AND ASSUME ALL RISKS ASSOCIATED WITH ITS USE, INCLUDING BUT NOT LIMITED TO THE RISKS OF PROGRAM ERRORS, DAMAGE TO EQUIPMENT, LOSS OF DATA OR SOFTWARE PROGRAMS, OR UNAVAILABILITY OR INTERRUPTION OF OPERATIONS.
',
    'readme' => '------------------------------------------------------
Redactor - Sexy RTE/WYSIWYG Editor for MODX Revolution
------------------------------------------------------
Author: JP DeVries, Mark Hamstra - support@modmore.com
------------------------------------------------------

Redactor is a commercial-grade Rich Text Editor developed by Imperavi, tightly integrated into MODX by modmore. Redactor for MODX has all the features you would expect in a rich text editor with all the flexibility you expect from MODX and modmore.

The media management in Redactor is optimized for client use, providing the site builder with lots of power to enforce upload and selection rules.

For a full list of features and configuration, please check the website: https://www.modmore.com/extras/redactor/
',
    'changelog' => 'New Features:
 - New and updated plugins including Counter, Limiter, and TextExpander!
 - New Modular API for greater plugin extensibility
 - Updated to Redactor.js v10 to include Imperavi\'s many updates, improvements and fixes http://imperavi.com/redactor/log/
  - All new Syntax Highlighter Support powered by the renowned Ace code editor!
  - Updated jQuery to ~1.11.2
 
 Depreciated:
 - Air mode, iframe mode, xhtml mode, vym mode. For full details see http://imperavi.com/redactor/docs/whats-new-10/


++ Redactor 1.5.3-pl
++ Released on 2014-12-30
++++++++++++++++++++++++++
- Fix issue browsing images when there is only one image in the browse folder.

++ Redactor 1.5.2-pl
++ Released on 2014-11-07
++++++++++++++++++++++++++
- Load the current resource more definitively to cover some edge cases where the resource is not in the modX scope
- Loosens Patch 11291 Conditional which caused asset paths to break in Revolution 2.3.2+
- Lexicon Updates

++ Redactor 1.5.1-pl
++ Released on 2014-10-29
++++++++++++++++++++++++++
- Fix z-index issue when used with MIGX
- #244 Fixes Adding Classes via Custom Formats

++ Redactor 1.5.0-pl
++ Released on 2014-08-14
++++++++++++++++++++++++++
- Several all new features!!! See Redactor 1.5.0-rc1 release notes below for more info https://www.modmore.com/blog/2014/announcing-redactor-1.5/
- Added Hidden Mobile Buttons to TV Level
- Lexicon Updates

++ Redactor 1.5.0-rc2
++ Released on 2014-08-08
++++++++++++++++++++++++++
- Some more design tweaks in modals and fields for better consistency
- Fix "undefined" placeholder for linking to resources
- #235 Fixed toolbar offset height in MODX 2.2.x
- #237 Fix Linking issue when editing images
- #238 Fixed underlapping toolbar issue
- Added toolbarFixed and toolbarFixedBox settings
- Fix setting lexicon keys for predefinedLinks and shortcutsAdd

++ Redactor 1.5.0-rc1
++ Released on 2014-08-05
++++++++++++++++++++++++++
- ALL NEW Custom Toolbars Feature!!! https://www.modmore.com/redactor/toolbar
- New Custom Formats WYSIWYG Widget https://www.modmore.com/extras/redactor/documentation/creating-custom-formats#/custom-formats
- Now easier to link image to resources with new typeahead feature
- New Predefined Links Feature for quicker editing
- Added rebeccapurple support to all color settings
- Fix the toolbar within the editor box so it\'s always in screen
- #100 Properly report error to user if upload failed for whatever reason
- Make tweaks to the CSS to make Redactor blend in with 2.3 even better
- Use proper dependency injection model in plugins
- Prevent excessive error logging in 2.3.0
- Added $redactor->versions support for third party packages to determine Redactor\'s version
- Updated fontcolor plugin
- #224 Fixed Editing Link URLs in Firefox
- #219 Fixed Broken Modal in Fullscreen mode
- #194 Fix clearing margins when un-floating images
- #184 Fixed tab inserts "1" bug
- #214 Table pasting issue
- #202 Open in New tab when linking to a file
- Updated redactor.js to 9.2.6
- - New Typewriter mode
- - Hidden Mobile Buttons
- - Toolbar Overflow
- - Image Tab Link Setting
- - Clean Spaces Setting
- - Additional Shortcuts
- - Many bug fixes. See more at http://imperavi.com/redactor/log/


++ Redactor 1.4.3-pl
++ Released on 2014-07-28
++++++++++++++++++++++++++
- #227 Enables a patch for broken asset paths. If running MODX 2.2.15 - 2.3.1, Redactor will attempt to patch broken asset URLs caused by modxcms/revolution#11291. To disable create a redactor.patch_11291 System Setting and set to \'No\'.

++ Redactor 1.4.2-pl
++ Released on 2014-07-07
++++++++++++++++++++++++++
- #217 Fixes broken image thumbnails when inserting images from a search result
- #221 Loosen image search sensitivity
- Fix typo causing OnRichTextEditorInit event from not getting checked.

++ Redactor 1.4.1-pl
++ Released on 2014-04-11
++++++++++++++++++++++++++
- Ensure Redactor TVs have access to the Resource data for upload/browse path placeholders
- Fix loading the proper RTE based on context settings
- #153 Fix E_NOTICE error in redactor class because of check for pre-2.2.9 S3 issue
- Fix lexicon entries for new settings in 1.4.0
- Ensure that the English language set is used as default to prevent undefined issues.

++ Redactor 1.4.0-pl
++ Released on 2014-02-13
++++++++++++++++++++++++++
- New Advanced Attributes feature for WYSIWYG editing of classes and ids on images and links!
- 25 New Languages
- Update to Redactor 9.1.9 with several bug fixes!
- Update to jQuery 1.11.0
- #175 Prevent Images from loading until Choose tab is selected
- #176 Fix issue when loading Redactor on non-CMP pages
- #171 Fix undesired base path appended on Edit Link window (set linkProtocol to empty)
- #169 Fix colors in FontColor plugin
- #168 Add Anchors to Links (via Advanced Attributes)
- #94 Add optional class field to images (via Advanced Attributes)
- #163 Add extra placeholder for upload paths (pagetitle, alias, context_key)
- #160 Add linkNoFollow System Setting
- #155 Fix choose file/image when there is only 1 result
- #80 Fix View Source overlapping save buttons

++ Redactor 1.3.5-pl
++ Released on 2013-11-18
++++++++++++++++++++++++++
- Fix problem with redactor loading in the content area (reverts #140)

++ Redactor 1.3.4-pl
++ Released on 2013-11-18
++++++++++++++++++++++++++
- #143 Fix issues with link* settings
- #140 Ensure Redactor loads in MIGX DB

++ Redactor 1.3.3-pl
++ Released on 2013-11-14
++++++++++++++++++++++++++
- Updating to Redactor 9.1.7
- Update to jQuery 1.10.2
- Add [[+day]] tag for dynamic file and image upload paths
- #150 Fix bug with unordered lists in Clips JSON
- #136 Default observeLinks to true

++ Redactor 1.3.2-pl
++ Released on 2013-10-18
++++++++++++++++++++++++++
- Add sanitizePattern and sanitizeReplace settings to tweak upload file name sanitization
- Fix issue with page not reloading when creating resources that have a Redactor TV.
- Improve loading in custom components that are built with modManagerControllerDeprecated
- Fix bug with incorrect paths when using the Choose files functionality.
- Update to Redactor 9.1.5:
- - Fix several issues with outdent, video links and uploading
- - new image and file parameter configuration
- - new xhtml setting making code produced by Redactor more XHTML-compatible
- - new linkSize setting to allow links to be truncated
- - improves parsing of Vimeo links
- - improves performance on large texts
- - improves compatibility with IE 7.
- Update to Redactor 9.1.4:
- - fix observeLinks tooltip compatibility when in fullscreen mode
- - fix IE9-10 issues with clipboard paste.

++ Redactor 1.3.1-pl
++ Released on 2013-09-17
++++++++++++++++++++++++++
- Ensure linkProtocol can be disabled.
- #52 Ensure floated images stay in their WYM container
- #91 Changing image position improperly unset margins/classes from the former position
- #127 Default to editor_css_path setting if redactor.css is empty
- #128 Fix description of file browse path setting
- Update to Redactor 9.1.4, which fixes observeLinks functionality in iframe and fullscreen and IE9-10 issues with clipboard paste. http://imperavi.com/redactor/log/
- #135 Restore missing CSS since 1.3.0.
- #134 Fix resource search with Redactor TVs
- #133 Fix missing styles for list items

++ Redactor 1.3.0-pl
++ Released on 2013-09-09
++++++++++++++++++++++++++
- Update to Redactor 9.1.3 which fixes many formatting and pasting issues and adds copy-paste image support for uploads! Pasting images to S3 Media Sources requires MODX 2.2.9 or later. Thanks to Jan Peca for the MODX 2.2.9 fix!
- Added drag and drop for images support. Just drag images right into the content area!
- Images can be moved/dragged across text.
- Rewritten and improved image resizing.
- Link parsing for images and videos. Paste URLs to images YouTube or Vimeo videos to auto embed.
- Option to open links in new tab.
- Paste as plain text.
- Removed toolbar color selector
- Added color selector plugin
- New tidyHtml setting - allows to turn off nice output code formatting.
- New observeLinks feature allows to follow/edit links by putting cursor to the link
- #130 Add system setting for removeEmptyTags
- #131 Fix for missing styles in iFrame mode

++ Redactor 1.2.8-pl
++ Released on 2013-09-05
++++++++++++++++++++++++++
- Fix Redactor TVs when the language is set to something other than English.

++ Redactor 1.2.7-pl
++ Released on 2013-08-22
++++++++++++++++++++++++++
- #121 Add [[+id]] placeholder to paths to insert resource IDs.
- Only load clips and styles plugin on TVs when necessary.

++ Redactor 1.2.6-pl
++ Pre-Released on 2013-08-15
++++++++++++++++++++++++++
- #123 Mail to tab on insert link modal now is available by default
- #124 Fix issue when displaying image subfolders when choosing images
- #125 Add browse configurations for images and files to Redactor Template Variables
- #118 Fixes issue with remote media sources

++ Redactor 1.2.5-pl
++ Released on 2013-08-06
++++++++++++++++++++++++++
- Fix issues with MIGX ("$ is undefined" errors)
- Fix odd issue on PHP 5.3 with not loading the scripts.

++ Redactor 1.2.4-pl
++ Released on 2013-08-05
++++++++++++++++++++++++++
- Fix issues with redactor.additionalPlugins.
- Fix issue with regular richtext TVs not loading Redactor.

++ Redactor 1.2.3-pl
++ Released on 2013-08-04
++++++++++++++++++++++++++
- #117 Add Custom CSS stylesheet in non-iframe mode
- #113 Add insert advanced option to Styles JSON (set "advanced":"1") to use insertHTMLAdvanced
- Renamed Iframe CSS Setting to Stylesheet

++ Redactor 1.2.2-pl
++ Released on 2013-08-02
++++++++++++++++++++++++++
- #112 Improve Styles JSON compatibility
- #113 Consider code tag text-level semantic element (not block)
- #114 Add forceBlock option to JSON

++ Redactor 1.2.1-pl
++ Released on 2013-08-02
++++++++++++++++++++++++++
- #110 Fix console error with Clips plugin
- #111 Custom Formatting: wrap inline for text-level semantic tags

++ Redactor 1.2.0-pl
++ Released on 2013-08-02
++++++++++++++++++++++++++
- #99 Fix air toolbar not showing in fullscreen mode
- #107 Default media source for Redactor to value of default_media_source setting
- #16 Add ability to load custom plugins through a system setting definition.
- #108 Slightly change text to indicate you need to start typing to find resources.
- #48 Refactor to make use of OnRichTextEditorInit plugin event to allow using Redactor in other components.
- Update to Redactor 9.0.4 to fix amoung other things issue when switching between visual and source code mode in Firefox, pasting in iOS and inline styles. http://imperavi.com/redactor/log/
- #44 Add custom formats like TinyMCE
- #69 Add Clips Plugin
- #105 Add base tag when in iFrame mode (for TinyMCE and CKEditor compatibility)
- Fix for TVs when which_editor != Redactor
- #103 Open in New Tab option when linking to Resources
- #20 Add MIGX Support
- #16 System Setting to load custom plugins


++ Redactor 1.1.2-pl
++ Released on 2013-07-03
++++++++++++++++++++++++++
- Add missing cachebust from 1.1.1-pl.

++ Redactor 1.1.1-pl
++ Released on 2013-07-03
++++++++++++++++++++++++++
- Update to Redactor 9.0.3, fixing among other things firefox issues with typing after selecting text, various cleanup bugs, switching between ul/ol tags. http://imperavi.com/redactor/log/
- Fix further issues with link editing.
- #46 Fix issues with iframe mode.

++ Redactor 1.1.0-pl
++ Released on 2013-07-01
++++++++++++++++++++++++++
- Update to Redactor 9.0.2 fixing among other things pasting lists from Google Docs, inactive buttons, pasting in Chrome, link pasting and undo. http://imperavi.com/redactor/log/
- #40 Add browse feature for adding/linking to files + redactor.browse_files Setting to enable it
- #33 Add fullscreen plugin + redactor.buttonFullScreen Setting to enable it
- #55 Add redactor.displayImageNames Setting to display file names under images in Choose window
- #66 Add redactor.dynamicThumbs Setting to disable dynamic thumbnail (phpthumb)
- #50 Properly change/escape unsafe characters in uploads
- #56 Fix typeahead initialization on non-link modals
- #41 Show warning if no file exist in browsing location.
- #60 Add redactor.browse_path Setting to allow browsing elsewhere than uploads directory.
- #38 Add redactor.linkResource Setting to hide Resource tab in Link window
- #65 Fix Incorrect Link Options bug.
- #58 Combine and Minify JavaScript on frontend.
- #61 Cache Bust JavaScript.
- #62 Fixed broken manager pages with RedactorTV bug.
- #63 Moved Resource Tab to second position in insert link window
- French lexicon updated, partial Dutch and Czech added.

++ Redactor 1.0.3-pl
++ Released on 2013-06-17
++++++++++++++++++++++++++
- Update to Redactor 9.0.1, fixing among other things backspace issues, link adding/editing. http://imperavi.com/redactor/log/
- #49 Make sure to use jQuery noConflict mode to make sure it plays nice with other possible jQuery instances.
- Fix wrong method (process instead of render) in TV Input Type.
- #53 Fix undefined on file upload bug.
- #51 Fixed broken links on dated files bug.
- #34 Moved Resource tab to first position.

++ Redactor 1.0.2-pl
++ Released on 2013-06-05
++++++++++++++++++++++++++
- Fix additional issue with loading translations in non-English managers due to 9.0.0 changes.

++ Redactor 1.0.1-pl
++ Released on 2013-06-05
++++++++++++++++++++++++++
- Fix issue with loading translations in non-English managers due to 9.0.0 changes.

++ Redactor 1.0.0-pl
++ Released on 2013-06-05
++++++++++++++++++++++++++
- Fix ability to uninstall the package.
- #35, #36, #45 Update setting descriptions for Redactor 9.0.0 and to be more useful.
- #37 Change insert link text to "Insert/Edit link"
- #42 Add ability to disable the introtext displaying in resource typeahead.
- #43 Add ability to scroll in the resource type ahead
- Upgrade to Imperavi\'s Redactor 9.0.0

++ Redactor 0.9.3-pl
++ Released on 2013-05-27
++++++++++++++++++++++++++
- Add French lexicon. Thanks @rtripault!
- #32 Add HTML5 tags to the default allowedTags setting.

++ Redactor 0.9.2-pl
++ Released on 2013-05-27
++++++++++++++++++++++++++
- Fix bug where settings and other configuration were not properly passed to Redactor.
- Change default buttons to include separators.

++ Redactor 0.9.1-pl
++ Released on 2013-05-24
++++++++++++++++++++++++++
- First released version of Redactor through modmore.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '047555d21d84a530576a9b5d4dd7e48a',
      'native_key' => 'redactor',
      'filename' => 'modNamespace/5c981a8dd0e6f36f4ca2d6e4deb8b9e7.vehicle',
      'namespace' => 'redactor',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '7bd3240092959039904e65258ffb2bd6',
      'native_key' => '7bd3240092959039904e65258ffb2bd6',
      'filename' => 'xPDOFileVehicle/014ae3efb18f4f9245670ef2fcd8be27.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'modmoreVehicle',
      'class' => 'modPlugin',
      'guid' => '001d49787eea7c74b4f3467f7f3bee17',
      'native_key' => NULL,
      'filename' => 'modPlugin/23acd65fed3e4c9981175c0237e21ef2.vehicle',
      'namespace' => 'redactor',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69f6863c82c5f7656e530d22b04e64ee',
      'native_key' => 'redactor.lang',
      'filename' => 'modSystemSetting/95fb03f412ae4f637ed7c1341ddc2c07.vehicle',
      'namespace' => 'redactor',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b3d00e7ce6e673c3d8ee1233c07c5ee',
      'native_key' => 'redactor.direction',
      'filename' => 'modSystemSetting/46e495a7303403562d08402b7e1946cb.vehicle',
      'namespace' => 'redactor',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7fd505b10fafdb0e625f181d4c6132e0',
      'native_key' => 'redactor.buttons',
      'filename' => 'modSystemSetting/880c01f77588945e4948d5b29c545626.vehicle',
      'namespace' => 'redactor',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d7c7aa31be76d22269d87846979196c',
      'native_key' => 'redactor.formattingTags',
      'filename' => 'modSystemSetting/5d58ad9fd62301037080741ad525f13c.vehicle',
      'namespace' => 'redactor',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '585f38f7e5a27d64279d3405e8dcaa5a',
      'native_key' => 'redactor.buttonSource',
      'filename' => 'modSystemSetting/c706372941b1738d067ba5bfee5df251.vehicle',
      'namespace' => 'redactor',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d1577f4748700d9050e4d85dc7878fe',
      'native_key' => 'redactor.buttonFullScreen',
      'filename' => 'modSystemSetting/7dab71a7f04546d0787f7fda9a41a003.vehicle',
      'namespace' => 'redactor',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1ec2209cb2dba561804c3e62c041c81',
      'native_key' => 'redactor.css',
      'filename' => 'modSystemSetting/4db6ab743862bf69cae65cbcace1b5ca.vehicle',
      'namespace' => 'redactor',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c9bd774ab34e948106c6116b2bae624',
      'native_key' => 'redactor.shortcuts',
      'filename' => 'modSystemSetting/d595471b4a8de1b1acf996008567584a.vehicle',
      'namespace' => 'redactor',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1634cbfa54deecc7e05ab6773b4a1c49',
      'native_key' => 'redactor.autoresize',
      'filename' => 'modSystemSetting/e3066bc86497d5e07153f6f90afa04d3.vehicle',
      'namespace' => 'redactor',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c4a07f552113e6cb875b5041c5db067',
      'native_key' => 'redactor.cleanup',
      'filename' => 'modSystemSetting/3fe5eac4f818e974ce49f06f5c46a93d.vehicle',
      'namespace' => 'redactor',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c4c14351921755e35eb5962c4b7e80a',
      'native_key' => 'redactor.paragraphy',
      'filename' => 'modSystemSetting/4839c9aeba2011775508c036fd7440e7.vehicle',
      'namespace' => 'redactor',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34b024f498d540c39268ea71f0265045',
      'native_key' => 'redactor.convertLinks',
      'filename' => 'modSystemSetting/e611a4aa8636f055ed79fd8b88f6baaf.vehicle',
      'namespace' => 'redactor',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d052bce946ddc176f3ba7b6f74a34ce',
      'native_key' => 'redactor.convertDivs',
      'filename' => 'modSystemSetting/1f4685fd70d4b7c484e0fb8e23a21355.vehicle',
      'namespace' => 'redactor',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45b7b30c12ba73ddbac8c38d52f4706b',
      'native_key' => 'redactor.tabindex',
      'filename' => 'modSystemSetting/49473998f61f5e858e273fd6466a825d.vehicle',
      'namespace' => 'redactor',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83f570ad8e0275c19e14ad9c6453a8ff',
      'native_key' => 'redactor.minHeight',
      'filename' => 'modSystemSetting/9881b552c787d751ac8388d499cbea5c.vehicle',
      'namespace' => 'redactor',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2570eafc82c3aec86b50a39f3ed80732',
      'native_key' => 'redactor.colors',
      'filename' => 'modSystemSetting/6c055031d7fe7bd1a7536c436db0b432.vehicle',
      'namespace' => 'redactor',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63163ed3b780f4ec1416f15da55cab64',
      'native_key' => 'redactor.wym',
      'filename' => 'modSystemSetting/1688a201a98f027bc40701fc3d6dfa03.vehicle',
      'namespace' => 'redactor',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a172986b6d81504088aff44f086fe5c',
      'native_key' => 'redactor.mobile',
      'filename' => 'modSystemSetting/f3dc473a824bb989fb815a409f0a1f1b.vehicle',
      'namespace' => 'redactor',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd7d866b2d864b662aa55719756bd2dd',
      'native_key' => 'redactor.linkProtocol',
      'filename' => 'modSystemSetting/bc37a716f660588cb3d30b46744b05f4.vehicle',
      'namespace' => 'redactor',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c7e2bc4646ea37ff80144f6a8033217',
      'native_key' => 'redactor.placeholder',
      'filename' => 'modSystemSetting/b31aa6c674ce09c67f59ff9a9ec5ace5.vehicle',
      'namespace' => 'redactor',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdac7f5c0e8cedf6e32ffa5dbc0ef39c',
      'native_key' => 'redactor.linebreaks',
      'filename' => 'modSystemSetting/46687d29863effe33b17dfef7354bd68.vehicle',
      'namespace' => 'redactor',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ea09c66fb71743a89766534aafdab27',
      'native_key' => 'redactor.allowedTags',
      'filename' => 'modSystemSetting/f67bcde085ba704c86fbd2d5f40151f3.vehicle',
      'namespace' => 'redactor',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36174fe01562f2301cc214790aed6611',
      'native_key' => 'redactor.deniedTags',
      'filename' => 'modSystemSetting/b4658ea6c0e51449e4fe22665bcfd1f0.vehicle',
      'namespace' => 'redactor',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5119f350b5fd3ef5b597b67bcc2a3b9',
      'native_key' => 'redactor.linkEmail',
      'filename' => 'modSystemSetting/905436fd2baace3767980904e7b9be0c.vehicle',
      'namespace' => 'redactor',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e48e21be3a59904f5ff7083f86edde5c',
      'native_key' => 'redactor.linkAnchor',
      'filename' => 'modSystemSetting/1ac5ab46c7d20f06dcc5fb98355e2d09.vehicle',
      'namespace' => 'redactor',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43aff11e6db236d54b9bab1439356a69',
      'native_key' => 'redactor.visual',
      'filename' => 'modSystemSetting/2a3491fa8d106c3418c9e90277200dc0.vehicle',
      'namespace' => 'redactor',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28f9dc784e16750c27c76ba8cfe55e78',
      'native_key' => 'redactor.marginFloatLeft',
      'filename' => 'modSystemSetting/d3084aee3c487daecf3daece6c774dd5.vehicle',
      'namespace' => 'redactor',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a125f52025990afee2068da42b072c0',
      'native_key' => 'redactor.marginFloatRight',
      'filename' => 'modSystemSetting/dcca4ce8c0b6805f0937ddad4a133439.vehicle',
      'namespace' => 'redactor',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f45b5cb21cd979f29612b9bc8588166e',
      'native_key' => 'redactor.mediasource',
      'filename' => 'modSystemSetting/c0537ed385b0b8196c2763aa68e4052a.vehicle',
      'namespace' => 'redactor',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '860de673896b42ac68e604ce2babc37b',
      'native_key' => 'redactor.image_upload_path',
      'filename' => 'modSystemSetting/ce72acfbb76bc49e7887fecb458ac6d2.vehicle',
      'namespace' => 'redactor',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c2a028a17ff26f1417feac89fc3b46d',
      'native_key' => 'redactor.image_browse_path',
      'filename' => 'modSystemSetting/617b21e33178c12eeeb9409fc071ddd9.vehicle',
      'namespace' => 'redactor',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28470890c6a68c4b1c6e83ef48fe6606',
      'native_key' => 'redactor.file_upload_path',
      'filename' => 'modSystemSetting/c7b0d144d76badb48a85723b2586f253.vehicle',
      'namespace' => 'redactor',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '090975a724a1444b759f68215231bc73',
      'native_key' => 'redactor.file_browse_path',
      'filename' => 'modSystemSetting/3057d57997cdb197983ec3a8b2d2bc24.vehicle',
      'namespace' => 'redactor',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64ba08967d535d3c82ee8711ba7af6ba',
      'native_key' => 'redactor.browse_recursive',
      'filename' => 'modSystemSetting/396201c35d04881f25b207e58cb3b8b4.vehicle',
      'namespace' => 'redactor',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a252b6e2dc1ea7c0a376ab1326bb733',
      'native_key' => 'redactor.browse_files',
      'filename' => 'modSystemSetting/a76a15f9cc535b1137ec6745d32140f1.vehicle',
      'namespace' => 'redactor',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '155b5cb7b18dea6de2e0e2e7e80cb072',
      'native_key' => 'redactor.date_images',
      'filename' => 'modSystemSetting/d46f63f7e5a728d6df6530aacfe2cb74.vehicle',
      'namespace' => 'redactor',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9817ec450542890dbfa02a0783e0b4f3',
      'native_key' => 'redactor.date_files',
      'filename' => 'modSystemSetting/4f0aebfc8ee2cd73e4317593ca7e17be.vehicle',
      'namespace' => 'redactor',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd7f2d144fcce29dafc3ee4beff4ea72',
      'native_key' => 'redactor.searchImages',
      'filename' => 'modSystemSetting/217aadcc4fd5e8c944f245dc4d6610c7.vehicle',
      'namespace' => 'redactor',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b61877cd8ed9f69d199921d4fce12d9',
      'native_key' => 'redactor.typeahead.include_introtext',
      'filename' => 'modSystemSetting/e7afbc6fa7d8a5617e0b32dafd268161.vehicle',
      'namespace' => 'redactor',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '160e7e9e921c6e56c222548868d115c1',
      'native_key' => 'redactor.prefetch_ttl',
      'filename' => 'modSystemSetting/6030d937e1da9de21e5c9f9c0e47210d.vehicle',
      'namespace' => 'redactor',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1b84f94d7668588255a5c682cc39e44',
      'native_key' => 'redactor.linkResource',
      'filename' => 'modSystemSetting/39399ca94ef6b8f312f08ef25c9de4fd.vehicle',
      'namespace' => 'redactor',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e703cee0f7196177e2de5401e6cf8cb',
      'native_key' => 'redactor.cleanFileNames',
      'filename' => 'modSystemSetting/b8ee59bb8790fce1d7ad6430221a584c.vehicle',
      'namespace' => 'redactor',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f73d4c46ee130eb854fd7512fa2aae7',
      'native_key' => 'redactor.dynamicThumbs',
      'filename' => 'modSystemSetting/b7afac6984296c5888ac86a9b7e22949.vehicle',
      'namespace' => 'redactor',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '592bec010892b382762f04181b9c5849',
      'native_key' => 'redactor.displayImageNames',
      'filename' => 'modSystemSetting/5b8ee954d3983eab1511122188b6b19e.vehicle',
      'namespace' => 'redactor',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '845ffa65def23f09d47b61d46a4015e9',
      'native_key' => 'redactor.clipsJson',
      'filename' => 'modSystemSetting/9e332033fe5c87cc57097cedcfb07451.vehicle',
      'namespace' => 'redactor',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66e21f759dce9cdf1fa2fea02fef3ac8',
      'native_key' => 'redactor.stylesJson',
      'filename' => 'modSystemSetting/8ed4f6e6ba0c69e8424c5c5e1ea84ab9.vehicle',
      'namespace' => 'redactor',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b62a016fb08f39f16b1ba22c2a3f10af',
      'native_key' => 'redactor.additionalPlugins',
      'filename' => 'modSystemSetting/31a80f0322c3c1de826d35eee7dbeb7b.vehicle',
      'namespace' => 'redactor',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c2ae3d7a24cbfc7be919fb2f633fe69',
      'native_key' => 'redactor.dragUpload',
      'filename' => 'modSystemSetting/ae0edc45b727d37bf2ab8dbc9202a639.vehicle',
      'namespace' => 'redactor',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2607a36e912293a0c4fb7e8f0fa1ac3',
      'native_key' => 'redactor.convertImageLinks',
      'filename' => 'modSystemSetting/9dc928adc4110692836e1a0e25a0c8a8.vehicle',
      'namespace' => 'redactor',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92b61ab447fab5afc9e4b190c0534a96',
      'native_key' => 'redactor.convertVideoLinks',
      'filename' => 'modSystemSetting/da6845c4bf2a479b94c0104d3dd7cadf.vehicle',
      'namespace' => 'redactor',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21fb8ecce7af94133769f169ca4336a0',
      'native_key' => 'redactor.tabSpaces',
      'filename' => 'modSystemSetting/b44b70e05be20b2b78cee62e667b7a08.vehicle',
      'namespace' => 'redactor',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a89651dc2907b49339976372b501a0a8',
      'native_key' => 'redactor.removeEmptyTags',
      'filename' => 'modSystemSetting/96688b1d7efec15e5556855e78f6fc24.vehicle',
      'namespace' => 'redactor',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76be8b07fd0993a7c34eba49528583a0',
      'native_key' => 'redactor.sanitizePattern',
      'filename' => 'modSystemSetting/98b1befbca958eaac9ef5baa2a076ca0.vehicle',
      'namespace' => 'redactor',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d80a49d8e6e2bd6af982df9308c319b',
      'native_key' => 'redactor.sanitizeReplace',
      'filename' => 'modSystemSetting/b4d5d24ab152da5bb6a1cb6ae59530ff.vehicle',
      'namespace' => 'redactor',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca66517e90db48e3e81a1646de8f770c',
      'native_key' => 'redactor.linkSize',
      'filename' => 'modSystemSetting/db7128b8feba305c171a4ce0fa5f1559.vehicle',
      'namespace' => 'redactor',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f5b268c37eac3555486e7b2c35a5a9a',
      'native_key' => 'redactor.advAttrib',
      'filename' => 'modSystemSetting/4e8498a4ba2673ea38de316d8c75c9ba.vehicle',
      'namespace' => 'redactor',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85686f0610fbf9a1c37748e515cc70fd',
      'native_key' => 'redactor.linkNofollow',
      'filename' => 'modSystemSetting/6359422e84ea65d36c05c708e1bfc1b2.vehicle',
      'namespace' => 'redactor',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9fb34e02d506ad8a01cbb039ab932df',
      'native_key' => 'redactor.typewriter',
      'filename' => 'modSystemSetting/26623fe8a903697aa2d39ec8249d4254.vehicle',
      'namespace' => 'redactor',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '468a7f29f46c0a29eb4045851dd9396b',
      'native_key' => 'redactor.buttonsHideOnMobile',
      'filename' => 'modSystemSetting/12ebc61bd6453d6c20ef5b81d8181d13.vehicle',
      'namespace' => 'redactor',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca41653a5e00800c02d22009e29239f1',
      'native_key' => 'redactor.toolbarOverflow',
      'filename' => 'modSystemSetting/1977363602e60a7ac3f31ca5e818645d.vehicle',
      'namespace' => 'redactor',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a960422db83185b9e8efe8f5f40d03ef',
      'native_key' => 'redactor.cleanSpaces',
      'filename' => 'modSystemSetting/d5946c1c95fbb3dc340bb7c43973fb72.vehicle',
      'namespace' => 'redactor',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efd4080caaa7c10c969e804960e2ad51',
      'native_key' => 'redactor.shortcutsAdd',
      'filename' => 'modSystemSetting/113358473c9c33829cf3593f3da630cd.vehicle',
      'namespace' => 'redactor',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3cf5d9f41d5010267f4d68b0979714f1',
      'native_key' => 'redactor.commemorateRebecca',
      'filename' => 'modSystemSetting/07a8249c15eb594f50e2e92485aadfc3.vehicle',
      'namespace' => 'redactor',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cdae7283026d3aefd2121ab3f4bb643b',
      'native_key' => 'redactor.toolbarFixed',
      'filename' => 'modSystemSetting/798874f80a9b56ebe0428c7188b8724c.vehicle',
      'namespace' => 'redactor',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62a158011ad0f5e1ee06bc03530b233f',
      'native_key' => 'redactor.focus',
      'filename' => 'modSystemSetting/59feb1f32afc76d51295090185b83d1e.vehicle',
      'namespace' => 'redactor',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41e32d1b560f2ae039e3230da6e14d5b',
      'native_key' => 'redactor.focusEnd',
      'filename' => 'modSystemSetting/a48d50d05307bc0d789b42447e498233.vehicle',
      'namespace' => 'redactor',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78f2722b92030e9429d9bbd285ef6c65',
      'native_key' => 'redactor.scrollTarget',
      'filename' => 'modSystemSetting/574ac539637709633dc4338f1e27b0a8.vehicle',
      'namespace' => 'redactor',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82f48abc3d051efe01983babe95633f1',
      'native_key' => 'redactor.enterKey',
      'filename' => 'modSystemSetting/0d5cffe8bc44ee8bf5c2ee92b0bc34b4.vehicle',
      'namespace' => 'redactor',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9401a5526f6f8ce177ca036efa5c65a7',
      'native_key' => 'redactor.cleanStyleOnEnter',
      'filename' => 'modSystemSetting/38f46e80c45d62909b84a57401a99867.vehicle',
      'namespace' => 'redactor',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '586d779c80ed4bc892eed286c92e36e6',
      'native_key' => 'redactor.linkTooltip',
      'filename' => 'modSystemSetting/98e3720cda9eaf98666657480cef4d49.vehicle',
      'namespace' => 'redactor',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa29b8784db18ec29a0d5bca32111389',
      'native_key' => 'redactor.imageEditable',
      'filename' => 'modSystemSetting/d55ac751d7731b6431e218cbad676c82.vehicle',
      'namespace' => 'redactor',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36fb0fee0e77ed3eedf2cce3e305481e',
      'native_key' => 'redactor.imageResizable',
      'filename' => 'modSystemSetting/d92fa7aa26b1714a837b21628b942692.vehicle',
      'namespace' => 'redactor',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af7cb4794a260990c27bc9d68bad10c3',
      'native_key' => 'redactor.imageLink',
      'filename' => 'modSystemSetting/446dd7bb3e626b29b369a93e26b31098.vehicle',
      'namespace' => 'redactor',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ff84362b8188bb9530aba0850a732a2',
      'native_key' => 'redactor.imagePosition',
      'filename' => 'modSystemSetting/2662a07df203a564f76a6d0935ba0a4d.vehicle',
      'namespace' => 'redactor',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e0892bf53ec67414dc826f5922e6b77',
      'native_key' => 'redactor.buttonsHide',
      'filename' => 'modSystemSetting/4f3e642b0bc0a1377c818e6e1c1cc8bb.vehicle',
      'namespace' => 'redactor',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf84ea0aa80884dd21b962b969e9f4b2',
      'native_key' => 'redactor.formattingAdd',
      'filename' => 'modSystemSetting/a7740cde0d9ec4d54d598110003aadfc.vehicle',
      'namespace' => 'redactor',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36fbe166b0356f6903debc80f02ba799',
      'native_key' => 'redactor.tabifier',
      'filename' => 'modSystemSetting/799371114cbf756434e596d2f8cff6e0.vehicle',
      'namespace' => 'redactor',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9304d0e9da05eec38862925a2e078c3',
      'native_key' => 'redactor.replaceTags',
      'filename' => 'modSystemSetting/d5ae1b5342b27a788437f43490e89a15.vehicle',
      'namespace' => 'redactor',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3e7412c302477a55a85ba52daa75ffb',
      'native_key' => 'redactor.replaceStyles',
      'filename' => 'modSystemSetting/837662390d530a04b7deb8a4415f5e3f.vehicle',
      'namespace' => 'redactor',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7df6d7f6692538a26141e3861a4cccf',
      'native_key' => 'redactor.removeDataAttr',
      'filename' => 'modSystemSetting/418e4e779265a2c911b679656b49b7a0.vehicle',
      'namespace' => 'redactor',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d7dda5ab9c2fdf265ad1879abd405c2',
      'native_key' => 'redactor.removeAttr',
      'filename' => 'modSystemSetting/8847c816f82293c7a2e3e5241610cffb.vehicle',
      'namespace' => 'redactor',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74cf06b8fb161d053af92be205c05245',
      'native_key' => 'redactor.allowedAttr',
      'filename' => 'modSystemSetting/86811d25013918b76bb2ea7dfb8a6fcb.vehicle',
      'namespace' => 'redactor',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0fa661725c062df36e7caa53ff83453',
      'native_key' => 'redactor.dragImageUpload',
      'filename' => 'modSystemSetting/e7d95b5c5568746d60d26565e98e7247.vehicle',
      'namespace' => 'redactor',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'faabfdfe26c7c44f1386be9e9a55ceba',
      'native_key' => 'redactor.dragFileUpload',
      'filename' => 'modSystemSetting/35969980eee4e68eceb1c84899d7e7be.vehicle',
      'namespace' => 'redactor',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '069e0dc9f6f5db05693cbb0f40de675e',
      'native_key' => 'redactor.replaceDivs',
      'filename' => 'modSystemSetting/fa6ea08b242aeb606bdec45a03ac98d7.vehicle',
      'namespace' => 'redactor',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0cdc1a1086dfd56b24ed2daa4bb464b',
      'native_key' => 'redactor.preSpaces',
      'filename' => 'modSystemSetting/408a7fed39ffbaba95a5bf4fb4240754.vehicle',
      'namespace' => 'redactor',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b82bc0aa9eaecd19d9ee0b4d6dd5dab5',
      'native_key' => 'redactor.parse_parent_path',
      'filename' => 'modSystemSetting/2e6714201f46cb590abcc1c60d964063.vehicle',
      'namespace' => 'redactor',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1329d67ce5a77a28f23fb771532c3d12',
      'native_key' => 'redactor.parse_parent_path_height',
      'filename' => 'modSystemSetting/74f8222d304f55c9ce12bf72f0b712db.vehicle',
      'namespace' => 'redactor',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '783eef6bca310bc4dabff942afade03c',
      'native_key' => 'redactor.plugin_counter',
      'filename' => 'modSystemSetting/3ce1ac50f46f4680a24be7277f720080.vehicle',
      'namespace' => 'redactor',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f541ed2143eb098b9c50714c3bfc83e',
      'native_key' => 'redactor.plugin_fontcolor',
      'filename' => 'modSystemSetting/55c52dc2a8eb65dcea2270ef515c9887.vehicle',
      'namespace' => 'redactor',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eba52468700635998092a71b3b6e3448',
      'native_key' => 'redactor.plugin_fontfamily',
      'filename' => 'modSystemSetting/32ee02993ce1a5a7af377cc9d5e63ac7.vehicle',
      'namespace' => 'redactor',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '580375c7c0b8b1ecfa83dbdb1de1fdef',
      'native_key' => 'redactor.plugin_fontsize',
      'filename' => 'modSystemSetting/3a27642ad9138ecc2f9493f9f134cb5f.vehicle',
      'namespace' => 'redactor',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7b3ed2a2baa2f42bc368f6cef29f623',
      'native_key' => 'redactor.plugin_limiter',
      'filename' => 'modSystemSetting/665a0c71e97ede5c195480d78734d082.vehicle',
      'namespace' => 'redactor',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae37424d9029c1f9c268c4180e4fab42',
      'native_key' => 'redactor.plugin_table',
      'filename' => 'modSystemSetting/6cfc95161d95219a8e9f1511350830e2.vehicle',
      'namespace' => 'redactor',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81e8ddf51c30dc8d0504488b050c331e',
      'native_key' => 'redactor.plugin_textdirection',
      'filename' => 'modSystemSetting/7b32ae9bc144a031a8bce7a22233b81d.vehicle',
      'namespace' => 'redactor',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '803820f3381e602123b473664dd9368f',
      'native_key' => 'redactor.plugin_video',
      'filename' => 'modSystemSetting/ed2072bb809eb9f9bf8da21abdbd68d3.vehicle',
      'namespace' => 'redactor',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4199e84ce115687b7a4022fbaadef8ba',
      'native_key' => 'redactor.plugin_replacer',
      'filename' => 'modSystemSetting/abf051a68928711a726fd9a07d17dafe.vehicle',
      'namespace' => 'redactor',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e66fc68f1a18e6bc981498b3ba2fed78',
      'native_key' => 'redactor.plugin_syntax',
      'filename' => 'modSystemSetting/83ca742acb97415eef18c7710623ae63.vehicle',
      'namespace' => 'redactor',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdfa0e6751c5eca62dbe8f960f854e42',
      'native_key' => 'redactor.plugin_speek',
      'filename' => 'modSystemSetting/d91ea0f8b8ade42fd06c30963cec8b9c.vehicle',
      'namespace' => 'redactor',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3325861b6feb0e72094c5ba207a4b15',
      'native_key' => 'redactor.plugin_contrast',
      'filename' => 'modSystemSetting/206443b4103022e3e0c974fca7fbc4e8.vehicle',
      'namespace' => 'redactor',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '998f56358398d77dce5fa9a550b04c34',
      'native_key' => 'redactor.plugin_zoom',
      'filename' => 'modSystemSetting/106d859a7ced0ecce8eb3db5eaab6e48.vehicle',
      'namespace' => 'redactor',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7aeb414f63e4c20311bdaab33208336',
      'native_key' => 'redactor.plugin_download',
      'filename' => 'modSystemSetting/3a433142df50a61f4aef0b0a526696f0.vehicle',
      'namespace' => 'redactor',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '239b3ca285a57c15a4a93f921dda775a',
      'native_key' => 'redactor.speechPitch',
      'filename' => 'modSystemSetting/370983c6611ce4ada1748aca74e44b2b.vehicle',
      'namespace' => 'redactor',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c03c30f558f4652617100f203003e7cf',
      'native_key' => 'redactor.speechRate',
      'filename' => 'modSystemSetting/74acb97a00651292fb3b2bce6e5397ee.vehicle',
      'namespace' => 'redactor',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70b2f4b2f9502f4edfcdc14ff68a5110',
      'native_key' => 'redactor.speechVoice',
      'filename' => 'modSystemSetting/62de29fad205384c0e353bc2709d7ad3.vehicle',
      'namespace' => 'redactor',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9573cb8823304f4239fc353e2a7bc6e3',
      'native_key' => 'redactor.speechVolume',
      'filename' => 'modSystemSetting/9c92b443e14c447a7791043ac64a22ab.vehicle',
      'namespace' => 'redactor',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3784dd8db841b294be3a21a7ba90fa2',
      'native_key' => 'redactor.syntax_aceMode',
      'filename' => 'modSystemSetting/f9bf88f20216cae502ccddbaac264f3e.vehicle',
      'namespace' => 'redactor',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3775e586b24d5d9fb4349464db000ea8',
      'native_key' => 'redactor.syntax_aceTheme',
      'filename' => 'modSystemSetting/ee7366b1b2a66b86e86d82ebfdd9eed0.vehicle',
      'namespace' => 'redactor',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42756e6cff9e4293bfa6379672eb18ef',
      'native_key' => 'redactor.counterWPM',
      'filename' => 'modSystemSetting/c311a54bb0d7ab29df523a40bf9712bc.vehicle',
      'namespace' => 'redactor',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2077f5bd38dc6e40c9c1e0f26d0fbc8c',
      'native_key' => 'redactor.0',
      'filename' => 'modSystemSetting/0924d4108b1a78a01346a64b8d8eea15.vehicle',
      'namespace' => 'redactor',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '57646db506af8be1f8a9e4038c59e2e4',
      'native_key' => '57646db506af8be1f8a9e4038c59e2e4',
      'filename' => 'xPDOScriptVehicle/8ffb90d87022771b2bc9c55570546779.vehicle',
      'namespace' => 'redactor',
    ),
  ),
);