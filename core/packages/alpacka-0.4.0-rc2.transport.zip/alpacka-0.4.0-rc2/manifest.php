<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => 'Alpacka contains common functionality that is shared between MODX packages developed by modmore. Those other packages require Alpacka to be installed, so it is automatically installed for you when installing such a package.

Packages that depend on Alpacka include:

- ContentBlocks
- Redactor
- MoreGallery

Other packages, including third party packages not developed by modmore, may also depend on Alpacka.
',
    'license' => 'The MIT License (MIT)
Copyright (c) 2016 modmore, a registered brand of Mark Hamstra Web Development

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
',
    'changelog' => '++ Alpaca 0.4.0-rc2
++ Released on 2016-08-04
+++++++++++++++++++++++++
- Fix fatal errors on installs that have a renamed core folder

++ Alpaca 0.4.0-rc1
++ Released on 2016-08-01
+++++++++++++++++++++++++
- Now available as a MODX Extra (transport package) for shared installations.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c72052a45b1af879c3a2099ecb420926',
      'native_key' => 'alpacka',
      'filename' => 'modNamespace/be739d32bfe40ff6108fad0c9d65d0e0.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '4acd912bc7c9634ccc4407f7fa7bd723',
      'native_key' => '4acd912bc7c9634ccc4407f7fa7bd723',
      'filename' => 'xPDOFileVehicle/963d3c3056f828d405ad08130e23c23c.vehicle',
    ),
  ),
);