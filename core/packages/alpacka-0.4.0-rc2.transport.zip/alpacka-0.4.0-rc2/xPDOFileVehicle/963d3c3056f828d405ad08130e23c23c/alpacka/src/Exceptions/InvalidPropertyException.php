<?php

namespace modmore\Alpacka\Exceptions;

class InvalidPropertyException extends \Exception {

}