<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '15834087fe0ecba3116c6c5f50af429e',
      'native_key' => 'core',
      'filename' => 'modNamespace/8044def29d1b72ddd08c287994d42be4.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '29d360b49ef0d8d66c2a37cbe6d91c63',
      'native_key' => 1,
      'filename' => 'modWorkspace/7323cce24cf4ee58de9ced415b5febd7.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'e4309490f76353e70ec2f7e8918d499c',
      'native_key' => 1,
      'filename' => 'modTransportProvider/d429a9330a0815c6df96e5f57382698e.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f0abb9a9d2b9c199ed7d67c0e47daea6',
      'native_key' => 'topnav',
      'filename' => 'modMenu/347f925809befe16c7f9c28bff2499f1.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4f08249c2b1acc68bfd4835c3238dd78',
      'native_key' => 'usernav',
      'filename' => 'modMenu/5f8b19b2815c8b7461876d51bee932e9.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c4bbc98f72f5b77fd973855cc3d9a852',
      'native_key' => 1,
      'filename' => 'modContentType/367c0dd24a0b19b3bb3dee150d79fcb0.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a99741836137e9d17dc91e73b0e34cfa',
      'native_key' => 2,
      'filename' => 'modContentType/a5e04f6335648a10a191899c344ce597.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '35db1fb6ea00f3c231d4e61e63166bb7',
      'native_key' => 3,
      'filename' => 'modContentType/129b45826bc19bce5360f5566f7bcc6c.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b39abc3ebb0b71745fe4af7fb767a981',
      'native_key' => 4,
      'filename' => 'modContentType/465f99d64e60b8578538fbf5b90c6123.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '80f897f1d77e54044d2a40e37175d511',
      'native_key' => 5,
      'filename' => 'modContentType/0a63b19ecaca2bf92a4dde1b47caeccb.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'ca32486e2d567b86f45c4394686d55f7',
      'native_key' => 6,
      'filename' => 'modContentType/36d82a9174e0aa15e4a2c4077fc3403e.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '909e22f3cfeed5ef5aa37f63d23c7dfe',
      'native_key' => 7,
      'filename' => 'modContentType/d73be964fdc6b25af66bcfc1c8f80bd7.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c0eecd7f5d3c659c60777261cfedc378',
      'native_key' => 8,
      'filename' => 'modContentType/e4a96c39c76be19e7cadaf985ebc04ac.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a556d055cf213b4f57eaea0af1f1550c',
      'native_key' => NULL,
      'filename' => 'modClassMap/1987b59c6c7ad949ab28bfb35bac7f03.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '8ad304b2603074181e795bdae1a25313',
      'native_key' => NULL,
      'filename' => 'modClassMap/3a8016a9c53721809bb10929006d5607.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '885d1cbee13a6444fb20844827c4f498',
      'native_key' => NULL,
      'filename' => 'modClassMap/88798844f18cd95a66084835f99af51b.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9ea9723989e9d1b4c1174bf083619a6c',
      'native_key' => NULL,
      'filename' => 'modClassMap/2a0d5c4c0c3bda83efd7c25d9e29b548.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '484b338f7bed1d44df053df357658ca9',
      'native_key' => NULL,
      'filename' => 'modClassMap/66a99c7a3f52891c29d06153b82cf3f1.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '554c49a83479a87d2cfa2a54ca4a609d',
      'native_key' => NULL,
      'filename' => 'modClassMap/035001c4269b72575675fbfea5632961.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '80f79f0d85bcb966368c4ff893684565',
      'native_key' => NULL,
      'filename' => 'modClassMap/0db52f6ad2024fb063bd9c798484e687.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '5e55e4e0bf307198349ece772123d3a0',
      'native_key' => NULL,
      'filename' => 'modClassMap/51a184a401be6baa99c6ed82a787973f.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '397328b163b7184284cecc1ff8a777c4',
      'native_key' => NULL,
      'filename' => 'modClassMap/ea3dbc6a0ee69a9853e4f7025b512f33.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb6b7c5000886159f5e73aad9917a148',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/11a9d4c745f8f7df8866880751869a40.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14d2b8743a25fd2a51b72fca76e28e5d',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/0e5df1f33b7472f1d48cb8cd8801e872.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4dad6653f6b7b06f03abb7d20489503b',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/efa075a5763b43a1766508bb938f11cb.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76e7eaabf8f446441b035838f1eec8c6',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/2708967214d2ef2d530f77424f968954.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88e5b0b21689a726eada0f794f3d4036',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/461aa429b0b005e297ff32ed7c1733c3.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5dbd40ace2f0bfa7065f80d6fb94a433',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/cc388668c54ecc7bc300f19737594092.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '010ee3340328015f7431f9702208ec68',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/b658bb8e2d88d52ec11e55031e2b9b27.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3baadfbd8b03af2b163b73ec2770c9b',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/3a96cdfa57f43dcfb37f551e1baf7ca1.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '696ccbf2ed293b319f1b492057041843',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/878624b452ab5062aa104878c076a028.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dcdc453449d03cf007c540b9be928ffa',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/ffef6379558872eecf30e0f3fca17c8d.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5cbbf28d821a9f019b15cce14499d655',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/6858603207f2f161a5e058f30dc90be7.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6179983f2961ac2f8757a9e4b399c63e',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/82a708ae3fd6897922c7b41c49fef0d9.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf6c46c92ccf578a5fd78c916c069eb1',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/8e41c05b70dc122a3645ff16c68dc502.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8fbf04e522efcf260f05a668c1534986',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/7806063581b5cd6ccd27bfc828a47c2e.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f50226fc9c242381ce0ae2e238aa646a',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/71183e6965983fa61af5b72206301be9.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '217514564439deaf65446db9afd72b36',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/f6c407a8334bb42d9c72410a051b8fbc.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06dbe99ea300df6526d112c5c129359c',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/d6a820ea55f16735763fed4c0af5edb9.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'edc52efe6c07c8ef9bb56989020b7fc6',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/4f0ea3041d64b165591bcfa9451b2bed.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2aded22be349a7913056da5644d397fd',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/d8c5596a09846e5335e3c16edfbe218a.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f1522347a0c8d88e3677e25f1375bea0',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/3037ecde782cda39254fed96a31b5217.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c51e8a5b2f19491932cf2b16e055c691',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/a9c93038d9da2f91f061531d49c4b87c.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3997c8b43d108087f7c042d579b86c8',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/ea9fd8625c7791756bd1f4cd06126db5.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa32c1bba742ef68390349615661d6d2',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/ab95f7c4bd9c1a4db3f20920a926b4bf.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f46d3d5de6942ea08d58cbf090b01195',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/a3ac1679bf8c8c9de467182b2832eb71.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbe8de0cb6e282e219938ce67a197122',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/a64080b0de5a16e828acb81b574b7268.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce2edb3f18db60e09c5c8e7ef8f96e40',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/ab0a0ac1d3921655a5b04bb350a1adf3.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78228b76bfd7a7593eec541f703d9872',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/8cf0524321953a0dc76bf963e4e3ebea.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c465034953144b2b99d54501fd98cc21',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/dd2dce3d4506c7064f80187ce67a35fc.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d12e476e862cc96f215844b4a6355f5',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/1a8f5099657ecc30f78dbec6c99298fc.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e776e6b7c765ca81633d6c156fc8f174',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/66413adeffc218fb6c1bc90894ba9dc2.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '271aef854efbb703c571ae58a618d9cf',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/3d6e190a225c65b4e519db3f27f330ca.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '078a11ff7da5076b7ad61dd74a6bb772',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/a07482a8b59d6fa9849f397e0088bca7.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94da26aa00baa7e595ac16b1b690cb17',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/29e7201356d794703434a008e74b7b08.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19e9570b6a1174bbb93c1794e9268ff0',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/9d618ad6a2c507f38d238ea61dbba329.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31fbf58063f7ca0b57a2f76eaca26f4b',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/1582c78761e9531a51576705f909b6aa.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96f87214fac766851cc490127d4bebc1',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/715ab19b6029830dec483aa825c43f69.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2bb832ca77c45e107f9fdaf526520cb',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/6f64d51955c1377dad2ad48068f5bed6.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb5e58df3040cb0a03206a068650f24c',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/c3cc8d63044121da3bde1010bbb9a74a.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0570c6c187188fa7a9adf5ef89f47d5f',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/ebf440d82c2a63583f47dc6aeda05ae2.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b78ffab38cc9621d9dcef897edefde22',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/5dad3773007d887354c9a2d286932563.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a57007e1c386adb4841dedcb5e199a8',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/ad732861f5939e8299a6e12019c23a2d.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2711852557bf56e34ea5110b59db5fd',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/2857af47520c3536186ec62eaf8f3ed6.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb30fbe0ea45b60f65ac90df245b4fc9',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/ca7010a8ba009f1a952ac7ceac5e9f3f.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1bf98198ab6620e19948a21a4aaa7eb5',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/7b3a1953793d22c7b31451149acd26ac.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ee02048d7a126ed4d4c819ad0c47f911',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/7008a9281fb648ed57b9caa562e5e5f6.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d5e76d0de49ff86f683592aaf42d485',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/18d25aa0775d9a63585538768f610894.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c22989a60e80d306b8adefe8ff48f847',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/1179978aca4b76025e36341699a882c4.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a965599481f3600190aacd23a27c0032',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/1b38f5ec3e2bf21658d565281b4ca272.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b25f4eff35c978208d2b06d8cc29f7d1',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/7c4285f1eb07668dbc3e3a84d9451883.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e01f36ec48864339b4f7660c8f1c161',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/6760391462f677982ab1bb89d0485b21.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3aa0199861dd27e55def6368cdb8a64d',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/75da736aeecb6593e9dc3809c563bcaf.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a309b1992f6a2306633a4417b347f71e',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/9873f5bb3e24616bbf3b4aeae16683a7.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84f11065f73d399d5c9ce3e935ef7ff9',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/413e12b5522df263da2a24df25ee2400.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b5a3b323998b1e9ab364a13c1e69846',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/96b5d7f76434aca114d9b0139bd06610.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2bdbdd10468489fdb18e85fd436187cc',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/6d3bb0019aaed71bf67521fd608d8708.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f51496ad1274ddb8a382e9850ada9c6',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/0204bd7aaac8662701a0a2de9bb528dc.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7cd41f1bd89a78f4137826b63f6cdf2',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/cd5591bc7c06fbb0e988bce11d0d352d.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e20b8d13aa2bcc8614f9c969128da19',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/b1c98e3fb3dec1440e7cc273fd667056.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6cff75dbe5f2e264a5d8688819b17f9',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/1163b5eb985dddf7c5d4c8f9a6ca1182.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa94fbad578054da8aeb472ad04c523b',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/595bfa0073673cdc21c52bc5b4942bba.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42e82aea9c25fa4abc1138fbd567dbcb',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/33c450251cbfdf89954e7c6841ae1704.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d60cfd2ac9d6e6a9880b8e31e9e98b5',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/3b2b4f82e555c11841f278bea4ca73a5.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f86c0d694d0907c75d223c5053108633',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/ee12d186162e7c870b58f6a64232c3ba.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1950056e72f1aca8a4f978db3a79aff',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/a3adaa43708020a28641373f9b0ed7d6.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '562098a79b7cb3b2617e43bdafe544cf',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/6951189f9485f48e6c314a0cbcb0b20a.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '879b2b120b2a179fe63ba752f0405294',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/320d4880d042ffb8bf8db83f5ce00ff4.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8286665094afc36eb4e3d824306307e',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/0700993f8e5caabecd17f89fd947fa98.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d23389e39b346a4cb08e24f1fdbf29f',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/4faa31370d5ea824ea4d5798cad1e7c6.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '453faf82d416c9d261fbb511eda5d260',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/b7732b6216d4e6487fc203fabc20bbed.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '194e1000be57fe2a37f948380a484a26',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/f09e1c0906c4afe4080ba3fd7c971162.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '475ca7948bc43f6a91368dd1b00be4ff',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/72881868acd86d2239deb977358a709e.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d87548bb1833c97b1c339f3837ac54d',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/67078c8cc431c37f71f99d4169137f7b.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f4a20f5a95fe1a93bf7ed9ce52eec393',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/606cfa756b424db64b67498952c2b540.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7c98afb83d90e09f837c54a5a8c35f8',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/c4b6615f718a4321a1a962c71d1dd15d.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '79b6fbd8e6a5a5a96466facf90b7a52b',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/cc23f10d66f4747ceb9365f9139899a4.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7f96fced2d8ccaeee02c69a04ae62f2',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/c44e5e1e85bad33d45e91f35d3a4c870.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1178fd3192c3e361bc67bc10cbdce912',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/9aa14204113329d8830fa14a18ddff0a.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dfb455d54f3fd05f1c965575eddd2b28',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/51e496772b4deb03ba90b664b94903c3.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aed4da828180b3de66226ee22648227e',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/627c6a4511f92cd514d26692a34326f3.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bdb34015fbdd18e57dba0ebf10479b6d',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/a859dc1f9b58add8f53e428dd1b32be7.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f833dc4585346c48235a9ea24b0c9bbf',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/dbf8688cd3381f8c135ce9cd8f6679b8.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07bc8ed68b42933bcf6501c5ed037a11',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/f738355993c1ec431f27c4b71f6ef67b.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97da9441dd9803e83f5a7f6d6355e36b',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/6f567e4d080023503db9009071c7dd0c.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '20d3259db6a921e805488d7f184bb2fa',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/e7fbd34db16c85a9e08fb2d33716923a.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c080e948b215ee9658ce3431c9a0601',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/764501498bd4a7421aaaba478cdbbc1b.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ca2aa3f556d85e82415e774e147423a',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/3d03204d26e44fcfdff3eac5a3699ac9.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ed94277f82f05a9bb560e0bbe338376',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/72c6531068dd8e0710270c2ff3e287fc.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec094346b9117ec58d923f589c5a5349',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/a69681b9be2038427cd38b9637a8f152.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d3736c2fb28c0721f1ef9084e732449',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/c837c6cf9f5c13322ea6f63f410208b2.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94b7365d5839457e7bd9efdeaae10cfa',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/a56e1ebfbc7778c95cff9d2301f57a80.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a233139d5c781867cfc3b8d83b8e9ea',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/e7aa3b0cde3d7160915eceef829790b2.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b4f1480b9f55c44891c9b8fc2582237',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/1044eb38c2318a0f57c1e17ec79ada37.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '302e1e1b10984f203feecc76548d20a3',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/81c4e1ec505fa0d6ae0aa082ac5ab9e4.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef6d133492b2270c8b3d458de14403aa',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/e4dd70463e5bf0f89cc4f170ad7a46bb.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39c16c86856cfc44ba6f20adee3330e9',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/0d5094966ec5b0ac7061b289b642cdfc.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6efe9f5e84b9a51e21e0d4597ef4b8ef',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/493cec0fc8b75709becd84e90c084a0c.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '128ace8dc4b7d08182d6dbefe210c376',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/a9dc62c03172515865ad22815c5616cf.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa2845fcc7ec73d3cc1abd6fe6506603',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/8231b1c4d99e114ab97c29c59c1405c1.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ad5dc010259b9cbb803dd00aa0f755f',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/eb207185a5a07abad94a4f891707aa17.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '191c2a33a41f225a673f8a66ef3161f1',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/1865de55afac146c8806538f9eaca8c4.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1f09d8ad3d8bb4452df0acea2fdc22b',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/840c8b90b92c3a7f7377865c06709ebb.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b46d7ae6d829de56d49c0faaa9216b2a',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/240d37682bbae114ce56d44ee90fefde.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4179c6d534dd313ac7b612b02fa67196',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/8fed00c290d105f8fa6df385d1623860.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a486303ef72bec9c5926173e0280306c',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/e458077df6b8e00e9af311b103ae5c88.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dfb52c514ef625a2266491d031667075',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/d57baff1289b918933895e4540a1b93f.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b400c7b004b114b91870af593729dc1',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/366a2f09b428ae00f2b48d13fa935207.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf3924cf2d71f29816d0943dd4b4b7da',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/b8190e5f69f29fe6dafee835b6488761.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c23a2d9e231bab4050521925620af6e4',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/98ba165aa70737c4078bfb7df106148d.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6dd0fbabf20e7b07ddbcfe508fb33757',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/a7b1c26689189a478dfa4b81ee1f4d93.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '323419e3d226de957cc64785b243d04d',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/83d6b86a80138df148dbbe5970a53843.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36e7abd6053ac9a7af123ddc6480ecf1',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/bd697c5086dec8d606e6fa28a0d079c8.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0da5cc346a17680485ca8f640878215',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/b0d6b58700451020fd7178c495841f94.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '34851867091861d76749399be4f2730e',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/f43d87f24eeed69b2c88f7014e21b4c6.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18ba62b2c935cafe713daa78d081dacc',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/aef4a1010d697ad3c63f03e8d8650248.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1421d69524a99dfc3c229d670d9b48b',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/c5c203ee970c1e3d5b6432e7421a6a74.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec3a9ac6dc1d526b7bc4882c0da4e80c',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/f44228ba6138aba51c8060aae390e481.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69f75a0eff09dc6c66d2a567f0fc4c04',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/580cb269203bd3cf612142c36075378d.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e017df41d0cec80ba6e712d8f8c36088',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/20784949e77c5d523057a3198f1539fc.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83eb63c0ab5128932953612a2d88fad9',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/3d548918e715c4001224c4e5661380f5.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f3123d5014a111c31fe95f557854bb8c',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/6ec55951829c6bb7b52eb85d6a4aabfc.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45f6fe04abcfd4a809cdf05b82492b7b',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/78e60053dcae8261cdf066b36fbd93f5.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5f26e7927e445db6a73600fe20cf2ba',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/f26398618fd090c81e0c43b22f6ed3d5.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ea481248a2f337740366481275e9ff8',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/37c197607e986651e8c4b6cb591d9f74.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '825a430cb587af04a1a1dc3a01e42a7d',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/99b8666758d39fa4e91f4637646cc6ca.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78c42e1612440c49f594ea68829f0272',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/d8e182c3a6ddbf5cf71131c3309de236.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '637c021bb45baa414e9024fbe6890f74',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/71cc57d625e2aa7e131090f696d76cbe.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c92663e5a8a69640b68c6803ce4763e',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/8e7f3ec0eac234b21745eec0ed149c59.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8669a004b661d0712859594e78f3880a',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/8451c4d6a517657c6e8b5ac8becce3db.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22f304c3622a8e3dea8954a4acea2a2d',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/4b54140880e8210571850ecbf844b77f.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3871dac46d81d5ba119c6ab85af15ef',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/7ea030878618aae8407045740f962327.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c877355fcb4d5ba4f8f68513eb160803',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/dca220036f5b632259c0df48c5510353.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0710baa43c950edeb35463e30440ec35',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/954429357c5224f127ccbdaca39ad725.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd79f790267c6c0af7eb99ee5486cf1a7',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/8471b9945164a61b391343b66bfa8ccd.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28c9aadbfcd77569e6e4b02b6a2e0882',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/dfd5761195ac98eff89fdd4e9056d3ee.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88d0535e32ba868f538260d9ff8fa59c',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/52cde0c097e8faae1ac7ea82d60b816b.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83ea57ec78f3865c1c7ec8fd4a57da30',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/55dd2357f6b95ec088a42185668dbb17.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa6f386f2c42b5461c60784ff339fd1e',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/111dc3053457f9f806a924d26d88e4f9.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ebbe49b9c1d3994f17abbed837b4a35a',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/9b29780f08a7d1b4a427f277d78068ef.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd471036ca7c31bcceeedc31ea041c1e3',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/f9937a89ac9009ab0a12fdcb5e89f802.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2fd852ac7405c7ad71605bd16fe5c410',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/9a2fc217f724afd0bed0f6a50be1c00e.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80c064ec4b569c34be0894a8f9ef63e5',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/4c3c0b9a48cdbfe6da9796bee3fe9523.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7fdd06e2985648f04038cdea2b42f680',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/76bd035b2e6ec4b38ca5c8017804f9a0.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4b8eefdf489bf81273aaabea9d57f3b',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/4215bb6cc07039be0e0a5b8df068891c.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5eab164501b7f45326d6a727a68d66a2',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/fad3e7f90e44681e1896b256259887d0.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '389a20a7b9ee16f8f503b34e93a485d8',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/ad4a54286b5664a7a06da2f9146fb64c.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '512355d7106eaa8949e463b6090f6dbd',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/a8995562c665aae59664c39c619c9cbd.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e8e3cac423880b347cd93488cc96ccd',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/bfd32ca3add7a3ead77e4aaf2b3fcc17.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '172c8d1676a1ed65bb486916c2b5026d',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/c3f9b4c489a073e91653d1ff26c62537.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a2ff6911e8157f72d817f0b4ff076ac',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/d8acd0b50ef732c305631dbaffc7e5bb.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8e1d333d690a12d285633fc5e1cc5d3',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/3356651f0c251bf51c5cf0fa877912af.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '109d5eef8d6699a8802686b6001a3fd4',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/7630086af83e8375cc58e07414d60a1b.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de2ca6fe67d53ae70b472398838e1f99',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/d002a8994f4c7366d482ecb54d5477b6.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0e4d0caec2f6f8ea79f56b91ff4173f',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/9ec6cf889cdd00f8de25174552d8fcfb.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a1bee32972f4ee24a867c413623466a',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/19742a1b0d71240cde964706744d0e20.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ab496e80353c8c1f7e35a203d3e061a',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/1c79e537ab925854f06575026fa9f26b.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c87583f55237b8b2b56ee6eae235bc70',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/06ccf7399b46f4da807dbb3a3397df63.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67b62113badd465d048e81aabeca009b',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/fc0c6cb05734081d4c007801ea1d271c.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40dc511ccfe66335cd28b234f5291459',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/403a1c865caf7a7153277edcb428be4c.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf757861591326a1b303664918f5a15d',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/10d5300668d0c730c7ad92d01aa4f788.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8e8373eda31c113b31df0463515b5b4',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/7bbf02cbe2f49dc5cd154b38ccb4cbad.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb96174c6c63f42a399510d76c8ced58',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/0a47ad1eb31471cdd2b035ce0523c1c0.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a442c91c0ed634936c0ce8643ed953d',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/e681a04f46de874c8f2969c0046abace.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c058508754d7d7ab330b325fee4d92c2',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/883009f2cd53f7e5ac57ab3ca882fa67.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '265da79ebce12b16201ca4590f4b9c4f',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/061215781263fbcfafde48d926d7fc84.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '760a9b05c20bf61c1109a94d8137840d',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/acc768fdbc82019698a82413a63f7d3b.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '948fccb498015c99338f75cc52282dd2',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/b5d10148df06a7c3d4e5aeb8b21dc19e.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '61057a6d02702290bcf59ae5868ffef1',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/9988f377dc07fa2cb76cfcc72af207f9.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5944457db14a4638178a42868ff1d324',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/c19aacbb68420d5bd54244861276b7df.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b43092a9b034c6025c765b27d5ab397',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/d3a9cb4217a7b95fd15eb07ba25565d1.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '136163fed3d2faa21b4bef3ee74f8357',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/797286a6a5307ddfa1948b865bb3727b.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1fb1f1bed93642b321914fd16854a115',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/bd43c4c65ac8e9a6afdd27adcb713e6f.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b9de3128e88d79677c4ee6cee4748b0',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/e031aa521c7841c867d10498a48fda2e.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd11b98b8d0cf93b39bef5ee001991bd',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/1b8b9ea25d6315d1f7bd9f1d05825000.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8720836801778f5ebc2abd828108efdb',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/fdbe9273f09194741679a870f4cef09a.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5d711a2c0398c699ab6fc079c73c7ec',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/4c951ab3fa24ad0121699b5a63e6451c.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cab238624734df764fe695a77e28ffc1',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/64cad8fb695e1f9ceb6bfd27c4182576.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80c7d8f25f9fa948b5f5162996939766',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/f9ccd8bb57ce94a3e58a63ed545cb24a.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '782e37cc5c7c72b3b31e4a001e9befe4',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/8ab508a5e2ad1912d79147b342da3dc1.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '825a50cda671313a8218b9c79fcacc30',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/276af482981911a951bb6fbfc4dc2a59.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8acff714476f5282cf556fd020f6a23b',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/e93a3d9aca769f3339f4018723e5ca32.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5196e3f89e1d46b52fa401e1383a4d21',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/13545b25cae456ca3fb5491b95a46c56.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94158ac33f94a277b9b210529205cf97',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/c8052e87088b008a14c60656701252f4.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71c063ecab939aa52032e728d4c60385',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/d4ca1a9acc81254f51a967b7c97d865f.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '173866bf2450c0242c1fb387284bb6eb',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/26407b3a0349506fc6f3635c2b8acd85.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7b7289b8a8e7a842349a7c562d690a7',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/4bfd003e329143ba5c03ef05fa202a6a.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdaf0130e4609dd6fdd27eaccb60ae77',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/638403674b3e7a32c64f48bf6e3dfff6.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ad8a3896b580a29af531c378a8c97c3',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/02c1c0ca5f46285856675eff228ea784.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '357bccfe542b071ea82fe35d0c5982ec',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/addb915d42401fce410aadee0d8a7895.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a054aa0dc72a959a9504ab475a8623aa',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/a1a24ea6946e266907a23f3e2f8b522c.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a635f7122cd6a44c11bee8b8d290886',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/52efd9a7110d8da6c11dc2597595aae5.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57cbdc9bd72e7a27cb4889ec5a1fd845',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/82bb13840e60538d44c11542a86d70a7.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f1be74e6a43d6e5b09c151397efef57',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/45208f72210fe958174c5e713a9e2b91.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01bf31e67c704a24413545d34253e4a3',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/9e6629e2592fcd89ec1c8ad4fd44019b.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7709184c451fab7d39bc1e9f034250bd',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/3f9281f380ce0b3916b0e43f88cfb7ad.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6f8718baf66d7726884ccb2b0ce6cb7',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/8b53896e7f76845d190067ecc6e0c7c0.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7f31934daf3a2fdc9cc212e6dcbfb22',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/b0b225b777fd20a0e821a92ec0152cbd.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5483b7473cf6f21f48b2668aa3039130',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/2b4ba96bd378d35f523cfe5704f50f90.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6737fd4a1ee435d8049d6cec8c2d15f',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/89fc6150ac2dd03a9e7716880bf970b0.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '295b9581aee7a767929dbc14589e2eb9',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/3dbd72a4db164f96345f223b3c1e5833.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e0750aaa892f322b121313242266ae6',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/3365b48d997614084d69fb8d8178dad7.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '802c3703e79b7e9c3c170fcbfe896210',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/9e56ecacb48c72168d555e559b1fc658.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d4b556abae7b5194c4401f238e3f8fc',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/a4fcb40e7fd54840cfd8fee192b5699a.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '575fb16aeb59c5550ec40b4e5b715a3c',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/1e32563e080e00786d8760966b86f094.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31d1d5f78f47772116d667ebb26e7680',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/621f530aa4b8d6044064f8e9182b577b.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '380831f3f0f5f2d90fa6b257034176e0',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/072c6aa001c3b88631f7083387404ea5.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27ed7ad7a37c541f4a7812bc015b18ca',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/30b9e44a0481b9b92d2472a36db1a0e9.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67cb9823f9942391e320d9c2d2693828',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/a47871c0d1eb15ad5ad4ab9133688ef6.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f68ed07a00d95472fd1c10863f5183fb',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/aafb8a6b864759b1b715f4f8501af32e.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '842c31be831ade55fd17b660feb57402',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/4a28d7e10031f527aec84df975690794.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d6aaf6c1e11e56174a0dc5efcd810f0',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/d6445af4b8b2ec153e9c7380e03013cd.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f3fe33becf735ebb644f2a7128d944f',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/9b48af3ae9a21fc0e6739f41c733c8a4.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a434b9195671d1580b311d5f253c75e0',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/d6d420cf458cea9bfbdd2918e054c864.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c933b072d1378dc3c70de8979afcb942',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/2c970d9370803220e83af9777d71d9bd.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92e521e5e7e4522b8536f8d46885a56c',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/2ebfda83d72b7d2d8b971da59adb98f7.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7151527fe70ef82ac81b19d22caf302',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/ddabcfcbe6c508ce0cc65c6b19477a65.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '094eb79ee5371fb5e5289708c7386f03',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/09e2f1caa07c47c708e2be0112e5db3f.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15db9b2f7aaf57e9011028a3bf24f24c',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/0c4266bc000d2a3b273228b2e03c6dca.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b137747a6cf353f397e34fc913bfd01',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/3755f7b0d235f3ab1cfc20061891a176.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8dd6f3d1bbbddba87c7c4222e6637188',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/9fda35dc937d1dba882e1eae217e2d65.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab419896b7e22e3481acae30b52bc081',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/da1458192eeb66224b160fa6b1951460.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd299bfdfe0a7df01bb8e16c7ca55c793',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/370b88b3143785579673c7a31b947557.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd0bf846d64049f837b972dcea543987',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/c703b9c59256d657f19e9bcd8036b804.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4aae3a1b491e0f0960e0f2d3e9ab303b',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/a009d061bd313d18ab17e3aae16fb1f2.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c64f0c8f6315510630b895f5272bbbca',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/b2c5dbd0f096b570ce0ea94a9007ae0f.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd772ee28d73e466518bf59a6b18840b2',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/9f39236e0873ca8ad984bc537260d0c5.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3bc3f0df693c83ed85db32b7e3c269a8',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/8afec7e3198f32019f6441fb37371da5.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df2cfa6290043ae0bab167c91a535e1f',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/6431b931f8089ec9d5ac9d25be4e8681.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02de188bd2adf54ce50d714d74fb9a08',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/3c8eaa208db9d5fe42eb126d5dc97b9c.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96e2deb8b4a20d4988fcfc38baaa6b38',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/a57d4346a6edc6bd1632b92795188036.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee1d4aad8cc9f85148f3a74a37e72a94',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/85b5f4e6653048c00b48ee6c460721d9.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a017750b727aa88b66bc2ae83e817b4',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/f38f28f08d4a40ce38244f6f6f3b36b3.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40f69c7779c405cff211fbd6878d0b37',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/e00d0770911fac6fe0c6d878bed5f97e.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7f9195994ac13422135564ba0a2bdc8',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/4a0e5c33df89c034fc4d77a644d57049.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7771bfdaeb25c4d75ee3ed4e2278edd',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/bbe2458c590a67fdd4e5eca8bdc65327.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5dd5b6fa155fca17d59e8ca011811822',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/a93c24f97cfb12926163bae755c7f81e.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7af94d3c19d9533ebc504c8814656cd',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/191a1525b52701ecf3742bc5587b8a74.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7cc04928886b781e07a080607e745ce7',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/ddc9d2405884eec1e9c518fce0ea5449.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e90402d87bfc603002ae4bbd801adfb',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/178448c5b777581a3db03b9e3e4a4cab.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ef185ecb8752bbaa7b4ca4de3bf92e0',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/4d3791d5da8abfc1fa43ff2092886dcd.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36c55b613db92efc050e9b0849eb7421',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/eb4766dba8f80dfadca61466ad3d4439.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '746e6cfb3accb4f7cfefd7453426d884',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/7af4780023d66272d9c55e377b48172b.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '284855b5305850de2efccf8fd460b8c3',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/2eb479e4dde6f4f80cba4276f1ea81dd.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a08c7d22cc8166505ab069ba4c50cba1',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/c044ff12afc79f40bdcc530bba9cc75b.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4d1dc6ac2025b54048f066ba0ce50e9',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/09012e43150a8ea7ea5ec220f22dfb19.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7181dcfb34a772e5de0a20556552e526',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/66fb95a1939266c006945d43788963ec.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '698612770e9046b1793023a4d30ef88d',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/2d43eb5989fda1693db88624730358bc.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b09f185d51508000452bcf9d23a5d23',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/587d4801f492f17d6843b476d91eb0ff.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c44e3d378bc647485c2699444dac5cc',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/10885041c871d51cee450461caf60bab.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '012371cf68584a5fd98751496c4eaecf',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/aa826376bd43b786b80fb35dbed83fde.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81ab746ee7ce09464b4199ed6f3ad32b',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/5f1e766fa6adce521da54c6b5a1b9d4c.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70dade1da8b0ddb31e69d9b9ba963d6f',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/1d8e233c92e6d366cfe045f8b3629b8d.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bc9001318f15808685bd9dbc02be466',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/7b26f641aa0f1ed04cdba57024ba1f1c.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c41fb3d727861e6ce35c8150c433ad5f',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/54cfb1e01fd72b23f70ee4ea382409a3.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66cfb762899dbdee94b1bcd2ec33f4fa',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/da307903a00259385bf176bdee4f1462.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d6cf9a84935f129a06ee2f56cd6f1ae',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/515c7f70eb9ab58ec51a59615bf38630.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f458f2ad87c61ead4c113cdb78a9303d',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/9f35c157c3dac682a59865c3fdd4fc0b.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7aee29942b378701d48db1541c3a6867',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/e36b7aafb8346a726b33ff275232b0d2.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b33791f80cc5db66d9018faee5d7888',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/1ac57d8cfac49b06f2c929d94fb48393.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b96b9ad4daea6cd553573571f411a4c',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/55e077ef78c1ad06ed16f4a7775b720d.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6d55826fbc24155e8aa3ed38854ab4c',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/7ae3bdb3f4ba230e5c86d604b1635399.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '084e3591eec5a5758d1179b96bed36a7',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/bf1d8637db6abe702b9d9e9627fdacb7.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ab8691073e7e6c55b33c2638547cbed',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/486d0838ea4747adb008c730704312a0.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4caf5bff9253abd4a3b84303fb8ebeaa',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/9ccf9c504d94603383ceee68c8e617d6.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cab9f37ec1890764dd3ab0f769e12165',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/68e95fec711892961d14adff14f7f7a2.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9abbaeea30c0f9903f99c70d5735ced8',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/cbc8bfceb904363f0c43a9c61d7c4b30.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3491a5f9be2ed1b5611c3e0b57d48f7',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/34c0cab067fa53b714fd677482f17c39.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a666264606dae3ec7b0ec572625569bd',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/59b1fc8749911607d3efd4bebb221338.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b24e8da0887fdd22b2e27d220c8f4014',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/3c10a37e005df850e4f2db1923b162f5.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2043aae0761c46f7836716b68c9be389',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/b75eb526fa904ac771c6b7924160fc9e.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba79703120dda2a84672c605aa331bb2',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/bbc166cd7fbdf3813d46c879e34c2583.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1d16ff4995b201f4eeda6d33b843f1c',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/37004caf72754ecd735daae9019a468a.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1dc409cea1f084b44d28a66e22374d0',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/b53dcdaaab81d12cd92c151d60d98758.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a49b55cc9cf20fccfdff11343599e1d3',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/2d56570726ef4a2ed2c2315925b9b5b2.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '960bcb7691833ecd14d3c5a9ef2be556',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/5495f967478da7057e297b6dc5786627.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6abb0b187775d39d33511452a5126eb8',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/b07c3147f94b697cb883d27f9b0d7135.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b854a14c7913598a212b1a97e47040f',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/6cf5c3207db3b6fad3fb642d218d0d2c.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a388f451207137e06e6e9b7e48f10b99',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/0488b02d418683b151ef8314e0fc22c6.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab9656464091a22763e1dda7dbfcf64a',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/247012b4cf9480060f3ec674efe8e8e7.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3028fbb08deae2c6d0d2838bf7e59a1a',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/bb813e6eeb6e0300419c997b94282832.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f76826ecf23dd5beb81676832128ae7b',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/c32e4b7127b45e78819dbfd601be9f6f.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd35efad2c8d6b4286e155117acad2d2',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/4a4f334756a31b9e7acef5bfd1a6fc88.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0deea7c2077eb9b2792c7b98e34653d7',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/7c4ba301b4d7936dfe67474d974b7d54.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5316b7a9725186957ce4e81b3f2db7d',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/5f925dfe17822228eac623dea59de762.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5310b7f5278c10cbfd10ace24b6cb3b0',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/ae33858535de138805e0084fae5dd98c.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47fa808d9adcfcb9ba7f63ab94607d26',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/66a9207b7764f1fa0823218210e5a4ef.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8cd5fdd3d786fe5437f92c860473c99',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/af2bd6fc451f108b0c8fe7ccf54e68e8.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd2835a22a84b14e414a26a3994ae896',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/ad667cf8df096f267cd87bd740aa4e46.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a94f0184d64a17a8e6a54ec2660a1aa',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/66cdfbd9692fd3c842565f577604392e.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce0af2019f3237ff07834c9fb261d586',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/f79bddfa41cb061682bd4c9e92afa1ad.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9200c3a805adb02d3da1b28dbcb89768',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/429f39e70162b798c357a792caffc203.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9a82da1146aa820f8762e9b69d830d9',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/ef5f54ca2d86ac666d4d4e7b4e488386.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6982bc478cfa0c94f5498e4a10e4765a',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/58eb635f4c91897de96f32b90ce1027f.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '205c63bac398ea693caf276d064731c2',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/4958120d5a0b311c2ba3f07fed607727.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dea018100e13405459826322c2f9ba84',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/6f06d35a5e565088d480ccdafe6f2dce.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6113a4de02e625967bf69315e7ab2213',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/6224eb5e33591cf52a8cba996734628e.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4e5cb59f450ed808e756d84d3acc1ba',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/a116eb662895aea83aa6bd52ff062a06.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eacee5d277a8bfcd39412ffaddaaeedd',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/5506471d8f9beac3024972ce561fb508.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c3ce1eb6a2d331d6a2acb88dbb21a8f',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/d42def089d90c9e3ed482ddad5c3a3b0.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33695ffe999f3219790315e4f66c6951',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/a7fda9f9e81704f569487e6d99e83482.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd57b3f5be233fa6f4de9f0cabc865f82',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/84df713c210211ea3e019dc77c2428ed.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c161da8be13b54bdad50622638bd266',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/e1ecb77108af917a763ba124c0823a1d.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49775feab12d089e807cdc59d9f46efa',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/c9ac09db6355fad6a613810ff580f29a.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f891882f3d3845a178ade5fc25fcf7e',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/70de14f1bd3428a97150745abbca7095.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ceae4b17bb66591b4b965e39be3188cf',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/e055482f155a4c45f523a8b8c3d73d26.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21eff3bea0315e519cb060919a8d0f08',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/b28bab31cfc5ef4ac89fbdd8a4baa931.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59219f270a1163601afe55d6547e600e',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/4c4fdddadcd57f7bfc98d7a14726b2df.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '505f72dd5cb6fa97e43004bd13eb61af',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/719cd5152f876b50915725a0c47f1a0b.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f0aa346d924b34722d8865277c13553',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/5c95fef4881a8ee6e130a3536e63741b.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8d7f08b11d87ff55c21f10388afdf20',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/5aea8e0a7a9829b79537dc5c1e3f3aae.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87a36f8bfe01708604afeff53509e672',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/5885ca411ae2ed1eafe4d083eafe2b5e.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f3fc18b48604af5f9c217a28565028c',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/24fb231e9cf8ba1e9f767d562b99a84c.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b2250af5e9aa3986816c9312f4af2aa',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/88529beb74215d1f5cbd2af9a39175bc.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3deeda61da602fc652829c6cf57b2e95',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/10d4297b2412bc23abcab6f4b2ac8cc1.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c5de019862e30becf2e4365898dc933',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/eb2aff8f000fdbdf1784137f95a63995.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25a46272fd9e8c74a5fe2389cfdc9a33',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/305a1a08fdc0492f2ea28e7935d7950a.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdf3d2e676c7c3d715448bcb01ea5746',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/9036db0d53366ae9327a7ed2739a535a.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e60797ded38062545e14973451bcec9',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/34143a17a3c53c01a1175c032ef6c155.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d6bb399c140bb4c9038d1ea9fe5ff62',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/668aff81dd6f1c02d3fb80ae4672b117.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cb8324775090806c866e0cfefbe8f41',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/fd3b47ba5de633f3c36d2e5e18c6ad32.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4918f63dfbd605bd6b6de809eb4b7dd0',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/1d11de074a65f6dc05558b26235f5efa.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e08010286ce763a2ce0bc1f2225203e2',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/e7703f0c7cdc3fc13777836186bd4c7d.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd259adc32c5dadbbc9f053d8a14354f9',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/e644b9ef87b6f06260589283fd79729e.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c0e42b1c208e60259ff81f8feab95c2',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/2e3ed5d6858e291ca7545a2b128890ba.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '074a86e05afd49f20f52fe7298200b26',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/0ccb42745617f51d05b83c2dd54cd9bd.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c862fcab9209045a7af26ce7bff031b',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/e636e92b688304ecda79bb2a4be722ae.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '047a43798bcdf1fc00984bdb70380a94',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/303231f9570877a39d9c089282a13458.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37d76037a97b4b9b065e3d0ca012fff3',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/6ff731607247081b55b4348060bcf004.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efb5569fa7f7dc5beb64a7637cc2ea9f',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/a913646bc2438de473189ceed80ee35e.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4cbc9321742f30dde641d0ac9bd678e',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/d27a8958ca7370eacdf5eff273478cf8.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f829070d0ac97c3b451497cbc318495',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/25b0071cb77dbf274d978b5cf4d7cb40.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '238f33364c3cc02f1f67fcab46bfa3e9',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/a92038e5f15d73b1ad4a8b309c886651.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c29610298d0f704cdbb5c80b41e770e',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/cf863f779fc5871e175a51214289db0b.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '925a917a127898d27ca68737bec74e0d',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/03cce6320b3d0f1dbc07c232e2fad29c.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40b5f09cec5f06f1a1737d749540b147',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/58ba592a72c2fdac6b678a859f5376b4.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52499fbae3b89b7f136cb7edaeb69381',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/9a85df92f8ada4aab99dc667348fd330.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01b0291daa05e99751e17def013deac1',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/6d87d03e1463a17f67ef947965b43dfe.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c8155c6b2651b4ce1b7c357a5441e7e',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/6b0f80e754e8ba4c0c02fac6fa4b8956.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5d9dc32ee0416680c0f725a2114bce0',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/03db980cd985e697a100d6476d1b02d0.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7fc884f9f04bde5d1af3f59a9298bcb',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/38b97a6526d4f752bede4800e4cff29d.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a35ffc92d158f36d69a027353b7eac90',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/d68d90ae1acb2e6ee7eca1b0e6d0b775.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd625edfa1fea2453bcf0f5e8c496e28d',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/dc2c7fdf50b88bf0b8f7cbbf14010c96.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '421a3d9bc54c730f571438fbf1dfac98',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/686d0600829d57dfeb135a62a791da81.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fe302116446f2977dec283aa42bc919',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/3f59cd4a1e40c2aec0994d77b24b0e1a.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ea34ba619e4ebaac3d9daf418a2b933',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/2a7ed69b1d0f21f9a5bd2cf3a424aa45.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8db608e0c4f1596548e7eac615fb83f2',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/93727338758b7fe665553142b759797e.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00e3dcbe9dd17a31dc467343b2c23e16',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/08f06117f8ba40396ec3194e1cbaa876.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47280047fde73e94c83a9bd1a85c155c',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/b8e59ccc21c81361eb8d349f49239a58.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a18f88e4a9bba0784bd49e6cfe19e7e2',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/35d0851169601ded8c2f98811a2b55b7.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88fad2c8d9934c1a3929b23271594ada',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/7293bfc7205ca98418baa20cedc2f102.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9439f8ed10bae50427c488d044b20bdb',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/ea7aa29049037a06e0a2fbdced8fa0d8.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82ffaeeef6867b5398c14d0bef904467',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/13469ed7a8bd3923cc4bd04fac8e07cc.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1d632d1af6eb42c57b89ee8b9bde11b',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/308bb1e5f9e95ea1c9e59102b67233fd.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55e55148bebccef881fb0c51292c4c39',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/1fc62c7eacfd3eb1e5ab1a17a225fb99.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff9b7579d00da67d729b40b2ba45b49e',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/6ec2e35dea6669e434e83eb61662f98e.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5966fee0afe2074d02b9513fd8548edf',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/cf6cd3a4c989f94ab41192f9e5e7260a.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '217d57a1d4ddff196ed1795d3eab7ae8',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/4065301e266c0ec0aa1d275a77a193f9.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfadd7b12e69d74dd383b5f0fd80ef1e',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/892783e804ce16430cfde19605c88c5d.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3438222f7c05dc3be3f0a55357a5f498',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/dd0052209cf685830c98e9c678dca691.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '324503cead4e6af8fffd58839045fad4',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/d79c5b45d6f8b59e57da2f5f0bc3f44d.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66d8355baa19b84ba2f0ea1aa1e92fdf',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/14743d70c37518151c10ae6f2efcda3d.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3023ccb599aec1954c8f5d37ce4587b7',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/d9a52411502c412fb1c9ebb1ffe8730b.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'acaeb178c11bc6589a486f9a15d6f6fa',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/e2ac57c7b77f335b891065a502361731.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9c789db31a7a6dba8506b05d2ff074d',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/ab2268ac3a58870b9b021c63a7238b41.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c35ce3ee9bd6111dcec7a4d117614f7',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/d604a78cd8c9eb868c768a0b5852e7dc.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7800e0980360a0e0243aeef6fbb9b1b',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/5b803b323e6588ba10da748ff1939472.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f19c9cb2795d0f756212d10c83197e6b',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/b7556fbca98833e3545957ae5eb8dc7d.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '917fc7388a65611a762d046fd7470f4f',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/01317908349fda974b37b79a05b90e15.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b6dc623434e34144462c5368b17ac87',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/9e831592ebb0ba85d7993eee87f868f2.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e34e16091b9cf26abb3378961a598066',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/98fe6023a60f62e7772447293ea79049.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00865530a8acf4ffd160445f9d6d2bac',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/539f7b07fc4975d847631f84d76b9d88.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d6474b792b87c94ae0df7c0bfb29a06',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/2ce354f9fbf0f076410f9b192945fcef.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '740bcb8b6c16ea30d61f73e18d5961d9',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/e7f1257452cc570678a22fa2bd56d540.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de1c717f71b8baffc9827f6873ed3fee',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/8f5315ceb7d994e0c3c7ba2f6eca72e1.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a90b6e166e6722052ca4c64cceb8c26e',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/0cd868801c784af57b0e5e5d2bbfa991.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '611d390f83a3dd3ec66066016924757e',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/cf93072804e3dec8943ae7da0c7f1d01.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'daf88a9fae3e7e7a16d18e31fd6de644',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/84deac70d90007d1df0eedea0f20734b.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '319d83d92c256cdbf2c9d2a2cbe6dc50',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/bc483b5bea941b1d153a0d6138fc9d85.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e758bef4d37d9e57f62438d76313f772',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/7acbd42a2d73eb5475e621a5bdd2b419.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9871e18b4ab57ac4a32db7fa038e313e',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/367751e6b8694b14c91d46e2f472e9fe.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca02f87a2dd928dcc8965fc7584f306c',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/8fe06a4bd2b89daa7d6a66250860bfb7.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdd91b3b6cdaa19057130951f97b012f',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/9668d72c1267959f5606e75f0ccbf892.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e72af1315884acade72fb58b69be9c06',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/2e2941343a4cac11324cacd551015828.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15c8330060b6ae972986fded433cfc89',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/6b64c55e5ca3cb38e6d60743fc3b13b3.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8200ad702695c15032c750f73339d490',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/9478569726db2cc7b61b104273ffe4e4.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afd6717fc30f79ef3d081e89ecc968e8',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/b4040cf9f7884b46f180490937b64290.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df7f287d87c8b32d0662f5f0fa8446f0',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/6066cf91c4e05fd1dd90ab913a9ad700.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1a690c3ff3ed7f84709e08224804001',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/d39bf60a5b5c19f36e8816737e534716.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4787b8305194104c58289f717801f1ac',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/1a815569e247de23905132296d68d528.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '095543f81d4cfa90eca44395345edc5a',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/ca1faaedef4e0488ea52d1e83895dcb9.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb246a241376d0e927b5c5dc1647ce7a',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/5532e6f45adc5d33027a1c837bda493f.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5977ca4abf136f686fbb4e4af702268c',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/9673726cd61b0effbbed5de39b63f0ce.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd41b20e7501bc7b2f39afd095c8484e8',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/563bf1f787069b297f3b3edc34433871.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfba2c72a83c7312ba40d210a955c2bc',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/3afff6749eee352a55d8e55ae23f0db1.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd591b8fde289e790d7241fbde5490272',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/09fef359d92657b337fcf1f3eeb05da5.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c31469af1898d2dc86e369f699344a9',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/904e2abcfbc715c0aae497c1e67465e1.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8bceae32795f46fdb014119b3b66dbc',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/002b579a07ddb2767b60e76b49c79cfb.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0657d6a42628de5950739681359aa522',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/962db4c52b287bee7b1281c91add6225.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cd6ec1bff6b0e665cb38fa872121cb8',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/91ddd007428a93e010235661c56bd9d0.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1189c0f0016b12093c8bfdc071d85963',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/7fd1947831efdc074b0342b53f27b13e.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b7fab8b2f9495651e6d8aa6a544e2d4',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/f7f420346b2be03217b109ed40cd42cc.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0121d4740df50fac05e1cfa76386cfd2',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/6d924db471dc863c0ba7a6b70a490b3e.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2dd672eb0f4cc54aa757e17368c2344',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/7bedc160d04b8daf9a5161d8722c27c4.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7610299db0ce0680e3cf47fbcd6e147e',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/31eb8efec7dc374c5b93b175db25323a.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61061c11b789443531c68882596db581',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/c7cf073b53655ee36fa028f4184c9040.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed854ab123c8e0bf7ccb5c93194f887b',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/85deedb5445588cecce5cfd0f7cec4d8.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '491ab198bd139d751d03419d47ec8729',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/61cfb1af5527b9df4d991817a773a907.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '1b5a600643f3e6cc040f0cdb29d693d3',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/8e1a39db2743af30aef9665fb4d6211a.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '278ca83eac611b6f5b767439ceff4a2f',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/c7d9e1fa884aa8f07c5fdd98b1a597ac.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '750d97c09f807265a904e7d4f86c25fc',
      'native_key' => 1,
      'filename' => 'modUserGroup/ec59a7b850ba4a71fa1bfb7b576c4515.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '792dcca1f06b397b6119ed183e3a8838',
      'native_key' => 1,
      'filename' => 'modDashboard/be9ce09c559e82633b2878629dbe3dc3.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '31cea210219ee70bd07ccce4c0ce3eab',
      'native_key' => 1,
      'filename' => 'modMediaSource/3d77f0ab849ace76f015b65747ef17b7.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'cdd6ed5892f89bc5717a386a60b5cbb4',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/3a8b42703cfc618c2331abf0f1f84bab.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '95174d6005f05fa8e54f3891de11e5a9',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/bb4d8e85a7ec83f3c69b27067ed1521a.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '12bd608aef19042dff0a02d00a2ba0c8',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/a5bff2df75ab64bc72f9536cb8e55eb8.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '352230017b2be5b6f393138714d8b9af',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/e0347e2b1345c2c5449b137be8960a8f.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'c5c64ee237b9116ea4adb2019a19d5b6',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/6458b9e9895efc6e41e5226b53bbc0cd.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '5bd19c8a9ac0b0d228770904831f220f',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/3013b75f164a11d1cb39b186c5adb2cc.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'be6178c8ea0c6b3042e920bc34095d80',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/14bfaf81f5b9f44e0dea3e2eb84bc99b.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'be0389ba62101a8c0f1ab50472619908',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/1be3f252c5a0fb5c667163b766697d4e.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'facf20d7b3212196ba8f8a8fc2cce7d5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/6ae0d063a1e73974e2b106bf0c44ee10.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'a89e9f2252bcbdd5dc9cc4b1dc3cf25b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/14a10bd1466493542c02eb71ec60a8c7.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '2396483b0f7ccbe5878e65fb659cb4f8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/7562dbfdc0e51cc2a22c764571849dfb.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '9075df99d463d85de1c54b497953f30a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/28388dd0c48bcf05f6fc707133f6721c.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'd0103d7f476d45d43e8300f86512b7aa',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/deb11f78e10c3b24b7c722884098c126.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '72eb56adebac9606104aa8d8a19083bf',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/d25fec2caafc5e24ba0b0635beb1b0d2.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '3e598d59cbc5e46508e1a72e082e04e8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/6686e4c11b82682796b93c5ecd471302.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'dae7e367393193de0658974eec3430b0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/38bd647482677b468cf2a505540b3359.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5fce86f439045c263dc91ee37f62914b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/0b38b2d3d1c3306ca8edfdb3b16c7d05.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5a92cb21cdc62b4f3c05665c9983957d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/296f3afc8317f6c2c6f6354df121c55e.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '7153d839ecd6714f6b484b67bb803b14',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/0602c5ad71e7824ebc1f450b8d6c9f36.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '162afcd601cc2f84c84606fce7be0757',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/d08648bdf5bc0d22482808eeace7fb00.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e4952b2badbc9d2a3a7e8289876fd56f',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/d010aecb27387c326773dc5384b842d5.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd7fa25277d083aa49fd87a83f1446d52',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/7b371a9c930e4cbcd8f7bd1a469e3232.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '19da204dab58f5e1e9e5c30db63a0b48',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/d9fd09dc81f1474c4d53db7d1df363a4.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1afe23b94372759e852bdb09bcd31233',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/a3b322cebd065daa5acd7f2eb00deed2.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '569c0ce00533a70f2fb0c7568b2cebbc',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/b7aa7abd2765d6d8af52e8cc0c6889ad.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '660be17208bcece663b826987271d6c2',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/1aa1e48a53e34123a838750b803aa4af.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0b795a02450149cb5c8c8910d865e1c1',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/341d2b6ce80b149847fd2f9b2a9a7998.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'dbe48b9cfe6ea1cf71d416fcb45b0d98',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/454ea1f17e846562d15be2f957ea123c.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '41b3096566ad3f5f84955ceef8de9eaa',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/3cadb27c94198d1a8ad85bdd9f9bb3f3.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd6e73cc36bb11e7a92ae23ce92f71051',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/d78a1751ecc1fa390c87ea3909f5e3d0.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e5ff89eee240e5445efd44268572a1c5',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/1a1794e6b767ecbc824027e049a2c990.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '751b4a675293414bb5295ec399edf866',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/e4ef45b89eeea4697e28a99883b8efbd.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '870500cf52e4a2e7ac92dfe61e81bbf6',
      'native_key' => 'web',
      'filename' => 'modContext/6d5a2ed241e9c0cc2b5ae393bfd3958d.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'bf26fdb3740a29513b679e0b4697eeb7',
      'native_key' => 'mgr',
      'filename' => 'modContext/6b59633abc6177f843221398aa2e4cce.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9988f041b12902ab12292834000a5a52',
      'native_key' => '9988f041b12902ab12292834000a5a52',
      'filename' => 'xPDOFileVehicle/399fa716ed721097a70eb4501c5862e0.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'f775c993c79bcf0e0d06778879b45563',
      'native_key' => 'f775c993c79bcf0e0d06778879b45563',
      'filename' => 'xPDOFileVehicle/0844d7e40ac1ce54997c61e2653043c7.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '255f672be71ebc9d4d686763c0b4395a',
      'native_key' => '255f672be71ebc9d4d686763c0b4395a',
      'filename' => 'xPDOFileVehicle/ede20237d120f39a406e882a61f37911.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '13eaba30aa11215528290c73736bfed3',
      'native_key' => '13eaba30aa11215528290c73736bfed3',
      'filename' => 'xPDOFileVehicle/d7b1606682058ad8513e1763fb91db1b.vehicle',
    ),
  ),
);