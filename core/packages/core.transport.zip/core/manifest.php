<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b71427bf3b6316cfbc355ceab59d0391',
      'native_key' => 'core',
      'filename' => 'modNamespace/c50945a320b6896b75e6d4de30404ad6.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'c31de00322be05073a2814f2d983f116',
      'native_key' => 1,
      'filename' => 'modWorkspace/c69ff3a987406209df22d8b788a42455.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '6212b82c021bd05fa9263a8ea35af423',
      'native_key' => 1,
      'filename' => 'modTransportProvider/349d6574eb6bee4c35d2105a00c1d176.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'fd96a08fb31eb9adcf73c3a76d45e669',
      'native_key' => 'topnav',
      'filename' => 'modMenu/ad67e6da3048e628e7c8e3c030a3d2ae.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '22c945b58add216937d1cc286f7d7ec0',
      'native_key' => 'usernav',
      'filename' => 'modMenu/fd61016aa9fe4a7c67cfd89806bc9049.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '952599fdf5224ff2c41a02b01a02d052',
      'native_key' => 1,
      'filename' => 'modContentType/f12c9f5408f3a47c7b873b4098f11657.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'fc0d1c7896d87d0d3f8895c79219b05e',
      'native_key' => 2,
      'filename' => 'modContentType/a6a334a742fded0f76259c4ad1c5c794.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'def22d43086860c85b1f1410439b431b',
      'native_key' => 3,
      'filename' => 'modContentType/23b6206628f3ee75a616d899ae41a9a2.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c7f3c63d3ca8c6aade2e80ea08a4baf7',
      'native_key' => 4,
      'filename' => 'modContentType/7dae82799abc65bc099f0cd33f8d0ba6.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'd8054780e030ab71a1cc4ce4831880f7',
      'native_key' => 5,
      'filename' => 'modContentType/f80dd3f1edb2f21a07152244f6e579a8.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '9902b08e7c4bf6dcb87b2e94fbbaea3c',
      'native_key' => 6,
      'filename' => 'modContentType/9613da3ad5c6828e99de34a33ed8e6db.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '845b1476fa5f43c0128fb26dc539e4ad',
      'native_key' => 7,
      'filename' => 'modContentType/9175cf49a9e5ca2b8297c0ffcf6293ef.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'be47d4c666bca93fa0fc3f482beff055',
      'native_key' => 8,
      'filename' => 'modContentType/4a5f448efca78b280acd1b6a84b53d60.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e58801ad987b3030eff9fc427d106896',
      'native_key' => NULL,
      'filename' => 'modClassMap/c63433220608e8b78efc659b4afd1a0a.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '5e3c6e6ca92fae60714be651cd7c3ac4',
      'native_key' => NULL,
      'filename' => 'modClassMap/ab3079d7de360727789d4144dd106902.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '649ec81bcf6a57cbbe011f20d5d35884',
      'native_key' => NULL,
      'filename' => 'modClassMap/074c2251e203952d90f4deeebf036081.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '6ad1b916bef4ce732982b795ce5c44b6',
      'native_key' => NULL,
      'filename' => 'modClassMap/8687f42191ce6c296ef83203c73f86e1.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '704adb8a2a0e2843fda0b7c2bcd3c095',
      'native_key' => NULL,
      'filename' => 'modClassMap/327ff9d72315a584aefef49d9fe65517.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c327ddaa8071c85a92a0243bf98c3b8a',
      'native_key' => NULL,
      'filename' => 'modClassMap/c7b3fc8809bef7b4b69c0c7dd1c8903f.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'fa4675288ef3b9494dbca39672054b37',
      'native_key' => NULL,
      'filename' => 'modClassMap/1f06e2bffb66f2a26dc69d81fa180840.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '57ab99e0c36eca339b0dbf90318004ae',
      'native_key' => NULL,
      'filename' => 'modClassMap/75153061c6cc1afd36f08d812eef0db3.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7856073ff9b5032b1ff0f1a7a84df450',
      'native_key' => NULL,
      'filename' => 'modClassMap/16f7d421dd416fa976601149ab93e188.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '953657283363fe48781477916bd8d0b9',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/01620860d975a868fcb17379c1a9c752.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7aef166b5888f6318cb349f85c4901e3',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/8c75d3bbf674771f86a9f0dd85061baa.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '680a604e0ba8e54ada4b00001beec425',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/c7ad4528d4b333142dbbf561b6594f3e.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6e6d7b5117c28883cbcbfce46f31386',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/8b6655f08bc0057e30bcde5709cd1874.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2877748007132336beccf8955e2c866',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/1a4c537671de05054a8cc04290bb0817.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2538acf48388b8f33b081a94e9efa119',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/bb9949e605808e67939a273ff578e851.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f43bb252d4b4d5d7c0fbe5fbc73d897',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/91951f8a0307d04e676c8828e846a1e9.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ccf0f46d720d93f6e3ace96ff252b82',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/f500820dfc7eb47d633bac82c54be0d1.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99f21d83e62e45115fe1a3137aa7a9a9',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/2deaf8db9f39d09e76c133be85f040d1.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef10cceb00dcfbdbc6f8a3b6a7877b06',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/04bdca24e6a4d10bcb4706b4f842e96b.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdb7b672aa012b997f7098fd62942e48',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/0b8bfdd2f8281925cc8b11230625fca7.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f93c0278fc592a91bc549dc5a5f01b1a',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/c3463a557a6ba060e0fb24adc5b4b33f.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1896497c9c7a9ba50577146bbce615e9',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/b95df1f720d0768be06ce0dc40ac50f9.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78fe9ef89e231920d78eaf1424e69fb5',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/a3f57fafd8d4277d749be6d14843732a.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a535092c4b19528e16d1abb71a0e50f5',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/a345d16ff2ee27e83baa0f837dc3c88e.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8eb28cac6edb8c2ac5c1f1042569a52',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/7ee5f2742eaa640c3199c96c3aedab4a.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab6313553c78403f376e88abd83ff370',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/ca7a8d949a527a4d3a5698dc8b580f0c.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '349ed9cf4055510fbf14d6e8b4f28f9d',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/cf9c887b212007780940dd077b302315.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c08c13ea682ac31e708097afc312651e',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/43fd3ff9f5163c58d60a914c2842f85e.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66fd3919d902defa6b59b4986b904450',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/a703aba1573e788f7ec987fafe7a4466.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '705304787e160c9c531caf99ee8df2d4',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/1ccf24d37258eeebf68ad1675464f1b6.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b5c091e4cba3f27158c2c3eba72c21f',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/e3b115f65bc39d22f60ba03ad37f8299.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '871efd7124fccf7f77b9ca0228a66192',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/ad21b4693d9ab0c8604e75c939fba202.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '194236108135e4c9ec0c8dbcf302454a',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/37cbdf0f580ab3c030af5ca947e44c6e.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2619c86622b02d18ba01f9afcdb733fa',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/7f72ab9e725daece59329c976ee784e1.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f306b3d75c49150223f8e87dc381c54',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/0f5fcfb1c03ad16be3c95bf97c1165f6.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0429845e7bff76fba73c32abd51aeb3',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/b390ef06e5fef2d31358c140d024a993.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7e4be483dfeed40d1ca22db78cb4990',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/fa6a1cfec8f33f2500a41fe7d2f8f098.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a7888059e0a32feddab8a599bda4a8c1',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/e325696e608755bb8880d3401a22ce7d.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e87a5d8551eb205abe851e11ea2e4bc4',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/7f155630ff99d00e0b149c139ccad6bb.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1876b1464c1a93e62ef33e308ac9fd6',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/c68dbbb582219439b3a95a4c35e28fe6.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0d749d5103fee10d527eb23e0f1b754',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/c27cb7314e8f18c6788b6a6ac94780fc.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46476d46694a4b0bf1ef7257e994e1db',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/6982a827e5ec7f68e81ba9a7141ffacd.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '92e31e192b1006f17118e7c3fe0dcba1',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/451dc49b62bb0dfb1fb03c71d56fc884.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78cbb2844bee33973b64de18f23d13c3',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/216f54c96c64c8091657896ec4819ac3.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '559216f0f8c6180a6ccba6abf6f735ce',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/f01a72359bd4202cc27407e56b841748.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ffad8bb09d6ad47976f03815c6219f5',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/079d0e7e8410927dc6635448cd2359b4.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c83e56da79bf09a0196b5379cf8599f',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/29c81e8191f50aa40a9ca6a97bb02ddf.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6188c273134745e097e2ec1a9d4f8ce6',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/c5a49ebfca6e4ef63a49ac1c714207b8.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2db7adeaae9898bedf1a3806a69b55f',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/c2a87a03d8803112e502b0c01ff2e4ec.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '327b502d6a8d53347f44eaa151b88fbb',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/24e3b00e6156207d5852a2bc2c91d247.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '240022dc2700bc4c06638322f69a41af',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/0a70c131654fc1f2fc22a5e4f64b554e.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88d6a6e758ae44b721261cc8dc6183e8',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/33f947d9e7de19d9f67cf12f4487b43c.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9684202260279531c5cadddd616a86fc',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/f85149cbef18c900e3d4cf4b2170919b.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a161c07d22a1f0bce2c573f2294f531',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/e249eba5d0cdbd6a442c0dbbf48b5f84.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c3709ca0bfffa7e2b61bbe8bc14d909',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/905f618eb5d7336e718bc6796fa2d63e.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd5d826c991c723fcc88c421e1c63343',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/f551fba843d805f189602ac55c9e53aa.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6331ce7a8d41909867f0706d825cb5c2',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/adeb01e94c95fa15468190c7cec653b2.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e2281829d54aa7586c2803e40680e78',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/b11f07808051c90be26d34ba57bfb333.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af8d3488cf4762bbc200a8d1e496f8b5',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/6bab55990f947b1f5d20142ce31c9cd1.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f5ee9361dd16216c733a0bdcd0c1e852',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/a3bc9ba3781fb9f1e5189e34ed95d616.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef100897b32526920a6c71a5e4eceff3',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/cbbdc62cfa4dd99adc68f162e40cccce.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68f0edc0940917ae6678ee6f1cbee683',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/d770eba54c94b4aabc888602422b1a34.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed3e2c8538b2707bfe377580b82685a3',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/e69b3fbf4d455e3f3b923c46a108ac08.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1208a9adce17eba15ef27c2ec2f24fb9',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/5d1dfaf686948537d1e446e2f1ec6f8e.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad489f195236b2ea8d3e67b41bc17cea',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/0e002bf69dcc491e22b64a8f1e4e398c.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a836d9cc0e519e5639ebf6ebdcf2dbb7',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/f41d9271fb3445aa48c238ae641040e2.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c78f1093111c116e494ca01941f15e6',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/772f9ef0f113065e972211d636c8858e.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e7a94ff145c5489398080c7ead1ecd0',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/7e37ef946ad19518ff35a5d1e9c754a6.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02cc7271c5ffd8613e679559d8818d49',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/cf73ee91401f991d7953b0906ba63909.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '313613e821480ece8122fa3139ef8213',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/72697d4b93804837d617d6998d9aea6a.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7c056a4216552fac403dcf2d357113f',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/8c25fd94e0a3e87a7366fa1e40247139.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f248f4e04065163d122975973b924828',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/a2e6bd6a606a9f2e4cf054a951d46353.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a71317840c154365e1007c2baea5360c',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/932200e260cd2c46aa736a669b79796e.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7009384f2267423b351dd7b4cabc1dcd',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/da8c8ad1686955692d2f4dfaaae245f6.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31084e490c0c09d07962eb55de0acfe4',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/b4a0de7bd3d44cdd6ce8f0e93c5737c1.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd78450ac1d9d3bb17963124263794d82',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/fd7bc9ec69f6f019f0b5a3f6a2283418.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef5a15c7076f3e835b8077430fa4ead7',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/d51deb3ed659915ef35251744855f27d.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '08eca625a4d2e0da6c22abe21c3476a0',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/544d591f7d5aeb56c15ddf00d590840c.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e193953e3f93cb7cc97a5a4ae7cec5a5',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/2374884bcbc2b6c6059683f1b9aaa0e7.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea1fd51f1ed02e792d6bef8aa948d007',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/cd415dad74e07a73c3a7d2bbf7a7cbad.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7864f4efe5ccfac76206844e3f77edc7',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/20c298fe128c18360804fbfaea4a15dd.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14d8fcb73fe1da9a91b232a78773a608',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/eef23e4b59e90fac5478cc9e4b47eb6c.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f10796ca735acd142e10c01b8b58633d',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/dcd3bf89d9224f2dd6b6f2a56b6a62d1.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65e05b39bb000988fe7cd43c8bdf134a',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/c3c7b619b7158ae12cfea05ffae5e46f.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a244f31de3151916c4d56d73499a691',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/f22baf1e9a50837635baf2a84b237a9c.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f000d78ef9c11e16b96ea92813682b33',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/0b7ad6d9f68c23de53a393cd6dea5b59.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94bea836f3f6c113b21888fd905a1bc6',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/82f77b51004cb9dfa5e609245c5467f5.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b85690765e2067e6f8f1d5d836afd867',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/ae4fdab9cf76e70959165bdc8af2f2bb.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5d39f567f21f4cf9e6ea568e71f1d6a',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/b397b17a5661072adf4fc2876ca4e0f2.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea712f9c3a3e61bb59d6016230d1c4d5',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/19e7480d4e2ce1008e1899b04a8b3640.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7da662b406b9622424566cc8a0194f4',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/ff1c2e22900e50cbdcf452412f94b3bb.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5fab549ae6bce2ba2fbff444f2fe659b',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/9bd6bb30da34ea272e5718e9cf722222.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0d5733efa2e0e510e39c2cecdaa84c5',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/314ae2651549e0e8e7241b95c786dc38.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2ff83d14b3ffef4434eeabf208d57a3',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/05bad396ff0ae38da1b746112a09c772.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69057fc226b1071b6107e0f78fe34bf3',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/0c91455025ecd634d5201e329d85f9fd.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d81585456d2c3f3fb787ca2c3d0ada1',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/4dbff1c998b7f0cb6f965b46022aedf4.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7deb285b854225a0beb33de6ce70e99',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/a4dba2918deb663cce1f706ca4663c74.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88e4fb8b64bca7a93036f1b9e2358c9e',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/39b8289c166c15a98180443ee03ec7f3.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3fd40d7a68c2e9561f686c09c9212ed7',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/d5151d08852932102ccf87cfbd0dc1b1.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3608c287a20daff08fa3613fe48c4450',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/c39d0f38ec22d668b05501c197b95acf.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c154eb65174def3b1fc89647b04add6',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/b1504f92f6887c9fb94b33a58ba15988.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52edde23a599842be8acca695a2def6e',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/6810a451b849062246784c3692c9d75f.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd62e00ed43a4bc1880f3e305ff6b4ca3',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/bafebd390ac592f70578c6d48dc12028.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37464a287a3ea04972434a5190934181',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/44baba1e732606f1db57881ce345fac9.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '224b821705527d31a92e9ad29aa4e6bf',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/d065c9bab174224cc7d473621468f494.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdde8a120c4b13dca6528871d2a3094d',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/6b7756a32b7d24a9e51981963738f83f.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2da7cbc7cc6c1c1005da749ee758f2be',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/9d81fe8b8dfa2f97facb84d81742cb45.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e9f15e6f6e8243d1e3f0ae969402575',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/fba39effdab059f742a7961bb49fc137.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f5595427e11762e8da49e31b1721e73',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/5be7535be3e31dde03fff4ff27810d42.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9080c64127f8abcbba784297b1649082',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/d07bd6180d27bec44d40b015b0f6aa3b.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '527f6229f94fab35b2c5b2ae446144d1',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/3e91362592a2e68ffb2c2a317f31d434.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29a87fcc5859c01cd010c16cacea2ea1',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/0a6d43a5657ac9c6703c1628e8d89f97.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd583274f80ce03c57ae53454fc781b5',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/e396971e1462773dfd70252d0ed6bd4f.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b0a9a84d891868ceebf2cfcf2496a34',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/1f88bbc8ac68dbbbf8bebb127d69e4bd.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97a7c852619d3c9de8a83db425e05bfe',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/ae8db6e99a6b9032241fe108154ebcba.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c1a81515b10a74362bbf89510c4b140',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/0e84f119fa6b6d43b04472195e31b623.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1eddd636319b88298c6005a7e8c98a1',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/c91eeb834bf3dad68840aba20b2515a4.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9ca04749f4d40abd91d85adc756ebdc',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/7cd21cebd83e66d8eb3c6aee3c792911.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e06c1a0ae6511933ae751128cc176260',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/527334581ec485da31160b8a3ac8d017.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29b1ef451752d05a13c4e53125cb8281',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/a8f9900337806fcc6de7ad0c1d9c723f.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a9fa99e7c70d8429ddd055eb92560d62',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/46d353641f9cc4e169cd4ebdf3fec4a7.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9aa14f5d076a32420a7f1fce8785f8ae',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/bd1f4b65034c335004c3a018a17f55ba.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f132ad1c03dd2aca279665ce0ba7e7db',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/90d31e0d37820a27f4a502c58aa2d72d.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '04be3ad9e0603b778fdb3e91fa3e5379',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/a6e8f45d6772010e7570e0191775e0fb.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a85db70b73de0b443fe65f12c88fb749',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/203192303699bd020316b9ae803a3f9d.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f02b4680b19336d54b068e806814422e',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/5a4d93b059bce069b11bfab5216d6fb5.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d7e99817186e0b71ddcd0fce70fa216',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/50faa4317383c92f13a7baf2fd6e612e.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3b0cb119126b196c5eb81f5d65245ac',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/a98d1b42cced5a24a5a90745eb67cc6e.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ce46b4753a8960f521eb3e974c449d1',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/dfa5dec6e2069dd8eb83e4d018b93f46.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b5c72487e57815750f4d9a0f80423ced',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/af6817750607fc2a9e13561598dab380.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab87b025bed6b776b07fb6061495dae3',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/d0ca673d48f19e49dd3b4d1eb4514461.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3db16b19011152ca2339981a42d78264',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/718a366bd3f92bf574fcc64768755b09.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c3769fb48ffd39cadd76e078ca50983',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/8c3ba40a2231a3a4c8a14b922c11ea5f.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85a0b1ad4f8de4ddfa630654fee34af5',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/1295fd084567049e707af67dcfac1418.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44341f1cdde016c83934e04066a9c920',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/724765bb77c429d5cf68a6ac7ed0324a.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11ffac876b61257edbcffe551104fb61',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/51ac39e2f55224ecc722f92c8e44e59d.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '70c8133080423764da28b9c60c93288a',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/75e56af0019fd277c4a6f60d6dde5304.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a37af80d6f66e79bebd04c5aa186f24',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/527d9cfd4887cf36ee9b38c02cf3ac66.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e521748646c99aacd4a7a49a9513946c',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/4b6291215bda95f1d5c7d3d51796319e.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '417f617880f6449f098ba47c6b1c360b',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/564e5694e36c84aa89818d97f97f606f.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af3c71b727ee0e3e71c83a88695a383a',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/50cab9dc57fe8f7725dae5e15850e661.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4672d3561f3354096d679723e2aa3082',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/3d4550b293ca411f089364556b64cd47.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7add7bddf849d2c379fa19665f14796e',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/c336f2b421bef41a1d33b932c0359b54.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '382cde5692015c79eea99429d4c2f34f',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/748ba2e3046ede78de0c1e7596cc51fc.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '422cd22ffb19fb9523e9da785f5464c3',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/d012c31495dd490ed277b72fbbeeb266.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dda36b46c85a0e353aeb1aa20aa2a6c5',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/8780a50e48f3671598aaac51feb28e98.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab1b3a9a673d2507f267a0e9dad07ef0',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/8f1b40348a59a6aa1cf7a5c4f06e8022.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ab1220b10fdb310991a6cbb66f4612c',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/3d05e68d315c82fa23a731ce57ff0335.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8754a96e46ac04bdefe949bcd7c873f2',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/a06b1e79eacbe8d28f3055a0f0e7d2f8.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b77e8dd7106a647e84c764e64d8b24a2',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/66c196a1108871c17dd2be1b43766035.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56b5b8a78338351d8739af4f6b307c2c',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/42894d05ce6f28683541b0db39a9fbdf.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3db095a6d6789acc3b31ab1bc4745bb',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/52aca84945a2f9a8bb3c74ca6537a64d.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a2e931144a6ae81677fab8d20d5f800',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/8cab8a00b4ef1456ab20c3255f1ea418.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e56406d5f01ce6622d942d84b6105244',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/8e42f5bd7b01a3f3c35b21b1879ac391.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ce86621159fc9aaa07f4e1c57247b95',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/4f17616c3ca285785aff93eb13ee45d2.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4440bd86423b9af1ec992186c0d3c29e',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/076c164b6a5056d84d82631f391d5bc9.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce3fc926e9fc54bf0e0dfbc1ce29fffe',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/5a8adcf7033d9534b79a1a3a40a02330.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da8fb8cccc73ff9eb03cc702e53f2a93',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/32e1de0732bb34c6f9da11209d28fc2b.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a21ba1b238bd13ff8fee8eb036b8444d',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/1eb7fc1bd8a6ab0f01967df0ad0b4d78.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e6ca82d55dedf236929775b92c088f54',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/5e259c6cbce01b119800b5242a05fe1c.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1017e4bac1c6d0d992fb36dbc09b8701',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/1dc035db86756cae2a714c205abc2075.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76dd37b20765db291f5c38f073dda21f',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/f994797978161ee2042a43e20ea7fcf0.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f25e4c4e56a3c1b901fa9846ce0f188d',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/d87d269e1d0f3ce972976df9e148431a.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94695eb534b0e0163ccbb7f2d534e2d7',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/56fc13a47f53e433610d861a654fc581.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29bb1c86ca8e1842edb360ef094886f5',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/928b916f73023e4a01cd77bc1f684483.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd335cb97b4a270e77f0cd46c87db9c8',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/a2c65eb6ba9f8848c487f27989dc2d44.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f743b053b5d6178ea7ae44b04bedc37',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/f451f6035f9e766187895ffb2df2731b.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43b208dd529fba3127a4260d5db6c85e',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/128fd2d3260e396abb7f81b3a7b81fc5.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f32525adf3bdaf288bb2362930c297cf',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/6154c0da761be249cf031a9643af6833.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4321c6671ca263c1bb9591edb7ddd78',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/4cea68bd196a9b739499ac60aca46f4e.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '13245fa3da86b03d52f542d43fcdff11',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/41fb5df7f2228b24bd8ec335b5a75111.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fcf1b4af0972e74f01198fb565328f48',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/f006025d03892d28354d2b93555bf417.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3b8008ff9e12b676095195fc820209a',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/ea1d554682508bc6c3c647a541a812e9.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae4982013a5700a7f5022e40f50b48db',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/753bc6cf8fe3ebde9388d4b65fb24d07.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f08dbe54c2f0704f8f5ea97ff2414d1',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/565bafb4d2e1b34f220a52918b001410.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ee329978a693c9484f7d63dbc50e2b68',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/6c9c9b1226eca6082ac1cdac8f60fa2d.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2af8fef78d5dccde08abe651e44d2a23',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/9259d7665c2fb7432407e967db70f7cf.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31dc91a5d8459916826ec9bd4912c957',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/a9196092495eb65a6e5dc8b2a2f4e4d4.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47ea3096121509b214ce8510bcd0de5c',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/b28834af1840ebbcdc0723b3e1e0c032.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0cc49d1312f88035afd4f3e1d7b58f79',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/38c1fd28af28eda1738a3780754f3402.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8953895fa3247b104116ae875a6c1f21',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/93b7e033414423731e4e59d51a9073fb.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1474efbd18cd784301cbbc814da742b3',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/3c8b6b89a17a1eb3a5c8440d1dd7736b.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e305b5d83d87cc328ff33202dcb842c5',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/ff50ef4c110cfc1dd7971bd53c6b58a3.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4f84e4b722cdf4ba3e0846243198fc4',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/44d6e1c35012df17f86a3487b1e9a8b4.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1885263b4ed065b1c33b1501a4245010',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/ea5afa90a607c9415284a9d49d0d3696.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb5697f88a47efab68761077f76a06e5',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/86eea84245396d5f855e5b9575ea8a78.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1cbb91d664283956e69cd781922ce30a',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/0f5b8d49460b4fc1aab5234940140a19.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a949ded0954cc8650c25fd8609a15f08',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/693a802bbb0ba664710f7d66e32b1437.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '79b5ed5b496a6ec23389b85737652b71',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/35e2e5a69dd8f3650b73a708c2c97937.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aca4c159658536242aeb8c644e4fe4b4',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/2af7fe5ec91bc726abf105b5189fd5b4.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '295cde32bd1e29bb1ea56dc49ee05291',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/420677fd91f16a85bfba249697790a25.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6a263a737943a7149c8e3d9a8f696ae',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/f28f49d1ca1aa60d98c240fc3f239831.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a6e0e83c16b05b3ca3e9dc1b57de2ce',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/38f802c5d5a5052fb8a65fe6ce00f26a.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34b12f04f52ac8b7dca9682cae76f116',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/ae0e752950866ba460478a5994422e4f.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8aa7fe8fed9516bf937c1931d44624ee',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/05253006826c1af99be8e7582edf1da2.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39fa48daeea83f3aee93061f82d7685d',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/18b800cfe148f7f94c10eacb5f84508b.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '343d85d0dda83b3cd9b46f233dcddf38',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/79fab5a4cc4d35261f7b9b223bfe1e38.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c449cc9c07a838249972264a608a041d',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/13f4be17ab6c92f2e4f0794276635777.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65e2e1384f4c351290b21c65e4ae0db3',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/77dd803f6f1d296ddf647fc489b5eb26.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bf967c105498e6b23c7c965be0527a0',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/b79f77129b38af8531b9873105de28d5.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cb5db845b7f51d72ca98a0cb7d8c1f6',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/55e8d759ad2a654a7f0267f24bd09cd1.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02d6a90153bb5c31be019504ef90a3f3',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/59aae08b7040eda07a97b4df322caf70.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9acabda319724221960fda753ccb0c7d',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/859e5ca7f21f1e52d0563c55e37cd744.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f72a064dabb604e4fe77cba7fc067021',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/83ee05284e5382d0fb3385778595bf44.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96ad4e40bf6a11fe6a33806f6b69287a',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/933d44b78de41d90c89d2289e0458343.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ec986b4fcbb2560f3a040c61ee1f411',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/a9346b244d44934ef76997760e3e285c.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f91a4b19c657f3d525be7e1f67f8c26',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/ed4365a866489d5ccede986e903dca72.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a80112a76de523125b808f47cabe0831',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/10eea883638cf4fd6cb5f9fb33d88d01.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da5c65ffedbc77f065a0899d49a44198',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/b098b49974ed6bc7f7296b231c3e6564.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00aa0896cd6f307ef2b5588ab7aa5f8f',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/71de2c21a6b52fb1d7620b855fb170b3.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb9f799d377989444bf86045718e5c2a',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/1808fb8a59b309bb38e5328635e67233.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5abac6478ffc9bcca7f895a4aeba896a',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/5120340531236017cc2926c52f628808.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1dafaebf87e8f81f59de7c5c7d7126c6',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/8a7550226f4260424ecf12123b8539d7.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52b003ff87cedac44befced1a61715ef',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/5562851f5a649116d3d62ac47e8cce08.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '460c3a9162d856ebc65e41d537546500',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/38a33d77462a52b7393c67ec3b54eaf2.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1149357607945dad6b0e242c6f3c877',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/24a1f265add48a686491fa9ffb1570f9.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ebd8ea96927f98c0d8ed7aa0f776a05',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/5e1137b893b6bc5031362540bef02e4a.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1450f48ae3627cebfc9837fca39a74fd',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/300b7521b569eef983de756ad53f4386.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a55802b5721d1c664602394944a67847',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/18b9c271b865c432e048234e56a79bf3.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6502002448e06fb9173ea735204433b',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/a037a3d5ce3f7c82b2c2a6c253a5442d.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8dc21ca664b5628baa80ff968e87526e',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/608794a3f3dab5afc07e207e4f4f4e10.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '578753efb232bee86338b6ee3a61776e',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/a326e4cfe1231031b2485e1d295587f5.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d026335b08b2fe1aa90c007a1fe1e7e',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/f28df797b674135a76c40f23a6a6fa50.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '145550614bfa8b7245b083e399b716ae',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/8322d866ee5847770be850312dbdba14.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09eacaf45e8bca4e4a60f7c83e5956e2',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/2693495c3fc43cee24c5bec29562d191.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b66b508dfc7929ddd287083bec695355',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/16605c7983ccf3d61f033b5b933d0b80.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d818ee134910d385cdeb3e4fd96f907',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/1c672698cb97e101f4f4c5bf56f4e164.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a084820d0b1eaf2821bb00ae28e342fe',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/0ae9ea3f499157b4b17d9a66139e9bd1.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3d68c55e31dc1c41336e5e34e2b5aa8',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/3c58fc6f20fc4c32bea9e44c84629b83.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f959cd6d8a8fd5899c0ee65d83c5d7e',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/7b902c162ffd1523ac2ec172e54d2dec.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ad967afec0c5738b616aed4e8b8d1e5',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/4a09a38d225b9b909600e51eff71e447.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd41c4de7a99e73152402eb6acb3dd66c',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/acd5456ac7eb5a62619cc242e98073cd.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd115570ce1580b3e13e9442b0b18e006',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/2106c67847a048b121c3f8fed9abe514.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3362975b644bf73fbedf5c9000b215c',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/fb4d0c9e474c78c25d088a3fb80fc77c.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5269aab0527d2dd8a1d4856fff3dc608',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/c5c592c203a212d8d3d9f7a31739a7da.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '201ae1ffa14065f0a00af1dc9b229968',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/b4250c5fea8fb25cffbec7c30ecf1446.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb711d110228d2bccfdc2e6bfe23afce',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/a1ad961a744b9c15177883ed9008b46f.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b85c1699d9e90dac9a9ef751de87a3e3',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/1caf35c001809b04bfe9d5f2597cf33b.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a86f581b2e0b1e790d35a6ad571c5547',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/a4be026fb2f77e167fbf903f06f03f32.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ba8358d08f4befcdcbd317e8fe981b5',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/ff01dcd0eeed2d515ccba0f02e0a9af9.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c1f6088512c38d667c638957aec275c',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/e391558ebd69d2df4fe067602e1f4142.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c2c6ed9a99fd71f8c534df02fa53b8f',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/531a23ffeb62d9a64696e489c2e05489.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a80c22c607efc32639ec53d2038a0f5d',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/43ae2fc54bb6ae50d93df9b7deed62f7.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b31d20d7134274474d7935849922d8d',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/143981ef603fc6812d011638a1dea698.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22249b6af84fadcc3e2488a807d81367',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/05fc266c0b7907d9d30bacd6f72dd366.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23dfe164e283e524eb6d1de644f6845e',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/58f8bdbede2662c85561aa1f5cd055a1.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98c5f9624809bb183e2713573350fac1',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/3fa522de7ae180299bfb3aac2c61e3ae.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a82157cbf0d88c4cedc1ce2a879c367',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/f611d6c6b953a2255d14c64699653ed5.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '407a24a01347dbb5f19108af5eef91db',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/81f91646d2fd4fffc76d62589c7836c8.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4795cbe7e808dcadd47d5790ef1c26c',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/7fe6ace38120e57e76e0d7862622d260.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e35514f6db64b7a7c54c1835dd628e8c',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/fb5a80aa04e2f1b686daf3bc54d20598.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2565a76f5ba81ea6232cc7689fb5973f',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/c4875a4941e4e47c5ada5adefb5716ee.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa5cc4367f55641cf4b630154e1617fb',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/c159a7a4a749640669d4f75412b369d8.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86caf9a00c9047b36905a54a6ed255cf',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/8676d7cd3092db04d9d68e89dc477059.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4200e1d30b2501b1ee5b7b04307c0742',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/b94e1ffd6f371bc0b62a594dd8e99727.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e54cb22242b1ddac3a01d5c00e67604f',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/1cd184cba85d89e5111a9b4ba67eec66.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3007b910135382d960c3092af27746f3',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/dd55ffdc494d5abd25d0df5d6b62b389.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dc467714135fb44565dce729580bce4',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/fc65e9ad66156799ad728ff0d7ac994a.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e53f590557ccf405a73687a1b3a87b61',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/df6e6617abf3dc642e46bd892143b610.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c31ecea03bbf41bd6d151edb1716ffc',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/2303631c21d7a74cb69698c469cbce9b.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24234ae4e69da9bf9eeb32a1d60eadf9',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/5280be0debdf78c1c1642cb49aa7e24f.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5c6a99939f7bd11b27adbd4e11c27ae',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/12debde6b109177e36456ec5f9e8b553.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a282113d12da2924c7f44e667b8e2084',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/3c2eedad816f8c786001c9fd213baa5b.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cdffe1f1a0fbbaa93443d9f494c6dd9',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/c8215348fae2026a61741735b8dbb8a1.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36d9455fdd7dfe12b25df71ba8fa58ba',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/7f068cd66f680e28119e2b11e05d02bd.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10ed3303ab719bd8f6600ded02a4d956',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/1831ce35434f932ee6092a1ba8778505.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae609f794dbf8f59f6b64ba828e818b0',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/654a00e076a1a0cb8f27b61dcfdbc5e5.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95ad72a36f06d576857a2ec45d71b26a',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/8b0be04256fc4236a3a9d4503ca81f77.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c07cfad903b725983e5a0b5ea080ccb6',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/5baa320a99cc41d4d0ca32876ff42dae.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3e352a1579da080c2aeb7e493582fea',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/696fc793c47cfb1b709e7f41ce9aa767.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43d8617f944c187243563e18e705ec3c',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/a35b238070f1962c3ffdc6fbf952ec29.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec92a027cc8e773764ee0cd34cc9ae02',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/5b28cae6b92f1d26693b275f8eb4637e.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a17ecd1d5533ad787c8282f7ad861371',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/38c6dad03552ea1b99f42dcdf4622dc1.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '105b504977c7afc9b5df650f7e8aae86',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/90807cb55a83589b3f96420bf14f9a43.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa96713d4caa55626f80da048eb12ebe',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/bfc17e2e0aceb812e61d081de0d7b120.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b474e62f38c4f83b0cb95afe546dd856',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/a2d8ed1fc4aaf47dd5e2ea7b7128a228.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0092f8ee0308e195b293f82f393d4f9',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/8732daf0fa215f3010badc69a645b409.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5c92d6bdf1375f7834be380639ebb25',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/c7e7aa6649d8711f106789878a0152d7.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f2f8bb5dabea14869c36a6ba9a3edd3',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/ddf15714e7d2c9e14546b8208dcf711a.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d0e1ece506827ec92dba5f0b3e13293',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/bc2db1476ae7f4a6739c3205e366b352.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46e2cf62415ce6296c5654d12ee39082',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/9000b68edef16c63c795fe205f736997.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10eae9664521325773fc3c02f9ca9aaf',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/5d75644ac85adad4a29a378d97d934bb.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f86a2d946e9a970c95fe7f10b9d16ffa',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/77b3a1b28beca3ea53f42ee1a6cdabc3.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9be2c4fedda5513fcad9fbea6f27c262',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/2b1d37a6a50acab210d2a738c08ca77a.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10ec92d40237192e0f3d70d5087de822',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/e0004e0ee63046a97ca6b5bd2706d1c6.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0b43f0edcfab6ec22f505faefb86473',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/96d628612d7d60840e4b7e2fb58f1d69.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4d7eb509b820fdac12ad41231110e4b',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/b71db4135e1089f165aff7f4a21662a6.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6c063dda057ea06ace74ae907e88d12',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/d6d1ad00ccfafcff962736f5553c8101.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5f31eb4fadb47c84ac203205997fa3f',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/f24e38d91250cb9951b29bc598918840.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8d938f64ead4f195ac84cded4dd8a35',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/7f49860b24a29e61e77be885cb3c380f.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6c2c2a64e27826450ef71ad01183261',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/060583969af8a1a7e6dc6850b7f2a017.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ab72dc793df0e64e32391d1171c96f2',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/ae0c3f71de38de7f0084b33927ecf5f5.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f8bd53280e0917edd116bafe3ff09c3',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/c28ad3cdb5198a6b11c9b33932f72988.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c6f09e5892e6c93ca95676b49a9f483',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/7d2cc6ec85dfab1c79bb7edfd3dd07b1.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2841d11f0292cb5e9273d56c71c0b08',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/7afb0397a6b013075e8bf492659c14d1.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18314a6805e783a2bc0fdc5739b8ba26',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/7680872e083a1533a1c253bad1e910fa.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d8aa47b97f777dfa358d26b3c6f75b5',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/5400050bb6034a6ca20cc7d97f5fa94d.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74822510d341f5351c6199a05b6fcc75',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/0e1dd98b6a1410b4f8dc8d913e052a1f.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7be598d7852535c0a653882a6932492',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/3cf2383549abd651bfa0f061cf55d5a6.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4f9b20f5e447f788f3d58036133770e',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/bc9f5029c1a29f2ae778acab5a280e91.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f5450aa2cdce80d61673449328e9fe1',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/d9b92d99ab1b13086878b833f86e6272.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd1335c8ff33c0809259eaa7ccb1eb40',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/a045dd55912ce3b42e123dfd492dad0f.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee5caf4273c0b24fbdd2ecf02f612faa',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/10e0910abb76552615a85efef275db83.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee622055d7ad774e373626d33bb8f9ba',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/e75e7d77751de2585a55df4b7c0e7334.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d18600144e4bea980a0f7acd5366ca9',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/1241c741bc816a4d41727f9aabfb2170.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6a3cbb490dd0300db838cbf7d96e60d',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/c58cf5302c80504c7f2096027527df78.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '042b03f0efe0c386b9bd3ac16a2c5046',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/e8d98c7f8a89a68693f2349694afc4e0.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d676e14cb9513f7e9a9e67905d31923',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/ec99992480b8d499d3bd1fc58d0988bd.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f8821400a6725da0560af0ecf6efd0a',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/9a40184ed82021e9c3e548f9a671e086.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f986230c1ebb84a9553cf33e87f160a9',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/94250cfaafb323790264eb80dc3ceab7.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5bda560d5e2ebb73ba8798cf4c71ba4',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/b84d1ca20a53ab9047d6b1e188870c52.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '209648c17e74fb9ba7a874d9bf400a55',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/28901c9e584e9de82a68234f80b0bb59.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21c869b2a8e8008432e62f0e5417c1f8',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/070d6c55ac44fd3d9538c8fb280f9d4c.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ded3a7beb567face075e8d886c242a2d',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/3e22b94a42fea3a4d23538391a0e9060.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72663af2723d52ec288361db4ebb8114',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/8423c6ce11a945b27dc4a5293c090421.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '090642f05ddfee1c5801b6553f6926f9',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/b596a07620548ce0026b53da2449e7be.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e12cb6989c76d521abb2e133132922ee',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/a0234a7aa33147317036a1576383b701.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c359b4d41947b002a9ed80b08cb533f2',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/9e0effaf66b5cc7ce1109e8ef09f6cb9.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0e114b6da5ad7de935608066726d1ca',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/77a5bd219fdfbf3eaa5a639b028ae779.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8da47674b04ff37838cb29a430ef11b6',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/e4e57fd263a70f9b48052589982fd65e.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1feb4964a811659ef1417009bb270a14',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/9a4361e4c34ae92e8c8101827ab2477f.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66ca6e05823d7e59f88dbe6c8d6e4671',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/c640a638cd6e0f7d4a495aa52dcf0766.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb5aae8b133c6f8e2a79297900952691',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/b94a7c664e169ee26c7403bfb97a4810.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cda38fd4624eab060a4c1d385e382f3',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/5761894e4dafe5928289ef5c9eb4d072.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63a2f1daa0ee945de671999bf183371c',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/bdc5d11db48a2864b929b52dc87f4a46.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8097863e7a52e3d815942509d9c9e30',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/598110bfa2b53e50ecaa2b4baa09849c.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '581b1a7c2e22743f1caa5410303eb2dd',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/2eebc9ba9976916dc48dd065191192f9.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '021bd2b8c221c6be0edc4bd726a51ada',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/57dcb6543b3c15720df42983de3f8ac7.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f64188cb426718455eb0a4c6c9f3cc5',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/875a6d708d316f9ac0d07c475eca3177.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1b0644a07629dd667b676ade46c8173',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/95bcf4aa8b8b182b0e65388fe8d2ff77.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcf3937a59b0deebc1ce239bb9144995',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/18570116e04e08a61b94f43ed0061904.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8abe420bfbf5abf785356242a44f2f6c',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/1c8a96c504876ce075084f5aa5f3f3b8.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '771b404d6693f4a4fff2f88e8c8a38ef',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/6925e8ee09c6d443cfea2b11a5a4ef7c.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd68eecd86ee601e0d8d009925b5730fb',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/69d33cffdcae383c18ebc30ba5ba82d2.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64c7dad981037289b15104410b815dcb',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/974423dfe5e1c7f2ef72d21484b7f275.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6552db67e27a3b80c0690cb98d67471b',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/38f4941a2c1435b791cafa982eab2bdb.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fa7b46a7da077328bfaf757b61d36d6',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/bc3f6b0c2164e10f1a4cd35227fbc753.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '197975f65367eb78fc7cd242c540a666',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/fb7dec196613b1b4f047ea2ca5be6d83.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7dcf894d80ebdce2575ffdf7c6d22677',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/4721876a56b3ec14c8b4f526a1ab1c99.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcbd83f08598d29f156d380083deca0f',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/08df94a10baabe57cca12f7af933120a.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7e9623fe9e02831af3087a5a0571575',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/45878bcbd55ef2dfe0c6d7d3783546e8.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3a10e7186fdc834b683c0a3200e5d01',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/1c14e9ad608068085ebe8b04b0cb7877.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '030a47156d9e03a5be137b0904c8762d',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/6dfc1c58026d7d601aecc75ff5225207.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1b40b2da649c2609dc3648ab86e8597',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/8f073ac33f6bce3cf33bc05d7afe8f3a.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab708df0d0e7e1e6270fa834491876f7',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/a132f4bad458ffe7136b4ef61f9c75f7.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd489bb9cd8927b2a4ad65da1af5eb2a7',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/01ef94b80d781800787eb2aefde1f11e.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '666ed860fd0180ee037dc0c7b826ee7c',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/2c1587408ec9e44dcc0bb8d5e73d31ff.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c11bd36aae092ccd44185b55f8326a21',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/ea4655e884a8eac08d337aa07bbe93a1.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '595feeea814c8b9a982d15e0aaf24112',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/7eccc45ff4d89378ac257db3c3a6fcd8.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ad7b1716e098d50a0c422480071fc2d',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/fac219e1ac7b0d6a702a750e36e912f8.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83abd53c9acd967f676f06000c391d36',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/8acb11077185da0d7de9223f331f8587.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a97fb2a270365103ce044abb8d45c8d9',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/34a369ee50dad7bd9efcc13cdda90aeb.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdccc2606507b0ba9295e6b8daa99e85',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/9ea4ec759577eeab91292363560a6fb8.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41f205def22ffc04bb55249cf2ac46ba',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/122436c9af81d9ac7e3199ab916c6a74.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e224e964161b95dd9ed940aa5ec6f5f',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/198f0fd5c7812f3bfb72b3c879d07a00.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef43b89629ebb554b55fb3b132a8ac28',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/7741cebbdff3834c43cbc4750274df20.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd636704763b1fcd2254e91b9a9dff818',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/8d0c0d8fdd2b68d32623c240611cee96.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b446ad9d44e41d427c4894fbba33d8de',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/8d6e574d57cc17354bbdfa5117371901.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3651da85947afecb4a892ad1ef71e818',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/62e4b7470afab986af23f940e78d5710.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f6fa8b3114aed382dc7192b67f93321',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/28afd06a6e137c22c27d1ca8f5289047.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e419470cf0d58e48c7d129d727c547bb',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/dee20637963e0554c318a6425bd93b2a.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eeb37f9e2e96817e2c255a535059aaaf',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/d56a9e2e28898bedd15a16662ced6682.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72111651524b5cf223ef5727a5b4011e',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/65a45997d7c8eb1cf1a1f315901c3737.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdabf88283b0cccb513b33e258eb994f',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/147037d78564f10cee069ee8a07801a2.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6c7faad9cafba424b7f22664d87a8b9',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/d73a91a20dc690f6f07092593976a1b1.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '654c0a9ca9509c90da74ef8c8c8fb326',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/b7ea249f55dbabe537970f937709ccd2.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46665e245b0b15d1dedc0da014826a53',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/d1e22dae70129f9f53c8b0c4a7001e72.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea0ec229ee4ad03c1f2670068f8677a6',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/1e4a13871c095f957da2e2173c3740ee.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7797930d050764ffbcc9dd90945e411a',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/47d1325b82f3f2f4b6bf214ab93c16b9.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20add6218a95c3f40ab39fac19a879f6',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/5f710286be681156ba36aa9b9c179c7b.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53323cc4338d0212c08f8579bfa9ef55',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/0c1494d12414ff7b9de8c9ff39d24859.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '775984dd253b26a350b8c1ddb254bbdb',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/94b6486ef64d48d82907064f243425eb.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '707d1645777d08274eee09a620d67451',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/1608e5c9a6b5a6793e10e740d7c094f7.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4849a39bb064a03ec4281577a108d7ca',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/73647e4578dd13a79eb5547aff0989bf.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5288cd4e28b13e8981eb8a2bf8575567',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/5c80d350ff471bb082963ab9ce5e4db2.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66c4e6ecdcc2bb2f32ba3bc8fe12c6fa',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/ec42bd6cca54cf595916a6642c1ecaa0.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '797b87902d78f3a017138d2229c2ce2a',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/378f63ade40bb5f806ee680777f822c3.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40c1a5f0a02b71bcdf635b131de39ed8',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/466e0f456305ba7a793513c4d063e9c5.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8165f81887ed7667846e2bc1c57feff7',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/18009e45a934a5c84cd11c7a193c7598.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37bd2f62578a2ef921272a72d5b2e355',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/60d38058e757826fc55d85db05f04242.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09a2d9734e7951fcd41e6c0d9ab01e92',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/bcd51aa6b20d893688908a67f0250001.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89b3605e66a078cb364ccf2a090c6634',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/ce45175023fb465f065c7af9dbb0c7fd.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22e2ea757610e1749fd3b73cfdc3de66',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/2be3e2b3e37e98dac5462614dfc6a582.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e47fe30a65da2291c21978a4e1c6b2ef',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/459bdd806c04e6666383e50871f1ceef.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9fa613493492202650bf453c1d3ea9d',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/2a6805947f991c8667e3cc48163c1f69.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b27d20ed01804c345c9ff7852816a34b',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/9043ab4945e12603cb575661ef6b81ab.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4eaaef76bebf5b18d16b04200e80646a',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/705292b1d18b8b613a57ba30c1696518.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e52585f03a1aa39745a2f744be6e6d7',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/7682a173161ac582cdce6baefa3f80b0.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '311cd3cf4bbc51dbee1a4c0dd0fcecb5',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/67a2dae36219dfcdd3020e4777555740.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0ac05512075c2355828ce492ad797df',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/3a8705fd4fa3b72f48c88a1351ff71f4.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23474b1386f576a961cab9118289931d',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/83147d67e56f16656291d527a6514c16.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6ebda48d9312fae6e2f77d26af77034',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/60a3107045ea2b7c83e655603cc28fd1.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbf069ee47faf6d3d22981c9173f75b2',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/0a85e714d0a9dc437e0e0ebcaef13644.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2f988cd2464764fed01e8d0422f5a9c',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/5f2ca4281361a9e8a96693c691e75376.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '941a5ceef8ba62b6df968e830271114c',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/3f70bd1372697933204edd5e9387f17a.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17efa0ca62a238c8f015e06965545d0a',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/c3cfb4f16a8c535bcf3f4cabba042cae.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99b7d1e41830cda132fbd646eef42f03',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/3ce7c20bccab812825e1a8a52357fa69.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06dad257c5dbf4b51f927df3fcdc88c9',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/35d0401e04806f2391b1528c598ba377.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30e611ca052fc85fa5b79ab9cf04e601',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/db90b6209c0040863b4c61dc34b9474f.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '644e1213dae992036cf1898b5a8fa931',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/5167a58b2c25fb82873e30a7219ba9a9.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45cc535c704eb9e0751fa49499792141',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/8ad0179a53a76c64cb8a5c1777eea033.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2d899f0d02d39ef0eabe1d789f5e1b9',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/39ad6b45d90fe43155ce4d17eb9fd62b.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a0dccd7fa076de72797b1138ecab564',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/3eab1a3d789d6106ecaaaa263eb1e682.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94a4a21db2588f1f583d84bba3a4b695',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/1bbeee0aadfbc183318a4637dd8b3b47.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ea46d87e22bd2277c307429d11f322d',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/2f651a0e81e25b30fcf41ae4a403da34.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e6ce99847f493abc81a7fe609af948b',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/668e0f1d22ede60a086eb6261e185034.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c2414357f18361631de418b1e54679f',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/c3f1aa70d0fab8669bfd9f944aceb11b.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39a5f37bc3226a28c144043e2280482b',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/2da241f1fa661254dd9f67a968ba4362.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb241e1d478db4e24ebbc6cb3010e170',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/35a6d1d38444bd0be4947b191518f142.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c836c6a1dea53d2770c60d957120c63',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/d8a2e21b3de0110a047994a0c8990d28.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66090bdb76aa37efd26a2e8722d84951',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/6962cd634bb3769596e50b512f0d52c0.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17a5bc44c35dfb588724b75a2b3bc3bf',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/0067dd67fa76058623105d874eab92c9.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fa7c27dd7cd8f2e3b1a6c7dcf3b8d85',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/27083258012166ca35fec944d41042f6.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '526f280ce311e258cc61e055ef2744fb',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/992fb214aae35dfbb4ee635c13666381.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be6b85efd38cc41c36d2fec160788ae2',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/9e349cad5891b380b0c66ff08ad0948e.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'a19f487e966b197896cceba1badebf20',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/123a904c333978e500a5e1add340eaf0.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'e9165c1c1d8fdede22811e249925ce98',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/1856db28e98781536a7dcbe7eb7db33b.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'cbdd4533f4abcd12cb94b9de10189ec2',
      'native_key' => 1,
      'filename' => 'modUserGroup/8eb5d8e07b219b53c28cc9cf05479e19.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '784befee138a374b64c4d12a5f3e5aa6',
      'native_key' => 1,
      'filename' => 'modDashboard/3193663f8166feafeae362124a194bc2.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '610e43ceab1d2ac1eabcb83f615d606e',
      'native_key' => 1,
      'filename' => 'modMediaSource/1352d33ced584ab4353ce8646c042429.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '164b48d05b9928463ae6b2910be930df',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/6f4bec3c3aee4f3f7b2d155a49c6ca5f.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '5da76d333dea573a8aab9ca3e6c32199',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/4cf9d302ac2d41629bc2eddc16f74d15.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '6629c48d7b7f014486668e954edaea2b',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/6caf8be88fc97464c4694c4787d27e69.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '25fdc946410afa429dd161fed2095e6e',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/79cdbc81e39de75124091c41ba4dbe1d.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'efb80c8f6a5ebeefe92d61b3774063e8',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/fa06e811c3955f6d5e4da15aebc04a37.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'd29eded82cfb28ec015fe47103cd6a4e',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/79a4f3cf8552b956ee6ec48475d575f9.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '692ab95e2dc2ffb17dbf1b11fe6c3a27',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/662c25a061c60f6e894518381bd3f167.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '7b748766833d2529fc97a2c1436b9ac3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/227d5f553c0bbe4f1512102edd0981a0.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '2345d7f3ab4f30c95e45f653bdfb17ac',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/e08e2eda77549f95be068f1a939778ba.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '5d9408ee67df1eef40138dfa134d112e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/d15b64321fe7657f7c2374fb7a68962f.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '278c9fce5c5dacd5cea1acf20a6e9e96',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/564efb75ef980aac4220efd4626d8ba8.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '33389ee070af58d7b893329b46f37618',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/d84a40a8a5ecb29db41fa974f26e2791.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '2edc43ca56bf972d8310e11cf1a57a5b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/9f25c46e3ed0381d678c7cb41e05fa22.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'acdc6b52f909958c92abc75b1831569d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/dbd6506f107d5295b8ac4daa04bbca16.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '82ccdaa310f3ad5a38a5aa98b36c83af',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/33130be749808121a3ceef8920e1f245.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '9cf6edcc35096d8eab441e55ab22d2de',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/03ded2bde674add9fbc3d31a3655946d.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '4c74a6ac00e85e66fbf0143326213a4f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/d44308ebff7e17d9fe3c64c9620838de.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '9ac585baec25d3a86488d0c0fa722044',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/17ec4751285655f2de7ccbd711073538.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b7bd78e28d938874070bad78d8828d3a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/215b23c9ee4175cea13cb714aff50251.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'c9b2017687e1b3d63cdc224b0b3bf421',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/015321e69218f00049612c9142dc0aa7.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8e7fcf4ca11f9213cc7e7b77af21f0df',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/6542b73a1a3ae3ed4f850bbe6ca26573.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1fe20dea50c0811ed4c2a4ce4addec27',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/f52d73c09ea3f65de339f59262426eec.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e0a37207ae337aca76f6f109209d1e34',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/917a364f59363575de8e6cc106e3ed19.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f010a700d1904b03b7374ef4883b74b7',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/18af6a4323d07a000a69918d578757f4.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7a488ff547d67c980e16f73157e8da62',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/ffb5d7c3c515839d6f2130e52afffb22.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7c4c4372bb1a533686f730262c40d80c',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/7ba58a097e1b40b16b472d905c850b91.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '37e0ca1f3fdbc2a46d0aca4b62db20a7',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/52b2de26c7a087a1caee258bf3b71265.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9bbd38c104286702fd3c37b822050ede',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/1fab868b3ab7f42d916e14d9475fff11.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '93aeee3c1c574fc2b99c85a6bfaa2ae3',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/91af8f86e5a558336a84995fd3acc0b2.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'de2e615a0ec5f3b3faa7b7aef9337107',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/cabc0b9a488efa6763b625455fbce358.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7efced20564e38590c96999aff66e370',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/d1aeb3a20fc2585e05fa0d3ad1912ee0.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0eefb5551fc8a1c6e6f73e9bcf3a0bbe',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/947c04a7131e82fd86946f4076db1770.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '6227056cf9361d36346b2a35e3de59e7',
      'native_key' => 'web',
      'filename' => 'modContext/2c3d5376de6fae1db80cbbef3c4d0893.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '3f53e7c01e0ee5a8c6b0b3383ec2f4ad',
      'native_key' => 'mgr',
      'filename' => 'modContext/d4e61e8b8dd76b87edb76319d3a04856.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '4729e61aca0e19bd4e40a4f3513e2ac7',
      'native_key' => '4729e61aca0e19bd4e40a4f3513e2ac7',
      'filename' => 'xPDOFileVehicle/a4b221f1343fbbe33bb9149436ba17a8.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '34ec8aca3ccfd4c5b9f1b5d603038306',
      'native_key' => '34ec8aca3ccfd4c5b9f1b5d603038306',
      'filename' => 'xPDOFileVehicle/1b5c46bc41963d380d74bea16a22f37e.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'be7b2788e3fd60ded23d29791ad111f5',
      'native_key' => 'be7b2788e3fd60ded23d29791ad111f5',
      'filename' => 'xPDOFileVehicle/c83ec2fe51d3492f7ba56545224d9ab1.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '0e447a8a87bf6ac656dad097bec2e4c1',
      'native_key' => '0e447a8a87bf6ac656dad097bec2e4c1',
      'filename' => 'xPDOFileVehicle/921f366a1e56e18ae735092790f875a8.vehicle',
    ),
  ),
);