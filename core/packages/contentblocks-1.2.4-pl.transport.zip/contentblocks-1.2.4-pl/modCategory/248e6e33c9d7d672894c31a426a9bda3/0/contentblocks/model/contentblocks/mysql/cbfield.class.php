<?php
require_once (dirname(dirname(__FILE__)) . '/cbfield.class.php');
class cbField_mysql extends cbField {}
