--------------------
Snippet: QuickEmail
--------------------
Author: Bob Ray <http://bobsguides.com>

A simple snippet for sending email and diagnosing email problems for MODX Revolution.

Documentation:
http://bobsguides.com/quickemail-snippet-tutorial.html

Also: Edit the QuickEmail snippet and click on the Properties tab.
      Click on the plus sign next to any property to see its description.

Bugs and Requests:
https://github.com/BobRay/QuickEmail/issues

