<?php
/**
 * Default German Lexicon Entries for templateselect
 *
 * @package templateselect
 * @subpackage lexicon
 * @language de
 *
 */
$_lang['choose_template'] = 'Template für neue Ressource wählen';