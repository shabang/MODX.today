<?php
/**
 * Default English Lexicon Entries for templateselect
 *
 * @package templateselect
 * @subpackage lexicon
 * @language en
 *
 */
$_lang['choose_template'] = 'Choose a template for the new resource';