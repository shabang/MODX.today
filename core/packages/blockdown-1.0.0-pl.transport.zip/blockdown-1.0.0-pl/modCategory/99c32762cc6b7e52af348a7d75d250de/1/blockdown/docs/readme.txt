--------------------
	Extra: blockdown
	--------------------
	Version: 0.1.0
	Created: June 16, 2015
	Author: JP DeVries <mail@devries.jp>
	License: MIT

	Adds the EpicEditor Markdown editor to ContentBlocks for MODX Revolution.


	Please see the documentation at:
	https://github.com/jpdevries/blockdown/

	Thanks for using blockdown!
	JP DeVries	
	mail@devries.jp