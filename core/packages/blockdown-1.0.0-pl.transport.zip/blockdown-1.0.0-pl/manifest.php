<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2015 JP DeVries

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '--------------------
	Extra: blockdown
	--------------------
	Version: 0.1.0
	Created: June 16, 2015
	Author: JP DeVries <mail@devries.jp>
	License: MIT

	Adds the EpicEditor Markdown editor to ContentBlocks for MODX Revolution.


	Please see the documentation at:
	https://github.com/jpdevries/blockdown/

	Thanks for using blockdown!
	JP DeVries	
	mail@devries.jp',
    'changelog' => '++ blockdown 0.1.0-pl
++ Released on 2015-06-16
+++++++++++++++++++++++++
- Initial Release
- Adds EpicEditor Markdown Editor to ContentBlocks

',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9c21422d29bda4dbeccb5811984d11c8',
      'native_key' => 'blockdown',
      'filename' => 'modNamespace/f668e72989a82a41146fa73bb85cc463.vehicle',
      'namespace' => 'blockdown',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0e53b368e7f601f0fcea41b9d1a7ce54',
      'native_key' => NULL,
      'filename' => 'modCategory/99c32762cc6b7e52af348a7d75d250de.vehicle',
      'namespace' => 'blockdown',
    ),
  ),
);