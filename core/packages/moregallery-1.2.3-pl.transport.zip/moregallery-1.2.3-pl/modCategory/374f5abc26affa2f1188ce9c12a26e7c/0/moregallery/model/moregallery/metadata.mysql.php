<?php

$xpdo_meta_map = array (
  'modResource' => 
  array (
    0 => 'mgResource',
  ),
  'xPDOSimpleObject' => 
  array (
    0 => 'mgImage',
    1 => 'mgTag',
    2 => 'mgImageTag',
  ),
);