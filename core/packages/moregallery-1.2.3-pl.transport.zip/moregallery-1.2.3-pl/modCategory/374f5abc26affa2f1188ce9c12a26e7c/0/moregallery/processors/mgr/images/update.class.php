<?php

/**
 * @package moreGallery
 */
class mgImageUpdateProcessor extends modObjectUpdateProcessor {
    public $classKey = 'mgImage';

    /**
     * Unset bunch of properties we don't want touched.
     *
     * @return bool
     */
    public function beforeSet() {
        $this->unsetProperty('mgr_thumb');
        $this->unsetProperty('file_url');
        $this->unsetProperty('exif');

        return parent::beforeSet();
    }
}

return 'mgImageUpdateProcessor';
