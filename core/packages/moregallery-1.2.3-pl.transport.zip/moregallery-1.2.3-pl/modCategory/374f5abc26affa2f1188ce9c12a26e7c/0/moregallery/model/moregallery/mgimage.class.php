<?php
/**
 * Class mgImage
 */
class mgImage extends xPDOSimpleObject {

    /**
     * @param string $keyPrefix
     * @param bool $rawValues
     * @param bool $excludeLazy
     * @param bool $includeRelated
     *
     * @return array
     */
    public function toArray($keyPrefix= '', $rawValues= false, $excludeLazy= false, $includeRelated= false) {
        $array = parent::toArray($keyPrefix, $rawValues, $excludeLazy, $includeRelated);

        $resource = $this->getResource();
        if ($resource && $resource->_getSource()) {
            $relativeUrl = $resource->getSourceRelativeUrl();
            $array['mgr_thumb_path'] = $resource->source->getBasePath().$relativeUrl.$array['mgr_thumb'];
            $array['mgr_thumb'] = $resource->source->getObjectUrl($relativeUrl.$array['mgr_thumb']);
            $array['file_url'] = $resource->source->getObjectUrl($relativeUrl.$array['file']);
            $array['file_path'] = $resource->source->getBasePath().$relativeUrl.$array['file'];
            $array['view_url'] = $this->xpdo->makeUrl($resource->get('id'), '', array(
                $this->xpdo->getOption('moregallery.single_image_url_param', null, 'iid') => $this->get('id'),
            ), $this->xpdo->getOption('link_tag_scheme', null, 'full'));

            $array['_source_is_local'] = ($resource->source->get('class_key') == 'sources.modFileMediaSource');
        }
        return $array;
    }

    /**
     * @return mgResource|null
     */
    public function getResource() {
        return $this->xpdo->getObject('mgResource', array('id' => $this->get('resource')));
    }

    /**
     * Removes files along with the image record.
     * 
     * @param array $ancestors
     *
     * @return bool
     */
    public function remove (array $ancestors = array ()) {
        $resource = $this->getResource();
        if ($resource && $resource->_getSource()) {
            $relativeUrl = $resource->getSourceRelativeUrl();
            $resource->source->removeObject($relativeUrl.$this->get('mgr_thumb'));
            $resource->source->removeObject($relativeUrl.$this->get('file'));
            if ($resource->source->hasErrors()) {
                $errors = $resource->source->getErrors();
                $this->xpdo->log(xPDO::LOG_LEVEL_ERROR, 'Error(s) while removing file(s) for mgImage ' . $this->toJSON() . ':' . implode("\n", $errors));
            }
        }
        $this->clearCache();
        
        return parent::remove($ancestors);
    }

    /**
     * @param null $cacheFlag
     *
     * @return bool
     */
    public function save($cacheFlag= null) {
        if ($this->isNew()) {
            $this->set('uploadedon', time());
            $this->set('uploadedby', $this->xpdo->user ? $this->xpdo->user->get('id') : 0);
        } else {
            $this->set('editedon', time());
            $this->set('editedby', $this->xpdo->user ? $this->xpdo->user->get('id') : 0);
        }
        $saved = parent::save($cacheFlag);
        $this->clearCache();
        return $saved;
    }

    public function clearCache() {
        $cacheOptions = array(xPDO::OPT_CACHE_KEY => 'moregallery');
        $resource = $this->get('resource');

        $this->xpdo->cacheManager->delete('mgimage/'.$resource.'/', $cacheOptions);
        $this->xpdo->cacheManager->delete('mgimages/'.$resource.'/', $cacheOptions);
    }

    /**
     * Gets the image before this one.
     *
     * @param string $sortBy
     *
     * @return null|object
     */
    public function getPrevious($sortBy = 'sortorder') {
        $c = $this->xpdo->newQuery('mgImage');
        $c->where(array(
            'resource' => $this->get('resource'),
            'AND:'.$sortBy.':<' => $this->get($sortBy),
        ));
        $c->sortby($sortBy, 'DESC');
        $c->limit(1);

        return $this->xpdo->getObject('mgImage', $c);
    }

    /**
     * Gets the image after this one.
     *
     * @param string $sortBy
     *
     * @return null|object
     */
    public function getNext($sortBy = 'sortorder') {
        $c = $this->xpdo->newQuery('mgImage');
        $c->where(array(
            'resource' => $this->get('resource'),
            'AND:'.$sortBy.':>' => $this->get($sortBy),
        ));
        $c->sortby($sortBy, 'ASC');
        $c->limit(1);

        return $this->xpdo->getObject('mgImage', $c);
    }

    /**
     * @return array|mixed
     */
    public function getTags() {
        $co = array(xPDO::OPT_CACHE_KEY => 'moregallery');
        $tags = $this->xpdo->cacheManager->get('tags/image/'.$this->get('id'), $co);
        if (is_array($tags)) return $tags;

        $tags = array();
        $c = $this->xpdo->newQuery('mgTag');
        $c->innerJoin('mgImageTag', 'Images');
        $c->where(array(
            'Images.image' => $this->get('id'),
        ));
        /** @var mgTag $tag */
        foreach ($this->xpdo->getIterator('mgTag', $c) as $tag) {
            $tags[] = $tag->toArray();
        }

        $this->xpdo->cacheManager->set('tags/image/' . $this->get('id'), $tags, 0, $co);
        return $tags;
    }

    /**
     * Resize the image to a smaller one for use as mgr_thumb
     *
     * @param $content
     * @param int $width
     * @param int $height
     * @return bool|string
     */
    public function createThumbnail($content, $width = 250, $height = 250) {
        try {
            require_once dirname(dirname(dirname(__FILE__))).'/model/phpthumb/ThumbLib.inc.php';
            $thumb = PhpThumbFactory::create($content, array(), true);
            $thumb->resize($width, $height);
            $thumbContents = $thumb->getImageAsString();


            $mgrThumb = $this->get('id') . '_' . md5($this->toJSON()) . '.png';

            $resource = $this->getResource();
            $resource->_getSource();
            $path = $resource->getSourceRelativeUrl();

            $resource->source->createContainer($path . '_thumbs/' , '/');
            $resource->source->errors = array();
            $resource->source->createObject($path . '_thumbs/', $mgrThumb, $thumbContents);
            $this->set('mgr_thumb', '_thumbs/' . $mgrThumb);
            return true;
        } catch (Exception $e) {
            $this->xpdo->log(xPDO::LOG_LEVEL_ERROR, '[moreGallery] Exception while creating mgr_thumb: ' . $e->getMessage());
            return $e->getMessage();
        }
    }
    
    public function loadExifData($file) {
        if (function_exists('exif_read_data')) {
            try {
                // Fetch EXIF data if we have it.
                $exif = exif_read_data($file, NULL, true, true);
                if (is_array($exif)) $this->set('exif', $exif);
            } catch (Exception $e) {
                $this->xpdo->log(xPDO::LOG_LEVEL_ERROR, '[moreGallery] Exception while trying to read exif data: ' . $e->getMessage());
            }
        } else {
            $this->xpdo->log(xPDO::LOG_LEVEL_WARN, '[moreGallery] This server does not have the exif_read_data function installed. MoreGallery cannot extract exif data now.');
        }
    }
}
