<?php
/**
 * Class mgImageRemoveProcessor
 *
 * @package moreGallery
 * @affects mgImage
 */
class mgImageRemoveProcessor extends modObjectRemoveProcessor {
    public $classKey = 'mgImage';
}
return 'mgImageRemoveProcessor';
