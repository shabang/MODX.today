<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MoreGallery is proprietary software, developed by Mark Hamstra for modmore. By purchasing MoreGallery via https://www.modmore.com/extras/moregallery/, you have received a usage license for a single (1) MODX Revolution installation, including one year (starting on date of purchase) of email support.

While we hope MoreGallery is useful to you and we will try to help you successfully use MoreGallery, modmore is not liable for loss of revenue, damages or other financial loss resulting from the installation or use of MoreGallery.

By using and installing this package, you acknowledge that you shall only use this on a single MODX installation.

Redistribution in any shape or form is strictly prohibited. You may customize or change the provided source code to tailor MoreGallery for your own use, as long as no attempt is made to remove license protection measures. By changing source code you acknowledge you void the right to support unless coordinated with modmore support.
',
    'readme' => '--------------------------------------------
MoreGallery - Awesome Gallery for Revolution
--------------------------------------------
Author: Mark Hamstra - support@modmore.com
--------------------------------------------

MoreGallery is an awesome Gallery add-on for MODX Revolution that puts your galleries where they belong - in the Resource tree. Optimized for speed and an awesome user experience, MoreGallery takes galleries in MODX to a new level.

For more information on features and how to use them, please refer to https://www.modmore.com/extras/moregallery/

MoreGallery includes icons created by Daniel Bruce, licensed as CC BY-SA 3.0.
',
    'changelog' => '++ MoreGallery 1.2.3-pl
++ Released on 2015-01-29
+++++++++++++++++++++++++
- Fix upload issue when image contained invalid EXIF data

++ MoreGallery 1.2.2-pl
++ Released on 2015-01-19
+++++++++++++++++++++++++
- Fix image alignment issues with screens of exactly 1600px wide
- Updated translations (see https://crowdin.com/project/modmore-moregallery)

++ MoreGallery 1.2.1-pl
++ Released on 2014-10-28
+++++++++++++++++++++++++
- Fix potential issue on PHP 5.5/6 related to exif data
- Change how the "Add Gallery" button in the toolbar is loaded so it also loads on components (thanks Wieger Sloot!)
- Change "Add Gallery" button to use Font Awesome in 2.3.
- Small speed optimization for large galleries (thanks Rico!)

++ MoreGallery 1.2.0-pl
++ Released on 2014-08-04
+++++++++++++++++++++++++
- Fix issue filtering on non-existent tags
- Fix icon in the resource tree in 2.3.? (depends on modxcms/revolution#11736)

++ MoreGallery 1.2.0-rc1
++ Released on 2014-07-18
+++++++++++++++++++++++++
New Features:
- By default set source, relative url and content position to "inherit" so they continue to inherit system defaults after save.
- Allow dragging resources into the image URL field for quick insertion
- Add ability to control placement of image IDs into image file name
- Add ability to prevent the gallery ID from getting added to the file path
- Add ability to use sortBy=`random` with mgGetImages to get random images from cached data

Improvements:
- Improve ContentBlocks compatibility with some styling tweaks and support for content-in-tab
- Improve compatibility with Tagger (Thanks TheBoxer!)
- Make sure TinyMCE is initialised when editing images
- #65 Strip out unnecessary data from AJAX requests that could trigger mod_security errors
- Adjust resource validation to allow for derivatives
- Add [[+idx]] to the tpl in the mgGetTags snippet.
- Added Swedish translation
- Add snippet properties to build
- Improve UX on adding tags to images by indicating you need to add it with a button or enter
- Update styling to match Revolution 2.3

Bugfixes
- Fix z-index issue with fixed toolbar
- Fix issue loading wrong media source when using import from file feature
- Prevent "`[[+resource.id]]` is not a valid integer and may not be passed to makeUrl()" errors
- Fix javascript issue causing gallery initialisation to fail when the resource tree is not available.
- Make sure the total results is set when data is retrieved from cache
- Fix TinyMCE rendering in image description

++ MoreGallery 1.1.0-pl
++ Released on 2014-01-25
+++++++++++++++++++++++++
New Features:
- Add Tagging functionality: back-end adding of tags, mgGetTags snippet to list tags and updates to mgGetImages to filter on tags and added [[+tags]] placeholder
- Import file into the Gallery by selecting it using the MODX Browser
- #55 Sanitise file names on upload

Fixes:
- Fix toolbar to top of the manager when it goes out of view due to scrolling
- Fix broken images in back-end when using remote media sources (like S3)
- #54 Make sure the container is resized upon opening a full image view modal
- #56 Fix errors being logged due to caching check

Improvements:
- Gallery Toolbar now stays in view when scrolling past it
- Change icon set to sprite-based icon set
- Updated Danish translation.

++ MoreGallery 1.0.2-pl
++ Released on 2013-11-06
+++++++++++++++++++++++++
- Add Danish translation

++ MoreGallery 1.0.1-pl
++ Released on 2013-11-06
+++++++++++++++++++++++++
- Add getResourceFields and getResourceTVs properties to mgGetImages to include fields or TVs placeholders.
- Only use the FileReader (for image previews during upload) when it is supported.
- Fix small content field if there\'s no RTE in use.
- Add French translation.

++ MoreGallery 1.0.0-pl
++ Released on 2013-10-30
+++++++++++++++++++++++++
- Prevent toolbar icon from being duplicated after saving a resource.
- Tiny fix to the CSS to prevent left box shadows from disappearing from the first image in each row.
- Prevent annoying jump in image previews when the image completed upload.
- Added Dutch, Czech, Russian and German translations.
- Extract text into a lexicon file for translation.
- Clear the MoreGallery cache when using the Site > Clear Cache menu option.

++ MoreGallery 0.9.16-pl
++ Released on 2013-10-15
+++++++++++++++++++++++++
- Fix fatal error in snippet.
- Fix issue with content location setting.

++ MoreGallery 0.9.15-pl
++ Released on 2013-10-12
+++++++++++++++++++++++++
- Handle exotic image type errors without triggering E_* errors.
- #25 Open full image in a modal instead of new tab
- #23 Change mgResource\'s to modDocument\'s during uninstall
- Add icon to create new gallery to the resource toolbar (can be disabled with add_icon_to_toolbar setting)
- Add single_image_url_param setting to change the "iid" url param to something different.
- Set the top position of the modal so it\'s within view.
- Fix loading of relative_url setting on resource panel (introduced in 0.9.13)

++ MoreGallery 0.9.14-pl
++ Released on 2013-10-08
+++++++++++++++++++++++++
- Implement better UI through usage of modal window for editing instead of weird sliding panel.
- Refactored to use jQuery UI\'s sortable plugin, while bigger it provides a better drag experience.
- #36 Check memory_limit on server and alert if file is probably to large to resize once uploaded.
- Fix issue creating images with MySQL 5.6 (columns always need a value, default or accept null.)
- Add feature to load RTEs into the edit panel (enabled by default, setting moregallery.use_rte_for_images)

++ MoreGallery 0.9.13-pl
++ Released on 2013-09-27
+++++++++++++++++++++++++
- #38 Hide content field or move it below images or into a new tab
- Add [[+image_count]] placeholder to wrapper tpl.
- #40 Properly load default options (source, url) from system settings on creating a new gallery.
- Fix weird issue with specific environments

++ MoreGallery 0.9.12-pl
++ Released on 2013-09-02
+++++++++++++++++++++++++
- Add some indices for additional (uncached) performance.
- Add "Resource" relation from mgImage to mgResource.
- Fix mgResource>mgImage relation from one to many
- Fix improper class_key setting.

++ MoreGallery 0.9.11-pl
++ Released on 2013-07-29
+++++++++++++++++++++++++
- Add relative_url and source settings to Resource > Settings tab to manage properties.
- Improve focus handling with auto save.
- Set "name" field of the image to the filename without extension by default.
- Improve error messages when upload fails.
- Accept empty value for moregallery.source_relative_url setting (ie, root of media source)

++ MoreGallery 0.9.10-pl
++ Released on 2013-07-23
+++++++++++++++++++++++++
- Add moregallery.source_relative_url and moregallery.source setting.
- Add error (and remove uploading image) if upload failed.

++ MoreGallery 0.9.9-pl
++ Released on 2013-07-21
+++++++++++++++++++++++++
- Fix annoying and broken reload when saving the resource

++ MoreGallery 0.9.8-pl
++ Released on 2013-07-19
+++++++++++++++++++++++++
- Lots of CSS tweaks to make it integrate better with latest 2.2/2.3 design.
- Add ability to link to resources by entering the resource ID.
- Add proper uploading image for images > 700kb.
- Fix loading RTEs.

++ MoreGallery 0.9.7-pl
++ Released on 2013-07-16
+++++++++++++++++++++++++
- Fix E_WARN error on certain environments.

++ MoreGallery 0.9.6-pl
++ Released on 2013-07-16
+++++++++++++++++++++++++
- Fix z-index conflicts with #modAB when editing images.
- Auto focus on name field when opening edit panel.
- Further improvements to performance of the manager, especially when uploading large images:
- - Minimize re-renders of backbone templates
- - Only show image previews for images that are smaller than 700kb to preserve the browser
- - Use data URIs to prevent additional requests for first 20 images in list, and freshly uploaded images.
- - Delay upload by 1s to let the browser do one thing at a time.
- - Only load full size images when opening the edit pane

++ MoreGallery 0.9.5-pl
++ Released on 2013-07-15
+++++++++++++++++++++++++
- Improve browser performance during upload.

++ MoreGallery 0.9.4-pl
++ Released on 2013-07-15
+++++++++++++++++++++++++
- Fix LOG_LEVEL_WARN error "Could not load package metadata"
- Fix prev/next when sortBy is not sortorder or with a descending sortDir
- Add resolver to increase upload_maxsize from 1MB to 10MB on install.
- More sensible (pretty) default chunks.
- Add uploadedon, uploadedby, editedon and editedby fields to images.
- Add ability to paginate through images with getPage
- Add check to make sure chunks referenced are still the same. Removes need to disable &cache.
- Remove dependency on phpthumbof for default chunks.

++ MoreGallery 0.9.3-pl
++ Released on 2013-07-14
+++++++++++++++++++++++++
- Add helpful note to indicate you can drop images into the gallery.
- Improve drag/dropping behavior between sorting and upload.
- Fix issue with uploading images when exif_read_data is not available.
- Make sure link_tag_scheme is used for generating of view_url.

++ MoreGallery 0.9.2-pl
++ Released on 2013-07-13
+++++++++++++++++++++++++
- Fix issue with gallery not properly refreshing when saving a resource.

++ MoreGallery 0.9.1-pl
++ Released on 2013-07-10
+++++++++++++++++++++++++
- Styling improvements.

++ MoreGallery 0.9.0-pl
++ Released on 2013-07-10
+++++++++++++++++++++++++
- Initial beta release.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ce4592fb25e2f743efbe2b5ff09153dc',
      'native_key' => 'moregallery',
      'filename' => 'modNamespace/5f99b42a8aa3ad185343945a24f89f85.vehicle',
      'namespace' => 'moregallery',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'bbf0b1b0f751b067b7f2ee48165df5ce',
      'native_key' => 'bbf0b1b0f751b067b7f2ee48165df5ce',
      'filename' => 'xPDOFileVehicle/a8368067b1732d129b9f6c8006116b90.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68f104c1bacde48a46dc37264129a989',
      'native_key' => 'moregallery.source_relative_url',
      'filename' => 'modSystemSetting/27eae595379a3222d75ac0925e6d2e01.vehicle',
      'namespace' => 'moregallery',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93ddc3e9ed8ed747fa88ad0cd0a6e49b',
      'native_key' => 'moregallery.source',
      'filename' => 'modSystemSetting/4d35c5d9f8497f1578112ff157eb262f.vehicle',
      'namespace' => 'moregallery',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8648df329fc660dc41c21380349e41a4',
      'native_key' => 'moregallery.image_id_in_name',
      'filename' => 'modSystemSetting/598eda1bc9130449b2bcd28ef79050eb.vehicle',
      'namespace' => 'moregallery',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97565a2ac8b27ffc34b3b9ac1f9d419c',
      'native_key' => 'moregallery.resource_id_in_path',
      'filename' => 'modSystemSetting/9f3c6f269397081dad47129c50b6184a.vehicle',
      'namespace' => 'moregallery',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '093f32b66fcae2dc7ac2e5022c95cdff',
      'native_key' => 'moregallery.content_position',
      'filename' => 'modSystemSetting/bd1266953a59fb86eaf889bdb971eb3e.vehicle',
      'namespace' => 'moregallery',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79d8107e9ce7a4c6fb35dd474537493e',
      'native_key' => 'moregallery.use_rte_for_images',
      'filename' => 'modSystemSetting/560c999334b9206d295edc9b2b37972e.vehicle',
      'namespace' => 'moregallery',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e91a726fef48d75cfe86bce2d2801b3',
      'native_key' => 'moregallery.single_image_url_param',
      'filename' => 'modSystemSetting/049cb35103486354f270d1aaa0c2fe6e.vehicle',
      'namespace' => 'moregallery',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c686c1fc304d3f8304c12453100ce4fe',
      'native_key' => 'moregallery.add_icon_to_toolbar',
      'filename' => 'modSystemSetting/c75dbe87c24f5e3c80994840787e0692.vehicle',
      'namespace' => 'moregallery',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff0f85427df0548305f6c56814be7d6f',
      'native_key' => 'moregallery.sanitize_replace',
      'filename' => 'modSystemSetting/04b5e7713aff203b912840f44abfbbbb.vehicle',
      'namespace' => 'moregallery',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '097c707c28ac380dc1b988af974b19cc',
      'native_key' => 'moregallery.sanitize_pattern',
      'filename' => 'modSystemSetting/973b5924c25277e506866e3a978b7605.vehicle',
      'namespace' => 'moregallery',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5be7bb4c07201f9782ec4e225205e82',
      'native_key' => 'mgr_tree_icon_mgresource',
      'filename' => 'modSystemSetting/92586400291e7d5dad1448f5384d0a3d.vehicle',
      'namespace' => 'moregallery',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'modmoreVehicle',
      'class' => 'modCategory',
      'guid' => '2602612ddc39239f8c9d5f6d0774bbac',
      'native_key' => 1,
      'filename' => 'modCategory/374f5abc26affa2f1188ce9c12a26e7c.vehicle',
      'namespace' => 'moregallery',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '4220f96e6b7443b9d70e14117fe7b8b5',
      'native_key' => '4220f96e6b7443b9d70e14117fe7b8b5',
      'filename' => 'xPDOScriptVehicle/f49a8d91c8db1101ff97d6ee193a533b.vehicle',
      'namespace' => 'moregallery',
    ),
  ),
);