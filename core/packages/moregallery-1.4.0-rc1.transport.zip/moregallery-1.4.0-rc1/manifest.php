<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MoreGallery is proprietary software, developed by Mark Hamstra for modmore. By purchasing MoreGallery via https://www.modmore.com/extras/moregallery/, you have received a usage license for a single (1) MODX Revolution installation, including one year (starting on date of purchase) of email support.

While we hope MoreGallery is useful to you and we will try to help you successfully use MoreGallery, modmore is not liable for loss of revenue, damages or other financial loss resulting from the installation or use of MoreGallery.

By using and installing this package, you acknowledge that you shall only use this on a single MODX installation.

Redistribution in any shape or form is strictly prohibited. You may customize or change the provided source code to tailor MoreGallery for your own use, as long as no attempt is made to remove license protection measures. By changing source code you acknowledge you void the right to support unless coordinated with modmore support.
',
    'readme' => '--------------------------------------------
MoreGallery - Awesome Gallery for Revolution
--------------------------------------------
Author: Mark Hamstra - support@modmore.com
--------------------------------------------

MoreGallery is an awesome Gallery add-on for MODX Revolution that puts your galleries where they belong - in the Resource tree. Optimized for speed and an awesome user experience, MoreGallery takes galleries in MODX to a new level.

For more information on features and how to use them, please refer to https://www.modmore.com/extras/moregallery/

MoreGallery includes icons created by Daniel Bruce, licensed as CC BY-SA 3.0.
',
    'changelog' => '++ MoreGallery 1.4.0-rc1
++ Released on 2016-03-23
+++++++++++++++++++++++++
New Features:
- Custom fields! Add text fields, text areas, rich text or select fields to the image edit modal [#74]
- Automatically regenerate the mgr_thumb if it no longer exists or the mgr_thumb column is empty [#138]
- Add crop_jpeg_quality setting to control the quality of thumbnails that are generated as jpegs [#137]
- Add thumbnail_format setting to control the format of the mgr_thumb file [#120]
- Add allowed_extensions_per_source setting to limit uploads to media-source specific allowed imageExtensions [#132]
- Add &includeCount property to mgGetTags to get the number of images using a specific tag [#135]
- Allow excluding images by tag with mgGetImages with "-tag" [#136 - thanks Thomas!]
- Add &wrapperIfEmpty property to mgGetTags and mgGetImages that allows disabling the wrapperTpl if there are no results [#118]
- Add &singleImageParam property to mgGetImages to allow changing the parameter per snippet call
- Add &singleImageEnabled property to mgGetImages to disable the single image view completely
- Automatically create tags when keywords are found in the image IPTC data [#112]
- Make IPTC data available via a new iptc image field
- Add support for path placeholders in the gallery path, including dates, a selection of settings and all resource fields and TVs
- Provide support for extras like FileSluggy that sanitise file names on upload [#142]

Improvements:
- Prevent potential fatal error in mgGetImages/mgGetTags if $modx->resource isn\'t set [#119]
- Make sure mgGetImages/mgGetTags set the working context
- Remove hardcoded tooltip on the resource toolbar icon [#117]
- Make sure mgGetTags with a resource filter also checks if images are hidden
- Make visual difference between active and inactive images bigger [#116]
- Implement modmore/Alpacka for shared utilities [#141]
- Add support for transliteration for filename sanitization [#121]
- Improve styling of the Gallery header in MODX 2.4
- Automatically refresh the resource update page if the content position or crops are changed
- Add prefill_from_iptc setting to allow disabling the automatic name/tag prefilling [#144]
- Add resource data to the wrapperTpl [#145]
- Allow deleting images when the confirm dialogs are dismissed [#143]
- IPTC and EXIF data can be inspected with iptc_dump, iptc_json, exif_dump and exif_json placeholders

Fixes:
- Fix loading the lexicon for the Content > New Gallery menu item [#87]
- Fix toolbar icon position being out of order
- Fix image URL generation on Windows [S7588]
- Synchronise processing with importing with the upload processing
- Ensure mgImage->toArray respects the $keyPrefix value


++ MoreGallery 1.3.7-pl
++ Released on 2015-10-08
+++++++++++++++++++++++++
- Fix loading crop information from resource settings, was causing images to not get cropped properly automatically
- Improve how the manager thumbs are created to ensure crisp images, even for very tall/wide images
- Strip out invalid control/hidden characters from EXIF data on upload to prevent errors

++ MoreGallery 1.3.6-pl
++ Released on 2015-09-28
+++++++++++++++++++++++++
- Make sure the memory limit is consistently increased when generating crops [S6583]
- Fix case sensitive extension check to be case insensitive [#134]
- Fix undefined variable error and broken image_count wrapper placeholder in mgGetImages
- Make sure description field is big enough when rich text is disabled [#128]
- Fix background of crops preview with transparent images
- Fix unnecessary hardcoded PNG format for crops, now only used when source image is png as well

++ MoreGallery 1.3.5-pl
++ Released on 2015-09-02
+++++++++++++++++++++++++
- Make sure only valid image extensions are allowed to be uploaded [S6405]
- Catch failed uploads when server limits caused the error rather than MODX [#122]

++ MoreGallery 1.3.4-pl
++ Released on 2015-07-13
+++++++++++++++++++++++++
- Updated translations, contributions are welcome via https://crowdin.com/project/modmore-moregallery
- Hardened XHR security to prevent leaking session IDs cross-domain (#114)
- Fix issue with double quotes in image fields not working as expected (potential self-XSS)

++ MoreGallery 1.3.3-pl
++ Released on 2015-05-16
+++++++++++++++++++++++++
- Fix uploads - sorry about that!

++ MoreGallery 1.3.2-pl
++ Released on 2015-05-16
+++++++++++++++++++++++++
- Fix bug that could cause the inability to save a resource when using unicode characters in moregallery (#113)
- Fix potential issues with MySQL strict mode
- Change how editedon/by details are updated to prevent constant changes with Gitify

++ MoreGallery 1.3.1-pl
++ Released on 2015-03-27
+++++++++++++++++++++++++
- Prevent paste from being intercepted by moregallery, resulting in errors (#41)
- Fix issue when using Gitify where the mgImage representation has duplicated mgr_thumb paths

++ MoreGallery 1.3.0-pl
++ Released on 2015-02-20
+++++++++++++++++++++++++
- Please see the 1.3.0-rc1 changelog below for what\'s new in 1.3.x
- Ensure the moregallery service is loaded before accessing it in mgImage

++ MoreGallery 1.3.0-rc2
++ Released on 2015-02-10
+++++++++++++++++++++++++
- Fix issue requiring &resource to be specified on mgGetImages calls
- Fix positioning issues on URL label text and wide crop previews (#108, 109)
- Make sure removing an image also removes the crop thumbnails (#107)

++ MoreGallery 1.3.0-rc1
++ Released on 2015-02-04
+++++++++++++++++++++++++
New Features:
- Add region of interest cropping for responsive images or better art direction (#5)
- Add new visible/hidden state to images so you can hide an image from the front-end without removing it (#85)
- Add typeahead to tags for much easier tag selection (#84)
- On image upload, automatically extract image name from IPTC data if available (#91)
- Add 5 plugin events to hook into various parts of the gallery interaction (#62)
- Automatically rotate images to the right orientation on upload
- Now context-aware, so all settings can be overridden on context level as well

Improvements:
- Add snippet properties to build (#72, #95)
- Ensure transparent backgrounds remain transparent (instead of black) for thumbnails (#51)
- Add &where property to mgGetImages and mgGetTags for generic filtering, accepts JSON formatted queries. (#83)
- Add loading indicator for image tags (#57)
- New [[+width]] and [[+height]] placeholders for images
- Make sure settings have a lexicon and description (#96)
- Improve image centering/cropping in back-end to be always centered and filling the area
- Prevent conflicts with other phpthumb libraries that may be loaded (#73)
- Change how EXIF data is loaded to make it easier to work with (no thumbnail, flat structure)
- Attempt to increase the available memory on upload to make sure the extra processing is possible even with larger images

Bugfixes:
- Fix issue where editing image information causes data multiplication in the js (#97)

++ MoreGallery 1.2.3-pl
++ Released on 2015-01-29
+++++++++++++++++++++++++
- Fix upload issue when image contained invalid EXIF data

++ MoreGallery 1.2.2-pl
++ Released on 2015-01-19
+++++++++++++++++++++++++
- Fix image alignment issues with screens of exactly 1600px wide
- Updated translations (see https://crowdin.com/project/modmore-moregallery)

++ MoreGallery 1.2.1-pl
++ Released on 2014-10-28
+++++++++++++++++++++++++
- Fix potential issue on PHP 5.5/6 related to exif data
- Change how the "Add Gallery" button in the toolbar is loaded so it also loads on components (thanks Wieger Sloot!)
- Change "Add Gallery" button to use Font Awesome in 2.3.
- Small speed optimization for large galleries (thanks Rico!)

++ MoreGallery 1.2.0-pl
++ Released on 2014-08-04
+++++++++++++++++++++++++
- Fix issue filtering on non-existent tags
- Fix icon in the resource tree in 2.3.? (depends on modxcms/revolution#11736)

++ MoreGallery 1.2.0-rc1
++ Released on 2014-07-18
+++++++++++++++++++++++++
New Features:
- By default set source, relative url and content position to "inherit" so they continue to inherit system defaults after save.
- Allow dragging resources into the image URL field for quick insertion
- Add ability to control placement of image IDs into image file name
- Add ability to prevent the gallery ID from getting added to the file path
- Add ability to use sortBy=`random` with mgGetImages to get random images from cached data

Improvements:
- Improve ContentBlocks compatibility with some styling tweaks and support for content-in-tab
- Improve compatibility with Tagger (Thanks TheBoxer!)
- Make sure TinyMCE is initialised when editing images
- #65 Strip out unnecessary data from AJAX requests that could trigger mod_security errors
- Adjust resource validation to allow for derivatives
- Add [[+idx]] to the tpl in the mgGetTags snippet.
- Added Swedish translation
- Improve UX on adding tags to images by indicating you need to add it with a button or enter
- Update styling to match Revolution 2.3

Bugfixes
- Fix z-index issue with fixed toolbar
- Fix issue loading wrong media source when using import from file feature
- Prevent "`[[+resource.id]]` is not a valid integer and may not be passed to makeUrl()" errors
- Fix javascript issue causing gallery initialisation to fail when the resource tree is not available.
- Make sure the total results is set when data is retrieved from cache
- Fix TinyMCE rendering in image description

++ MoreGallery 1.1.0-pl
++ Released on 2014-01-25
+++++++++++++++++++++++++
New Features:
- Add Tagging functionality: back-end adding of tags, mgGetTags snippet to list tags and updates to mgGetImages to filter on tags and added [[+tags]] placeholder
- Import file into the Gallery by selecting it using the MODX Browser
- #55 Sanitise file names on upload

Fixes:
- Fix toolbar to top of the manager when it goes out of view due to scrolling
- Fix broken images in back-end when using remote media sources (like S3)
- #54 Make sure the container is resized upon opening a full image view modal
- #56 Fix errors being logged due to caching check

Improvements:
- Gallery Toolbar now stays in view when scrolling past it
- Change icon set to sprite-based icon set
- Updated Danish translation.

++ MoreGallery 1.0.2-pl
++ Released on 2013-11-06
+++++++++++++++++++++++++
- Add Danish translation

++ MoreGallery 1.0.1-pl
++ Released on 2013-11-06
+++++++++++++++++++++++++
- Add getResourceFields and getResourceTVs properties to mgGetImages to include fields or TVs placeholders.
- Only use the FileReader (for image previews during upload) when it is supported.
- Fix small content field if there\'s no RTE in use.
- Add French translation.

++ MoreGallery 1.0.0-pl
++ Released on 2013-10-30
+++++++++++++++++++++++++
- Prevent toolbar icon from being duplicated after saving a resource.
- Tiny fix to the CSS to prevent left box shadows from disappearing from the first image in each row.
- Prevent annoying jump in image previews when the image completed upload.
- Added Dutch, Czech, Russian and German translations.
- Extract text into a lexicon file for translation.
- Clear the MoreGallery cache when using the Site > Clear Cache menu option.

++ MoreGallery 0.9.16-pl
++ Released on 2013-10-15
+++++++++++++++++++++++++
- Fix fatal error in snippet.
- Fix issue with content location setting.

++ MoreGallery 0.9.15-pl
++ Released on 2013-10-12
+++++++++++++++++++++++++
- Handle exotic image type errors without triggering E_* errors.
- #25 Open full image in a modal instead of new tab
- #23 Change mgResource\'s to modDocument\'s during uninstall
- Add icon to create new gallery to the resource toolbar (can be disabled with add_icon_to_toolbar setting)
- Add single_image_url_param setting to change the "iid" url param to something different.
- Set the top position of the modal so it\'s within view.
- Fix loading of relative_url setting on resource panel (introduced in 0.9.13)

++ MoreGallery 0.9.14-pl
++ Released on 2013-10-08
+++++++++++++++++++++++++
- Implement better UI through usage of modal window for editing instead of weird sliding panel.
- Refactored to use jQuery UI\'s sortable plugin, while bigger it provides a better drag experience.
- #36 Check memory_limit on server and alert if file is probably to large to resize once uploaded.
- Fix issue creating images with MySQL 5.6 (columns always need a value, default or accept null.)
- Add feature to load RTEs into the edit panel (enabled by default, setting moregallery.use_rte_for_images)

++ MoreGallery 0.9.13-pl
++ Released on 2013-09-27
+++++++++++++++++++++++++
- #38 Hide content field or move it below images or into a new tab
- Add [[+image_count]] placeholder to wrapper tpl.
- #40 Properly load default options (source, url) from system settings on creating a new gallery.
- Fix weird issue with specific environments

++ MoreGallery 0.9.12-pl
++ Released on 2013-09-02
+++++++++++++++++++++++++
- Add some indices for additional (uncached) performance.
- Add "Resource" relation from mgImage to mgResource.
- Fix mgResource>mgImage relation from one to many
- Fix improper class_key setting.

++ MoreGallery 0.9.11-pl
++ Released on 2013-07-29
+++++++++++++++++++++++++
- Add relative_url and source settings to Resource > Settings tab to manage properties.
- Improve focus handling with auto save.
- Set "name" field of the image to the filename without extension by default.
- Improve error messages when upload fails.
- Accept empty value for moregallery.source_relative_url setting (ie, root of media source)

++ MoreGallery 0.9.10-pl
++ Released on 2013-07-23
+++++++++++++++++++++++++
- Add moregallery.source_relative_url and moregallery.source setting.
- Add error (and remove uploading image) if upload failed.

++ MoreGallery 0.9.9-pl
++ Released on 2013-07-21
+++++++++++++++++++++++++
- Fix annoying and broken reload when saving the resource

++ MoreGallery 0.9.8-pl
++ Released on 2013-07-19
+++++++++++++++++++++++++
- Lots of CSS tweaks to make it integrate better with latest 2.2/2.3 design.
- Add ability to link to resources by entering the resource ID.
- Add proper uploading image for images > 700kb.
- Fix loading RTEs.

++ MoreGallery 0.9.7-pl
++ Released on 2013-07-16
+++++++++++++++++++++++++
- Fix E_WARN error on certain environments.

++ MoreGallery 0.9.6-pl
++ Released on 2013-07-16
+++++++++++++++++++++++++
- Fix z-index conflicts with #modAB when editing images.
- Auto focus on name field when opening edit panel.
- Further improvements to performance of the manager, especially when uploading large images:
- - Minimize re-renders of backbone templates
- - Only show image previews for images that are smaller than 700kb to preserve the browser
- - Use data URIs to prevent additional requests for first 20 images in list, and freshly uploaded images.
- - Delay upload by 1s to let the browser do one thing at a time.
- - Only load full size images when opening the edit pane

++ MoreGallery 0.9.5-pl
++ Released on 2013-07-15
+++++++++++++++++++++++++
- Improve browser performance during upload.

++ MoreGallery 0.9.4-pl
++ Released on 2013-07-15
+++++++++++++++++++++++++
- Fix LOG_LEVEL_WARN error "Could not load package metadata"
- Fix prev/next when sortBy is not sortorder or with a descending sortDir
- Add resolver to increase upload_maxsize from 1MB to 10MB on install.
- More sensible (pretty) default chunks.
- Add uploadedon, uploadedby, editedon and editedby fields to images.
- Add ability to paginate through images with getPage
- Add check to make sure chunks referenced are still the same. Removes need to disable &cache.
- Remove dependency on phpthumbof for default chunks.

++ MoreGallery 0.9.3-pl
++ Released on 2013-07-14
+++++++++++++++++++++++++
- Add helpful note to indicate you can drop images into the gallery.
- Improve drag/dropping behavior between sorting and upload.
- Fix issue with uploading images when exif_read_data is not available.
- Make sure link_tag_scheme is used for generating of view_url.

++ MoreGallery 0.9.2-pl
++ Released on 2013-07-13
+++++++++++++++++++++++++
- Fix issue with gallery not properly refreshing when saving a resource.

++ MoreGallery 0.9.1-pl
++ Released on 2013-07-10
+++++++++++++++++++++++++
- Styling improvements.

++ MoreGallery 0.9.0-pl
++ Released on 2013-07-10
+++++++++++++++++++++++++
- Initial beta release.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8d1233eace9e3a5230231f7ae8b5eb66',
      'native_key' => 'moregallery',
      'filename' => 'modNamespace/906fefccfabb9c25ca5730142e3c72e3.vehicle',
      'namespace' => 'moregallery',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'd96233a6f4169cfada5e6ad6da1a77f1',
      'native_key' => 'd96233a6f4169cfada5e6ad6da1a77f1',
      'filename' => 'xPDOFileVehicle/6371d578383889f4f517677aa432e78a.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f5aab4ff610b8afade0496ad4bcaf5f',
      'native_key' => 'moregallery.source_relative_url',
      'filename' => 'modSystemSetting/2cb3f881e8f9602d310d883c574a4b25.vehicle',
      'namespace' => 'moregallery',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71b020a32e78e7ff02ead9b85ba8d335',
      'native_key' => 'moregallery.source',
      'filename' => 'modSystemSetting/62c76a287d4703bac93008ce3fb07d6f.vehicle',
      'namespace' => 'moregallery',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '052d1d3097bf488f9cdc178ef0c0a47a',
      'native_key' => 'moregallery.image_id_in_name',
      'filename' => 'modSystemSetting/912a1f1e2aa5e94ff986fa531b3beebb.vehicle',
      'namespace' => 'moregallery',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab7eb5f1d9cc8ec1d2da8342d5551717',
      'native_key' => 'moregallery.resource_id_in_path',
      'filename' => 'modSystemSetting/22a650fc598fa3147dd91245c4619778.vehicle',
      'namespace' => 'moregallery',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd29254b94636d17de999db3340e82efe',
      'native_key' => 'moregallery.content_position',
      'filename' => 'modSystemSetting/a87913ddb4657cfe4630c3c530a384c2.vehicle',
      'namespace' => 'moregallery',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5c51a81bc95adbee4bf74a30e8bce8f',
      'native_key' => 'moregallery.custom_fields',
      'filename' => 'modSystemSetting/6589af6d3352ccf18f11dc4f2a7e6bd4.vehicle',
      'namespace' => 'moregallery',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59ed8353ebd26be60f99e18a8e9024cb',
      'native_key' => 'moregallery.use_rte_for_images',
      'filename' => 'modSystemSetting/ad8cea5fedd8fd5dfa39d5145a3a16a3.vehicle',
      'namespace' => 'moregallery',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90b695141fc8256a83b775663d6f5881',
      'native_key' => 'moregallery.prefill_from_iptc',
      'filename' => 'modSystemSetting/d540fa581083886190d8a044187531f4.vehicle',
      'namespace' => 'moregallery',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e068826d21d776fbb336b97ee94d848',
      'native_key' => 'moregallery.crops',
      'filename' => 'modSystemSetting/79ac5bea770d216c1085325b829bd4ec.vehicle',
      'namespace' => 'moregallery',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf661064547bb721a43cbcbc6bf843e3',
      'native_key' => 'moregallery.crop_jpeg_quality',
      'filename' => 'modSystemSetting/ed6bb78ab34c30db43b2092c7652d494.vehicle',
      'namespace' => 'moregallery',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '420ccfc0c784560e7f620a63c6e70515',
      'native_key' => 'moregallery.thumbnail_format',
      'filename' => 'modSystemSetting/001d5f09308a5f084315dcc3741344bc.vehicle',
      'namespace' => 'moregallery',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf3535ab7d1849c07b4b4c5494e753a0',
      'native_key' => 'moregallery.single_image_url_param',
      'filename' => 'modSystemSetting/da9aaa5d9873c831de014893384e392f.vehicle',
      'namespace' => 'moregallery',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3418e39fb57c3275b1dd78b93fb6dee6',
      'native_key' => 'moregallery.add_icon_to_toolbar',
      'filename' => 'modSystemSetting/1d899ebf7daa5400b06cd5c5135b87db.vehicle',
      'namespace' => 'moregallery',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54acc26cc67b1cf7c7ba369e4b26def9',
      'native_key' => 'moregallery.sanitize_replace',
      'filename' => 'modSystemSetting/84c96acfeb69bff760e962b9bf5e0949.vehicle',
      'namespace' => 'moregallery',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5af783f998791c95afb7b78c4093d139',
      'native_key' => 'moregallery.sanitize_pattern',
      'filename' => 'modSystemSetting/fce509a9aef1758d2c2179b5c44621f1.vehicle',
      'namespace' => 'moregallery',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34a3b8163ce2b71973da56c40aaaaea3',
      'native_key' => 'moregallery.translit',
      'filename' => 'modSystemSetting/8f6a5cd0fc1334d9dc23f56b7846aff2.vehicle',
      'namespace' => 'moregallery',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3c570e5683ba22b63b59c7a7e1bde27',
      'native_key' => 'moregallery.translit_class',
      'filename' => 'modSystemSetting/cf974c09fd2ce3ec0d350e4bfb3b98a7.vehicle',
      'namespace' => 'moregallery',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cb5ab175b1db2a03739289aae085c80',
      'native_key' => 'moregallery.translit_class_path',
      'filename' => 'modSystemSetting/68046d19335037747c29e5d4598ce1bd.vehicle',
      'namespace' => 'moregallery',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c91b07f9c913ddf925d9d63a2a4a11a',
      'native_key' => 'mgr_tree_icon_mgresource',
      'filename' => 'modSystemSetting/d8a9422a78ddf7389629e5f790717388.vehicle',
      'namespace' => 'moregallery',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90ec60c7f08a92e996cb4547a378ec15',
      'native_key' => 'MoreGallery_OnImageCreate',
      'filename' => 'modEvent/2adf4734dc39cc8133cecd481431c5b0.vehicle',
      'namespace' => 'moregallery',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '072d26f767181077a9953fbb5010b3d3',
      'native_key' => 'MoreGallery_OnImageRemove',
      'filename' => 'modEvent/7663319d61db00be8d3db1e0adb0b455.vehicle',
      'namespace' => 'moregallery',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84516179136318970355b7b51a7dd891',
      'native_key' => 'MoreGallery_OnTagCreate',
      'filename' => 'modEvent/4e0cead0133188af3270143c12bfc5bf.vehicle',
      'namespace' => 'moregallery',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c08380079d189b42e62d0cc2c6a6fafb',
      'native_key' => 'MoreGallery_OnImageTagCreate',
      'filename' => 'modEvent/d3ef534c523869ba0efd3b1ac8479632.vehicle',
      'namespace' => 'moregallery',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9cf5052e4cfa1a89fc436f9464e5623c',
      'native_key' => 'MoreGallery_OnImageTagRemove',
      'filename' => 'modEvent/5fe03ddd1db54165dd3b9dacdba343d5.vehicle',
      'namespace' => 'moregallery',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'modmoreVehicle',
      'class' => 'modCategory',
      'guid' => 'f180fd1a960105bf0f6eb47bd6834d6d',
      'native_key' => 1,
      'filename' => 'modCategory/9cddeb6a4dccd28528adb540a1a6abab.vehicle',
      'namespace' => 'moregallery',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '3f0aa1df2318bda274ecda3833909a5d',
      'native_key' => '3f0aa1df2318bda274ecda3833909a5d',
      'filename' => 'xPDOScriptVehicle/146ec163e1e6152ea1e620d0a6dd6aa3.vehicle',
      'namespace' => 'moregallery',
    ),
  ),
);